<?php
session_start();

if (isset($_SESSION['admin_id'])) {
    header('Location: dashboard.php'); exit;
}

$error = $_SESSION['login_error'] ?? '';
unset($_SESSION['login_error']);

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<style>
/* ── Variables (exact match to shared_styles.php) ─────────────── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --bg:#0b0e14;
  --sidebar-bg:#0e1119;
  --panel:#131720;
  --panel-raised:#181e2c;
  --border:#1f2633;
  --border-light:#29324a;
  --accent:#e8b86d;
  --accent2:#c47f2e;
  --accent-dim:rgba(232,184,109,.12);
  --success:#4caf82;
  --danger:#e05c5c;
  --danger-dim:rgba(224,92,92,.12);
  --warn:#e8a84d;
  --text:#e8eaf0;
  --text-mid:#9aa3ba;
  --muted:#5a6380;
  --radius:12px;
  --radius-sm:8px;
  --font-serif:'DM Serif Display',serif;
  --font-sans:'DM Sans',sans-serif;
}

html,body{height:100%;}
body{
  font-family:var(--font-sans);
  background:var(--bg);
  color:var(--text);
  min-height:100vh;
  display:grid;
  grid-template-columns:1fr 480px;
  overflow:hidden;
}

/* ── LEFT PANEL ─────────────────────────────────────────────────── */
.left {
  position:relative;
  background:var(--sidebar-bg);
  display:flex;
  flex-direction:column;
  justify-content:space-between;
  padding:48px 56px;
  overflow:hidden;
  border-right:1px solid var(--border);
}

/* Layered background atmosphere */
.left-bg {
  position:absolute;
  inset:0;
  pointer-events:none;
  z-index:0;
}
.left-bg::before {
  content:'';
  position:absolute;
  width:600px;height:600px;
  border-radius:50%;
  background:radial-gradient(circle, rgba(232,184,109,.07) 0%, transparent 70%);
  top:-100px;left:-150px;
}
.left-bg::after {
  content:'';
  position:absolute;
  width:500px;height:500px;
  border-radius:50%;
  background:radial-gradient(circle, rgba(76,175,130,.05) 0%, transparent 65%);
  bottom:-80px;right:-100px;
}

/* Subtle grid texture */
.left-grid {
  position:absolute;
  inset:0;
  background-image:
    linear-gradient(rgba(232,184,109,.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(232,184,109,.03) 1px, transparent 1px);
  background-size:48px 48px;
  pointer-events:none;
}

/* Animated orb */
.orb {
  position:absolute;
  width:320px;height:320px;
  border-radius:50%;
  background:radial-gradient(circle at 40% 40%,
    rgba(232,184,109,.12) 0%,
    rgba(196,127,46,.06) 40%,
    transparent 70%);
  bottom:80px;
  right:-60px;
  animation:orbFloat 8s ease-in-out infinite;
  pointer-events:none;
}
@keyframes orbFloat {
  0%,100%{transform:translateY(0) scale(1);}
  50%{transform:translateY(-20px) scale(1.04);}
}

.left>*:not(.left-bg,.left-grid,.orb){position:relative;z-index:1;}

/* Brand */
.brand-row {
  display:flex;
  align-items:center;
  gap:12px;
  animation:fadeUp .5s ease both;
}
.brand-mark {
  width:42px;height:42px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-radius:10px;
  display:grid;place-items:center;
  font-size:20px;
  box-shadow:0 4px 20px rgba(232,184,109,.3);
  flex-shrink:0;
}
.brand-text strong {
  font-family:var(--font-serif);
  font-size:17px;
  color:var(--text);
  display:block;
  line-height:1.2;
}
.brand-text span {
  font-size:10.5px;
  color:var(--muted);
  text-transform:uppercase;
  letter-spacing:.12em;
}

/* Hero */
.hero {
  flex:1;
  display:flex;
  flex-direction:column;
  justify-content:center;
  padding:20px 0;
  animation:fadeUp .5s .1s ease both;
}
.hero-eyebrow {
  display:inline-flex;
  align-items:center;
  gap:7px;
  font-size:11px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.14em;
  color:var(--accent);
  margin-bottom:20px;
}
.hero-eyebrow::before {
  content:'';
  width:24px;height:1.5px;
  background:var(--accent);
  display:inline-block;
}
.hero h1 {
  font-family:var(--font-serif);
  font-size:clamp(2.2rem,3.5vw,3rem);
  font-weight:400;
  line-height:1.12;
  color:var(--text);
  margin-bottom:20px;
}
.hero h1 em {
  font-style:italic;
  color:var(--accent);
}
.hero p {
  font-size:14.5px;
  color:var(--text-mid);
  line-height:1.75;
  max-width:400px;
  margin-bottom:36px;
}

/* Feature pills */
.features {
  display:flex;
  flex-direction:column;
  gap:10px;
}
.feature-item {
  display:flex;
  align-items:center;
  gap:12px;
  padding:11px 16px;
  background:rgba(255,255,255,.025);
  border:1px solid rgba(255,255,255,.05);
  border-radius:var(--radius-sm);
  transition:border-color .2s, background .2s;
  cursor:default;
}
.feature-item:hover {
  border-color:rgba(232,184,109,.15);
  background:rgba(232,184,109,.04);
}
.feature-icon {
  width:32px;height:32px;
  border-radius:7px;
  background:var(--accent-dim);
  display:grid;place-items:center;
  font-size:15px;
  flex-shrink:0;
}
.feature-text {
  font-size:13px;
  color:var(--text-mid);
  font-weight:500;
}
.feature-text strong {
  color:var(--text);
  font-weight:600;
  display:block;
  font-size:13px;
}
.feature-text span {
  font-size:11.5px;
  color:var(--muted);
}

/* System status */
.status-row {
  display:flex;
  align-items:center;
  gap:8px;
  font-size:11.5px;
  color:var(--muted);
  animation:fadeUp .5s .2s ease both;
}
.status-dot {
  width:7px;height:7px;
  border-radius:50%;
  background:var(--success);
  box-shadow:0 0 8px rgba(76,175,130,.5);
  animation:pulse 2.5s ease-in-out infinite;
}
@keyframes pulse{0%,100%{opacity:1;}50%{opacity:.4;}}
.status-text { color:var(--text-mid); }
.status-text strong { color:var(--success); font-weight:600; }

/* ── RIGHT PANEL ────────────────────────────────────────────────── */
.right {
  background:var(--bg);
  display:flex;
  align-items:center;
  justify-content:center;
  padding:40px 48px;
  position:relative;
  overflow-y:auto;
}

/* Subtle right-side glow */
.right::before {
  content:'';
  position:absolute;
  top:0;left:0;
  width:1px;height:100%;
  background:linear-gradient(
    to bottom,
    transparent 0%,
    rgba(232,184,109,.2) 30%,
    rgba(232,184,109,.2) 70%,
    transparent 100%
  );
}

.form-wrap {
  width:100%;
  max-width:360px;
  animation:fadeUp .4s .05s ease both;
}

/* Header */
.form-header {
  margin-bottom:32px;
}
.form-greeting {
  font-size:12px;
  font-weight:600;
  text-transform:uppercase;
  letter-spacing:.12em;
  color:var(--muted);
  margin-bottom:8px;
}
.form-title {
  font-family:var(--font-serif);
  font-size:28px;
  font-weight:400;
  color:var(--text);
  line-height:1.2;
  margin-bottom:6px;
}
.form-subtitle {
  font-size:13.5px;
  color:var(--text-mid);
  line-height:1.6;
}

/* Error alert */
.error-alert {
  display:flex;
  align-items:flex-start;
  gap:10px;
  padding:12px 16px;
  background:var(--danger-dim);
  border:1px solid rgba(224,92,92,.3);
  border-radius:var(--radius-sm);
  font-size:13px;
  color:#f08080;
  margin-bottom:24px;
  animation:shake .35s ease;
}
.error-icon { font-size:15px; flex-shrink:0; margin-top:1px; }
@keyframes shake{
  0%,100%{transform:translateX(0);}
  20%{transform:translateX(-4px);}
  40%{transform:translateX(4px);}
  60%{transform:translateX(-3px);}
  80%{transform:translateX(3px);}
}

/* Fields */
.fields { display:flex; flex-direction:column; gap:18px; }

.field-group { display:flex; flex-direction:column; gap:6px; }
.field-label {
  font-size:11px;
  font-weight:700;
  text-transform:uppercase;
  letter-spacing:.1em;
  color:var(--muted);
}

.input-wrap { position:relative; }
.input-icon {
  position:absolute;
  left:14px;
  top:50%;
  transform:translateY(-50%);
  font-size:14px;
  opacity:.4;
  pointer-events:none;
  transition:opacity .2s;
}
.field-group:focus-within .input-icon { opacity:.8; }

.field-input {
  width:100%;
  background:var(--panel);
  border:1.5px solid var(--border);
  border-radius:var(--radius-sm);
  padding:12px 44px 12px 42px;
  font-size:14px;
  color:var(--text);
  font-family:var(--font-sans);
  outline:none;
  transition:border-color .2s, box-shadow .2s, background .2s;
}
.field-input:hover { border-color:var(--border-light); }
.field-input:focus {
  border-color:var(--accent);
  box-shadow:0 0 0 3px rgba(232,184,109,.1);
  background:var(--panel-raised);
}
.field-input::placeholder { color:#3a4258; }

/* Password toggle */
.pw-toggle {
  position:absolute;
  right:13px;
  top:50%;
  transform:translateY(-50%);
  background:none;
  border:none;
  color:var(--muted);
  cursor:pointer;
  font-size:15px;
  padding:4px;
  transition:color .2s;
}
.pw-toggle:hover { color:var(--text-mid); }

/* Remember row */
.options-row {
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-top:-4px;
}
.remember-label {
  display:flex;
  align-items:center;
  gap:8px;
  cursor:pointer;
}
.remember-cb {
  width:15px;height:15px;
  accent-color:var(--accent);
  cursor:pointer;
}
.remember-text {
  font-size:12.5px;
  color:var(--text-mid);
  user-select:none;
}

/* Submit button */
.btn-submit {
  width:100%;
  padding:13px;
  background:linear-gradient(135deg,var(--accent) 0%,var(--accent2) 100%);
  border:none;
  border-radius:var(--radius-sm);
  font-family:var(--font-serif);
  font-size:16px;
  font-weight:400;
  color:#1a1000;
  cursor:pointer;
  transition:opacity .2s, transform .15s, box-shadow .2s;
  display:flex;
  align-items:center;
  justify-content:center;
  gap:8px;
  position:relative;
  overflow:hidden;
  letter-spacing:.02em;
}
.btn-submit::after {
  content:'';
  position:absolute;
  inset:0;
  background:linear-gradient(135deg, rgba(255,255,255,.12) 0%, transparent 60%);
  pointer-events:none;
}
.btn-submit:hover {
  opacity:.92;
  transform:translateY(-1px);
  box-shadow:0 8px 24px rgba(232,184,109,.3);
}
.btn-submit:active {
  transform:translateY(0);
  box-shadow:none;
}
.btn-arrow {
  transition:transform .2s;
}
.btn-submit:hover .btn-arrow { transform:translateX(3px); }

/* Divider */
.form-divider {
  display:flex;
  align-items:center;
  gap:12px;
  font-size:11px;
  color:var(--muted);
  letter-spacing:.05em;
}
.form-divider::before,.form-divider::after {
  content:'';flex:1;
  height:1px;
  background:var(--border);
}

/* Security note */
.security-note {
  display:flex;
  align-items:center;
  justify-content:center;
  gap:6px;
  font-size:11.5px;
  color:var(--muted);
  margin-top:4px;
}
.security-note::before {
  content:'🔒';
  font-size:11px;
}

/* Version tag */
.version-tag {
  text-align:center;
  font-size:10.5px;
  color:rgba(90,99,128,.5);
  margin-top:28px;
  letter-spacing:.06em;
}

/* ── Animations ────────────────────────────────────────────────── */
@keyframes fadeUp {
  from{opacity:0;transform:translateY(14px);}
  to{opacity:1;transform:translateY(0);}
}

/* ── Responsive ─────────────────────────────────────────────────── */
@media(max-width:1024px){
  body{grid-template-columns:1fr;}
  .left{
    min-height:auto;
    padding:32px 36px;
    border-right:none;
    border-bottom:1px solid var(--border);
  }
  .hero{padding:16px 0;}
  .hero h1{font-size:2rem;}
  .features{display:none;}
  .orb{display:none;}
  .right{padding:36px 28px;}
}
@media(max-width:480px){
  .left{padding:24px 22px;}
  .right{padding:28px 22px;}
  .form-title{font-size:24px;}
}
</style>
</head>
<body>

<!-- ══════════════════════════ LEFT PANEL ══════════════════════════ -->
<div class="left">
  <div class="left-bg"></div>
  <div class="left-grid"></div>
  <div class="orb"></div>

  <!-- Brand -->
  <div class="brand-row">
    <div class="brand-mark">🏠</div>
    <div class="brand-text">
      <strong>BH Management System</strong>
      <span>Administrator Portal</span>
    </div>
  </div>

  <!-- Hero -->
  <div class="hero">
    <div class="hero-eyebrow">Management System</div>
    <h1>Manage your<br>boarding house<br><em>with confidence.</em></h1>
    <p>A complete platform for tracking tenants, payments, rooms, maintenance, and more — all in one secure dashboard.</p>

    <div class="features">
      <div class="feature-item">
        <div class="feature-icon">👥</div>
        <div class="feature-text">
          <strong>Tenant Management</strong>
          <span>Register, approve, and manage all tenants</span>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">💳</div>
        <div class="feature-text">
          <strong>Payment Tracking</strong>
          <span>Accept payments, generate invoices, track history</span>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">🔧</div>
        <div class="feature-text">
          <strong>Maintenance &amp; Operations</strong>
          <span>Handle requests, schedules, and announcements</span>
        </div>
      </div>
      <div class="feature-item">
        <div class="feature-icon">📊</div>
        <div class="feature-text">
          <strong>Live Dashboard</strong>
          <span>Real-time stats, revenue, and occupancy</span>
        </div>
      </div>
    </div>
  </div>

  <!-- System status -->
  <div class="status-row">
    <div class="status-dot"></div>
    <span class="status-text">System <strong>Online</strong> — All services running normally</span>
  </div>
</div>

<!-- ══════════════════════════ RIGHT PANEL ══════════════════════════ -->
<div class="right">
  <div class="form-wrap">

    <div class="form-header">
      <div class="form-greeting">Secure Admin Access</div>
      <div class="form-title">Welcome back</div>
      <div class="form-subtitle">Sign in with your administrator credentials to access the dashboard.</div>
    </div>

    <?php if ($error): ?>
    <div class="error-alert">
      <span class="error-icon">⚠</span>
      <span><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></span>
    </div>
    <?php endif; ?>

    <form action="process.php" method="POST" class="fields" id="loginForm" onsubmit="handleSubmit(event)">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="action" value="login">

      <!-- Username -->
      <div class="field-group">
        <label class="field-label" for="username">Username or Email</label>
        <div class="input-wrap">
          <span class="input-icon">👤</span>
          <input
            type="text"
            id="username"
            name="username"
            class="field-input"
            placeholder="Enter your username"
            required
            autofocus
            autocomplete="username"
            value="<?= htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
          >
        </div>
      </div>

      <!-- Password -->
      <div class="field-group">
        <label class="field-label" for="password">Password</label>
        <div class="input-wrap">
          <span class="input-icon">🔑</span>
          <input
            type="password"
            id="password"
            name="password"
            class="field-input"
            placeholder="Enter your password"
            required
            autocomplete="current-password"
          >
          <button type="button" class="pw-toggle" id="pwToggle" onclick="togglePassword()" title="Show/hide password">
            👁
          </button>
        </div>
      </div>

      <!-- Options row -->
      <div class="options-row">
        <label class="remember-label">
          <input type="checkbox" class="remember-cb" name="remember" id="remember">
          <span class="remember-text">Keep me signed in</span>
        </label>
      </div>

      <!-- Submit -->
      <button type="submit" class="btn-submit" id="submitBtn">
        <span id="btnText">Sign In to Dashboard</span>
        <span class="btn-arrow" id="btnArrow">→</span>
      </button>

      <!-- Divider + security note -->
      <div class="form-divider">Secured Access</div>
      <div class="security-note">Protected by CSRF token &amp; session encryption</div>

    </form>

    <div class="version-tag">BH Management System &nbsp;·&nbsp; Admin v2.0</div>

  </div>
</div>

<script>
// ── Password visibility toggle ─────────────────────────────────
function togglePassword() {
  const pw  = document.getElementById('password');
  const btn = document.getElementById('pwToggle');
  if (pw.type === 'password') {
    pw.type = 'text';
    btn.textContent = '🙈';
    btn.title = 'Hide password';
  } else {
    pw.type = 'password';
    btn.textContent = '👁';
    btn.title = 'Show password';
  }
}

// ── Submit state (prevent double clicks) ──────────────────────
function handleSubmit(e) {
  const btn     = document.getElementById('submitBtn');
  const btnText = document.getElementById('btnText');
  const arrow   = document.getElementById('btnArrow');

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;

  if (!username || !password) return; // HTML validation handles this

  btn.disabled  = true;
  btn.style.opacity = '.7';
  btnText.textContent = 'Signing in…';
  arrow.textContent   = '⏳';
}

// ── Input focus effects ────────────────────────────────────────
document.querySelectorAll('.field-input').forEach(input => {
  input.addEventListener('focus', function() {
    this.closest('.field-group').querySelector('.field-label').style.color = 'var(--accent)';
  });
  input.addEventListener('blur', function() {
    this.closest('.field-group').querySelector('.field-label').style.color = '';
  });
});
</script>
</body>
</html>