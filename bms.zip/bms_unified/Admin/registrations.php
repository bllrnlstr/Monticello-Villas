<?php
session_start();
require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDB();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// Notification helper + base URLs
require_once __DIR__ . '/../shared/notifications.php';
$tenantBase = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://'
            . $_SERVER['HTTP_HOST']
            . rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/') . '/tenant';
$loginUrl   = $tenantBase . '/index.php';
$inquiryUrl = $tenantBase . '/inquiry.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act    = $_POST['act']    ?? '';
    $reg_id = (int)($_POST['reg_id'] ?? 0);

    // ── APPROVE + SETUP ──────────────────────────────────────────────────────
    // Admin fills in room, rent, due day, move-in, contract, and creates password
    if ($act === 'approve' && $reg_id) {
        $reg = db_fetch_one($pdo, "SELECT * FROM tenants WHERE id=?", [$reg_id]);
        if ($reg) {
            $password      = $_POST['password']       ?? '';
            $room_id       = ($_POST['room_id']       ?? '') ?: null;
            $monthly_rent  = (float)($_POST['monthly_rent']  ?? 0);
            $monthly_due   = (int)($_POST['monthly_due_day'] ?? 1);
            $move_in       = ($_POST['move_in_date']  ?? '') ?: null;
            $contract_start= ($_POST['contract_start']?? '') ?: null;
            $contract_end  = ($_POST['contract_end']  ?? '') ?: null;
            $notes         = trim($_POST['notes']      ?? '') ?: null;

            if (strlen($password) < 6) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Password must be at least 6 characters.'];
                header('Location: registrations.php'); exit;
            }

            $hash = password_hash($password, PASSWORD_BCRYPT);

            // Get room number from room_id
            $room_number = $reg['room_number'];
            if ($room_id) {
                $rn = $pdo->prepare("SELECT room_number FROM rooms WHERE id=? LIMIT 1");
                $rn->execute([$room_id]);
                $room_number = $rn->fetchColumn() ?: $reg['room_number'];
            }

            // Update tenant: approve + set all account details + password
            $pdo->prepare("
                UPDATE tenants SET
                    approval_status  = 'approved',
                    approved_by      = ?,
                    approved_at      = NOW(),
                    password_hash    = ?,
                    room_id          = ?,
                    room_number      = ?,
                    monthly_rent     = ?,
                    monthly_due_day  = ?,
                    move_in_date     = ?,
                    notes            = ?
                WHERE id = ?
            ")->execute([
                $adminId, $hash, $room_id, $room_number,
                $monthly_rent, $monthly_due, $move_in, $notes, $reg_id
            ]);

            // Mark room as occupied
            if ($room_id) {
                $pdo->prepare("UPDATE rooms SET status='occupied' WHERE id=?")->execute([$room_id]);
            }

            // Create contract if dates provided
            if ($contract_start && $contract_end && $room_id) {
                $pdo->prepare("
                    INSERT INTO contracts (tenant_id, room_id, start_date, end_date, monthly_rate, deposit, status)
                    VALUES (?, ?, ?, ?, ?, 0, 'active')
                    ON DUPLICATE KEY UPDATE start_date=VALUES(start_date), end_date=VALUES(end_date)
                ")->execute([$reg_id, $room_id, $contract_start, $contract_end, $monthly_rent]);
            }

            db_audit_admin($pdo, $adminId, 'APPROVE_TENANT',
                "Approved & set up tenant: {$reg['full_name']} (ID: $reg_id) — Room: {$room_number}, Rent: ₱{$monthly_rent}");

            // ── Send approval email with credentials ─────────────────────────
            $emailMsg = '';
            try {
                [$ok, $err] = notify_registration_approved(
                    $reg['email'],
                    $reg['full_name'],
                    $reg['email'],
                    $password,
                    $room_number ?: 'TBA',
                    $monthly_rent,
                    $monthly_due,
                    $move_in ?? '',
                    $loginUrl
                );
                $emailMsg = $ok
                    ? " Approval email with credentials sent to {$reg['email']}."
                    : " (Email failed: {$err})";
            } catch (Throwable $e) {
                $emailMsg = ' (Email error: ' . $e->getMessage() . ')';
            }

            // Send in-app notification
            try {
                $notifTitle = '🎉 Your Registration Has Been Approved!';
                $notifBody  = "Hi {$reg['full_name']},\n\n"
                            . "Your account has been approved!\n\n"
                            . "📧 Email: {$reg['email']}\n"
                            . "🔑 Password: {$password}\n"
                            . "🏠 Room: {$room_number}\n"
                            . "💰 Monthly Rent: ₱" . number_format($monthly_rent, 2) . "\n"
                            . "📅 Due Day: Every {$monthly_due} of the month\n"
                            . ($move_in ? "🗓 Move-In: " . date('F j, Y', strtotime($move_in)) . "\n" : "")
                            . "\nCheck your email for full details. Welcome aboard! 🏡";
                $pdo->exec("CREATE TABLE IF NOT EXISTS tenant_notifications (
                    id INT AUTO_INCREMENT PRIMARY KEY, tenant_id INT NOT NULL,
                    title VARCHAR(255) NOT NULL, message TEXT NOT NULL,
                    type VARCHAR(50) DEFAULT 'general', is_read TINYINT(1) DEFAULT 0,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_tenant (tenant_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $pdo->prepare("INSERT INTO tenant_notifications (tenant_id,title,message,type) VALUES (?,?,?,'approval')")
                    ->execute([$reg_id, $notifTitle, $notifBody]);
            } catch (Throwable $e) {}

            $_SESSION['flash'] = [
                'type' => 'success',
                'msg'  => "✅ Account approved and set up for {$reg['full_name']}.{$emailMsg} "
                        . "Login: {$reg['email']} / Password: {$password}"
            ];
        }
    }

    // ── REJECT ───────────────────────────────────────────────────────────────
    elseif ($act === 'reject' && $reg_id) {
        $rejection_reason = trim($_POST['rejection_reason'] ?? '');
        $reg = db_fetch_one($pdo, "SELECT * FROM tenants WHERE id=?", [$reg_id]);
        if ($reg) {
            db_execute($pdo, SQL_TENANT_REJECT, [$rejection_reason ?: null, $reg_id]);
            db_audit_admin($pdo, $adminId, 'REJECT_TENANT',
                "Rejected tenant: {$reg['full_name']} (ID: $reg_id) — Reason: {$rejection_reason}");

            // ── Send rejection email ──────────────────────────────────────────
            $emailMsg = '';
            try {
                [$ok, $err] = notify_registration_rejected(
                    $reg['email'], $reg['full_name'], $rejection_reason, $inquiryUrl
                );
                $emailMsg = $ok
                    ? " Rejection email sent to {$reg['email']}."
                    : " (Email failed: {$err})";
            } catch (Throwable $e) {
                $emailMsg = ' (Email error: ' . $e->getMessage() . ')';
            }

            // Send in-app notification
            try {
                $pdo->prepare("INSERT INTO tenant_notifications (tenant_id,title,message,type) VALUES (?,?,?,'rejection')")
                    ->execute([$reg_id,
                        '❌ Registration Update',
                        "Hi {$reg['full_name']},\n\nYour registration was not approved"
                        . ($rejection_reason ? ".\nReason: {$rejection_reason}" : '.')
                        . "\n\nPlease contact management or submit a new inquiry."
                    ]);
            } catch (Throwable $e) {}

            $_SESSION['flash'] = ['type'=>'success','msg'=>"❌ Registration rejected for {$reg['full_name']}.{$emailMsg}"];
        }
    }

    header('Location: registrations.php'); exit;
}

$filterStatus = $_GET['status'] ?? 'pending';
$search       = trim($_GET['q'] ?? '');
$page         = max(1, (int)($_GET['page'] ?? 1));
$perPage      = 20;

$sql    = SQL_TENANTS_LIST;
$params = [];
if ($filterStatus !== '') { $sql .= SQL_TENANTS_LIST_STATUS_APPEND; $params[] = $filterStatus; }
if ($search !== '') { $sql .= SQL_TENANTS_LIST_SEARCH_APPEND; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }
$sql .= SQL_TENANTS_LIST_ORDER;

$paginated     = db_paginate($pdo, $sql, $params, $page, $perPage);
$registrations = $paginated['rows'];
$total         = $paginated['total'];
$pages         = $paginated['pages'];

$summary = [];
foreach (['pending','approved','rejected'] as $s) {
    $summary[$s] = (int)db_scalar($pdo, "SELECT COUNT(*) FROM tenants WHERE approval_status=?", [$s]);
}

$navStats  = db_nav_stats($pdo);
$activeNav = 'registrations';
$rooms     = $pdo->query("SELECT id, room_number, room_type, monthly_rate FROM rooms WHERE status IN ('vacant','reserved') ORDER BY room_number")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Tenant Registrations — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
<style>
.summary-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:22px;}
.sum-card{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);padding:18px 20px;display:flex;align-items:center;gap:14px;cursor:pointer;text-decoration:none;transition:border-color .2s;}
.sum-card:hover{border-color:var(--border-light);}
.sum-card.active-card{border-color:var(--accent);background:var(--accent-dim);}
.sum-icon{width:42px;height:42px;border-radius:10px;display:grid;place-items:center;font-size:18px;flex-shrink:0;}
.sum-icon.warn{background:var(--warn-dim);}.sum-icon.green{background:var(--success-dim);}.sum-icon.red{background:var(--danger-dim);}
.sum-val{font-family:var(--font-serif);font-size:28px;color:var(--text);line-height:1;}
.sum-lbl{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-top:3px;}
.reg-grid{display:flex;flex-direction:column;gap:14px;}
.reg-card{background:var(--panel-raised);border:1px solid var(--border);border-radius:var(--radius);padding:20px 22px;transition:border-color .2s;}
.reg-card:hover{border-color:var(--border-light);}
.reg-card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;}
.reg-name{font-size:15px;font-weight:600;color:var(--text);display:flex;align-items:center;gap:10px;}
.reg-avatar{width:36px;height:36px;border-radius:9px;background:linear-gradient(135deg,var(--accent),#c47f2e);display:grid;place-items:center;font-size:13px;font-weight:700;color:#1a1200;flex-shrink:0;}
.reg-date{font-size:12px;color:var(--muted);}
.detail-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px 16px;margin-bottom:14px;}
.detail-item{display:flex;flex-direction:column;gap:2px;}
.detail-key{font-size:10px;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);}
.detail-val{font-size:13px;color:var(--text-mid);}
.action-row{display:flex;gap:8px;padding-top:14px;border-top:1px solid var(--border);}
.btn-approve{display:flex;align-items:center;gap:6px;padding:8px 18px;background:var(--success-dim);border:1px solid rgba(76,175,130,.3);border-radius:var(--radius-sm);color:var(--success);font-size:13px;font-weight:600;cursor:pointer;font-family:var(--font-sans);transition:background .2s;}
.btn-approve:hover{background:rgba(76,175,130,.22);}
.btn-reject{display:flex;align-items:center;gap:6px;padding:8px 18px;background:var(--danger-dim);border:1px solid rgba(224,92,92,.3);border-radius:var(--radius-sm);color:var(--danger);font-size:13px;font-weight:600;cursor:pointer;font-family:var(--font-sans);transition:background .2s;}
.btn-reject:hover{background:rgba(224,92,92,.22);}
.rejection-box{margin-top:12px;padding:10px 14px;background:var(--danger-dim);border:1px solid rgba(224,92,92,.2);border-radius:var(--radius-sm);font-size:13px;color:var(--danger);}
.approved-box{margin-top:10px;font-size:12px;color:var(--muted);}
.empty-state{text-align:center;padding:56px 20px;color:var(--muted);}
.empty-state .icon{font-size:40px;margin-bottom:14px;opacity:.35;}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:300;display:none;align-items:center;justify-content:center;}
.modal-overlay.active{display:flex;}
.modal{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);width:100%;max-width:460px;padding:30px;box-shadow:0 24px 48px rgba(0,0,0,.5);opacity:1!important;transform:none!important;}
.modal-title{font-family:var(--font-serif);font-size:20px;margin-bottom:6px;color:var(--text);}
.modal-sub{font-size:13px;color:var(--muted);margin-bottom:22px;}
.modal-label{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:7px;display:block;}
.modal-textarea{width:100%;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px 13px;font-family:var(--font-sans);font-size:13.5px;color:var(--text);outline:none;resize:vertical;min-height:90px;transition:border-color .2s;}
.modal-textarea:focus{border-color:var(--danger);}
.modal-footer{display:flex;gap:10px;margin-top:20px;justify-content:flex-end;}
.btn-ghost-modal{padding:9px 18px;background:transparent;border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text-mid);font-size:13px;font-weight:500;cursor:pointer;font-family:var(--font-sans);transition:background .2s;}
.btn-ghost-modal:hover{background:rgba(255,255,255,.05);}
.btn-danger-modal{padding:9px 20px;background:var(--danger-dim);border:1px solid rgba(224,92,92,.3);border-radius:var(--radius-sm);color:var(--danger);font-size:13px;font-weight:600;cursor:pointer;font-family:var(--font-sans);transition:background .2s;}
.btn-danger-modal:hover{background:rgba(224,92,92,.22);}
</style>
</head>
<body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <button class="icon-btn hamburger" onclick="openSidebar()">☰</button>
    <div class="topbar-left"><h2>Tenant Registrations</h2><p>Review and approve incoming tenant applications</p></div>
  </div>
  <div class="topbar-actions">
    <form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form>
  </div>
</header>
<div class="content">

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>" style="margin-bottom:20px;">
  <?php if ($flash['type'] === 'success' && str_contains($flash['msg'], 'Login:')): ?>
    <?php
      // Parse credentials out of the flash message
      preg_match('/Login: (\S+) \/ Password: (\S+)/', $flash['msg'], $m);
      $credEmail = $m[1] ?? '';
      $credPass  = $m[2] ?? '';
      $baseMsg   = preg_replace('/ Login:.*$/', '', $flash['msg']);
    ?>
    <?= htmlspecialchars($baseMsg, ENT_QUOTES, 'UTF-8') ?>
    <div style="margin-top:12px;padding:12px 16px;background:rgba(76,175,130,.1);border:1px solid rgba(76,175,130,.25);border-radius:6px;">
      <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--success);margin-bottom:8px;">📋 Credentials to give the tenant:</div>
      <div style="font-size:13px;color:var(--text);margin-bottom:4px;">📧 Email: <strong><?= htmlspecialchars($credEmail, ENT_QUOTES, 'UTF-8') ?></strong></div>
      <div style="font-size:13px;color:var(--text);">🔑 Password: <strong style="font-family:monospace;letter-spacing:.05em;"><?= htmlspecialchars($credPass, ENT_QUOTES, 'UTF-8') ?></strong></div>
      <div style="font-size:11px;color:var(--muted);margin-top:6px;">⚠ Save this password now — it cannot be retrieved later.</div>
    </div>
  <?php else: ?>
    <?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?>
  <?php endif; ?>
</div>
<?php endif; ?>

<!-- Summary Cards -->
<div class="summary-cards">
  <a href="?status=pending"  class="sum-card <?= $filterStatus==='pending' ?'active-card':'' ?>"><div class="sum-icon warn">⏳</div><div><div class="sum-val"><?= $summary['pending'] ?></div><div class="sum-lbl">Pending Review</div></div></a>
  <a href="?status=approved" class="sum-card <?= $filterStatus==='approved'?'active-card':'' ?>"><div class="sum-icon green">✅</div><div><div class="sum-val"><?= $summary['approved'] ?></div><div class="sum-lbl">Approved</div></div></a>
  <a href="?status=rejected" class="sum-card <?= $filterStatus==='rejected'?'active-card':'' ?>"><div class="sum-icon red">❌</div><div><div class="sum-val"><?= $summary['rejected'] ?></div><div class="sum-lbl">Rejected</div></div></a>
</div>

<!-- Search -->
<div class="panel" style="margin-bottom:18px;">
  <form method="GET" class="filter-row">
    <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus,ENT_QUOTES,'UTF-8') ?>">
    <input type="text" name="q" class="form-input" placeholder="Search name, email, room, phone…" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:300px;">
    <button type="submit" class="btn-secondary">Search</button>
    <a href="?status=<?= urlencode($filterStatus) ?>" class="btn-ghost">Clear</a>
  </form>
</div>

<!-- Registration List -->
<div class="panel">
  <div class="section-header"><span class="section-title"><?= ucfirst($filterStatus) ?> Registrations <small style="color:var(--muted);font-size:13px;">(<?= $total ?>)</small></span></div>

  <?php if (empty($registrations)): ?>
  <div class="empty-state">
    <div class="icon">📋</div>
    <div>No <?= $filterStatus ?> registrations found.</div>
    <?php if ($filterStatus === 'pending'): ?><div style="margin-top:8px;font-size:13px;">When tenants register, they will appear here.</div><?php endif; ?>
  </div>
  <?php else: ?>
  <div class="reg-grid" style="padding:4px 4px 8px;">
    <?php foreach ($registrations as $reg):
      $words    = array_filter(explode(' ', trim($reg['full_name'])));
      $initials = implode('', array_map(fn($w) => strtoupper($w[0]), array_slice($words, 0, 2)));
      $badgeMap = [
        'approved' => '<span class="badge badge-green">✅ Approved</span>',
        'rejected' => '<span class="badge badge-red">❌ Rejected</span>',
        'pending'  => '<span class="badge badge-warn">⏳ Pending</span>',
      ];
      $statusBadge = $badgeMap[$reg['approval_status']] ?? $badgeMap['pending'];
    ?>
    <div class="reg-card">
      <div class="reg-card-header">
        <div class="reg-name">
          <div class="reg-avatar"><?= htmlspecialchars($initials,ENT_QUOTES,'UTF-8') ?></div>
          <?= htmlspecialchars($reg['full_name'],ENT_QUOTES,'UTF-8') ?>
          <?= $statusBadge ?>
        </div>
        <div class="reg-date">Submitted <?= date('M j, Y · g:i A',strtotime($reg['created_at'])) ?></div>
      </div>

      <div class="detail-grid">
        <div class="detail-item"><span class="detail-key">Email</span><span class="detail-val"><?= htmlspecialchars($reg['email'],ENT_QUOTES,'UTF-8') ?></span></div>
        <div class="detail-item"><span class="detail-key">Phone</span><span class="detail-val"><?= htmlspecialchars($reg['phone']??'—',ENT_QUOTES,'UTF-8') ?></span></div>
        <div class="detail-item"><span class="detail-key">Requested Room</span><span class="detail-val"><?= htmlspecialchars($reg['room_number']??'—',ENT_QUOTES,'UTF-8') ?></span></div>
        <div class="detail-item"><span class="detail-key">Address</span><span class="detail-val"><?= htmlspecialchars($reg['address']??'—',ENT_QUOTES,'UTF-8') ?></span></div>
        <div class="detail-item"><span class="detail-key">Emergency Contact</span><span class="detail-val"><?= htmlspecialchars($reg['emergency_contact']??'—',ENT_QUOTES,'UTF-8') ?></span></div>
        <div class="detail-item"><span class="detail-key">Emergency Phone</span><span class="detail-val"><?= htmlspecialchars($reg['emergency_phone']??'—',ENT_QUOTES,'UTF-8') ?></span></div>
      </div>

      <?php if ($reg['approval_status'] === 'rejected' && $reg['rejection_reason']): ?>
      <div class="rejection-box"><strong>Rejection reason:</strong> <?= htmlspecialchars($reg['rejection_reason'],ENT_QUOTES,'UTF-8') ?></div>
      <?php endif; ?>

      <?php if ($reg['approval_status'] === 'approved' && $reg['approved_by']): ?>
      <div class="approved-box">✅ Approved on <?= $reg['approved_at'] ? date('M j, Y',strtotime($reg['approved_at'])) : '—' ?></div>
      <?php endif; ?>

      <?php if ($reg['approval_status'] === 'pending'): ?>
      <div class="action-row">
        <button type="button" class="btn-approve"
                onclick="openSetupModal(<?= htmlspecialchars(json_encode([
                    'id'         => $reg['id'],
                    'full_name'  => $reg['full_name'],
                    'email'      => $reg['email'],
                    'room_number'=> $reg['room_number'] ?? '',
                ]), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP) ?>)">
          ⚙️ Setup &amp; Approve
        </button>
        <button type="button" class="btn-reject" onclick="openRejectModal(<?= $reg['id'] ?>,'<?= htmlspecialchars(addslashes($reg['full_name']),ENT_QUOTES,'UTF-8') ?>')">❌ Reject</button>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>

  <?php if ($pages>1): ?>
  <div class="pagination" style="padding:16px 20px;">
    <?php for($i=1;$i<=$pages;$i++): ?><a href="?status=<?= urlencode($filterStatus) ?>&q=<?= urlencode($search) ?>&page=<?=$i?>" class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a><?php endfor; ?>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>

</div></div>

<!-- Reject Modal -->
<div class="modal-overlay" id="rejectModal">
  <div class="modal">
    <div class="modal-title">Reject Registration</div>
    <div class="modal-sub">Rejecting application for <strong id="rejectName"></strong></div>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
      <input type="hidden" name="act" value="reject">
      <input type="hidden" name="reg_id" id="rejectRegId" value="">
      <label class="modal-label">Reason for rejection <span style="font-weight:400;text-transform:none;letter-spacing:0;color:rgba(148,163,184,.5)">(optional)</span></label>
      <textarea name="rejection_reason" class="modal-textarea" placeholder="e.g. Room not available, incomplete details…"></textarea>
      <div class="modal-footer">
        <button type="button" class="btn-ghost-modal" onclick="closeRejectModal()">Cancel</button>
        <button type="submit" class="btn-danger-modal">Confirm Rejection</button>
      </div>
    </form>
  </div>
</div>

<!-- ══ SETUP & APPROVE MODAL ══════════════════════════════════════════ -->
<div class="modal-overlay" id="setupModal">
  <div class="modal" style="max-width:560px;">
    <div class="modal-title" style="padding:20px 24px 0;">⚙️ Setup &amp; Approve Account</div>
    <div style="padding:6px 24px 16px;font-size:13px;color:var(--muted);">
      Set up <strong id="setup_name" style="color:var(--text)"></strong>'s account before approving.
      The credentials you create here will be given to the tenant.
    </div>
    <form method="POST" id="setupForm">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
      <input type="hidden" name="act" value="approve">
      <input type="hidden" name="reg_id" id="setup_reg_id">
      <div style="padding:0 24px 20px;display:flex;flex-direction:column;gap:14px;">

        <!-- Credentials section -->
        <div style="background:rgba(232,184,109,.06);border:1px solid rgba(232,184,109,.18);border-radius:8px;padding:14px 16px;">
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--accent);margin-bottom:10px;">🔑 Login Credentials</div>
          <div style="font-size:12px;color:var(--muted);margin-bottom:10px;">
            Email: <strong id="setup_email" style="color:var(--text)"></strong> (auto-filled from registration)
          </div>
          <div class="field">
            <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);">Set Password *</label>
            <div style="display:flex;gap:8px;align-items:center;">
              <input type="text" name="password" id="setup_password" class="form-input"
                     placeholder="Create a password for this tenant" minlength="6" required
                     style="font-family:monospace;letter-spacing:.05em;">
              <button type="button" onclick="generatePassword()"
                      style="padding:9px 12px;background:var(--accent-dim);border:1px solid var(--accent);border-radius:6px;color:var(--accent);font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;font-family:var(--font-sans);">
                🎲 Generate
              </button>
            </div>
            <div style="font-size:11px;color:var(--muted);margin-top:4px;">⚠ Write this down — you'll give it to the tenant and cannot retrieve it later.</div>
          </div>
        </div>

        <!-- Room & Rent section -->
        <div style="background:var(--panel-raised);border:1px solid var(--border);border-radius:8px;padding:14px 16px;">
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:10px;">🏠 Room &amp; Rent</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div class="field">
              <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);">Assign Room</label>
              <select name="room_id" id="setup_room" class="form-input" onchange="fillRoomRate(this)">
                <option value="">— Unassigned —</option>
                <?php foreach ($rooms as $r): ?>
                <option value="<?= $r['id'] ?>" data-rate="<?= $r['monthly_rate'] ?>">
                  <?= htmlspecialchars($r['room_number']) ?> (<?= htmlspecialchars($r['room_type']) ?>) — ₱<?= number_format($r['monthly_rate'],2) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);">Monthly Rent (₱)</label>
              <input type="number" name="monthly_rent" id="setup_rent" class="form-input" step="0.01" min="0" placeholder="0.00">
            </div>
            <div class="field">
              <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);">Due Day (1–31)</label>
              <input type="number" name="monthly_due_day" class="form-input" min="1" max="31" placeholder="e.g. 5" value="1">
            </div>
            <div class="field">
              <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);">Move-In Date</label>
              <input type="date" name="move_in_date" class="form-input">
            </div>
          </div>
        </div>

        <!-- Contract section -->
        <div style="background:var(--panel-raised);border:1px solid var(--border);border-radius:8px;padding:14px 16px;">
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:10px;">📋 Contract <span style="font-weight:400;text-transform:none;letter-spacing:0;color:rgba(122,130,153,.5)">(optional)</span></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div class="field">
              <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);">Contract Start</label>
              <input type="date" name="contract_start" class="form-input">
            </div>
            <div class="field">
              <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);">Contract End</label>
              <input type="date" name="contract_end" class="form-input">
            </div>
          </div>
        </div>

        <!-- Notes -->
        <div class="field">
          <label style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);">Admin Notes (optional)</label>
          <textarea name="notes" class="form-input" rows="2" placeholder="Any notes about this tenant…"></textarea>
        </div>

      </div>
      <div class="modal-footer" style="display:flex;gap:10px;justify-content:flex-end;padding:14px 24px;border-top:1px solid var(--border);">
        <button type="button" class="btn-ghost" onclick="closeSetupModal()">Cancel</button>
        <button type="submit" class="btn-primary" style="width:auto;padding:9px 22px;">✅ Approve &amp; Save</button>
      </div>
    </form>
  </div>
</div>

<script>
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
function openRejectModal(regId,name){document.getElementById('rejectRegId').value=regId;document.getElementById('rejectName').textContent=name;document.getElementById('rejectModal').classList.add('active');}
function closeRejectModal(){document.getElementById('rejectModal').classList.remove('active');}
document.getElementById('rejectModal').addEventListener('click',function(e){if(e.target===this)closeRejectModal();});

function openSetupModal(reg) {
  document.getElementById('setup_reg_id').value = reg.id;
  document.getElementById('setup_name').textContent = reg.full_name;
  document.getElementById('setup_email').textContent = reg.email;
  // Pre-fill room number hint if tenant wrote one during registration
  document.getElementById('setup_password').value = '';
  document.getElementById('setupModal').classList.add('active');
}
function closeSetupModal() {
  document.getElementById('setupModal').classList.remove('active');
}
document.getElementById('setupModal').addEventListener('click', function(e) {
  if (e.target === this) closeSetupModal();
});

// Auto-fill rent when room is selected
function fillRoomRate(sel) {
  const rate = sel.options[sel.selectedIndex].dataset.rate;
  if (rate) document.getElementById('setup_rent').value = parseFloat(rate).toFixed(2);
}

// Generate a random readable password
function generatePassword() {
  const chars = 'abcdefghjkmnpqrstuvwxyz23456789';
  let pw = '';
  for (let i = 0; i < 8; i++) pw += chars[Math.floor(Math.random() * chars.length)];
  document.getElementById('setup_password').value = pw;
}
</script>
</body>
</html>