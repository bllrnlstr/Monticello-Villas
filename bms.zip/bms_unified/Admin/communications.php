<?php
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDBConnection();

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// ── Handle POST ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';

    // ── Announcements ─────────────────────────────────────────
    if ($act === 'add_announcement') {
        $title = trim($_POST['title'] ?? '');
        $body  = trim($_POST['body']  ?? '');
        $type  = $_POST['type'] ?? 'general';
        if ($title && $body) {
            db_execute($pdo, SQL_ANNOUNCEMENT_INSERT, [$title, $body, $type, $adminId]);
            db_audit($pdo, $adminId, 'CREATE_ANNOUNCEMENT', "Posted: {$title}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Announcement posted.'];
        }
    } elseif ($act === 'delete_announcement') {
        $id = (int)$_POST['id'];
        db_execute($pdo, SQL_ANNOUNCEMENT_DELETE, [$id]);
        db_audit($pdo, $adminId, 'DELETE_ANNOUNCEMENT', "Deleted announcement id={$id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Announcement deleted.'];
    }

    // ── Borrowed Items ────────────────────────────────────────
    elseif ($act === 'add_borrow') {
        $tenantId   = (int)$_POST['tenant_id'];
        $itemName   = trim($_POST['item_name']   ?? '');
        $quantity   = max(1, (int)($_POST['quantity'] ?? 1));
        $borrowDate = $_POST['borrow_date'] ?? date('Y-m-d');
        $notes      = trim($_POST['notes'] ?? '') ?: null;
        if ($tenantId && $itemName) {
            db_execute($pdo, SQL_BORROW_INSERT, [$tenantId, $itemName, $quantity, $borrowDate, $notes]);
            db_audit($pdo, $adminId, 'ADD_BORROW', "Lent '{$itemName}' to tenant id={$tenantId}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Borrowed item recorded.'];
        }
    } elseif ($act === 'return_item') {
        $id         = (int)$_POST['id'];
        $returnDate = $_POST['return_date'] ?? date('Y-m-d');
        db_execute($pdo, SQL_BORROW_RETURN, [$returnDate, $id]);
        db_audit($pdo, $adminId, 'RETURN_ITEM', "Item id={$id} returned");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Item marked as returned.'];
    } elseif ($act === 'delete_borrow') {
        $id = (int)$_POST['id'];
        db_execute($pdo, "DELETE FROM borrowed_items WHERE id=?", [$id]);
        db_audit($pdo, $adminId, 'DELETE_BORROW', "Deleted borrow record id={$id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Record deleted.'];
    }

    // ── Item Damages ──────────────────────────────────────────
    elseif ($act === 'add_damage') {
        $tenantId   = (int)$_POST['tenant_id'];
        $itemName   = trim($_POST['item_name']   ?? '');
        $desc       = trim($_POST['description'] ?? '');
        if ($tenantId && $itemName && $desc) {
            db_execute($pdo, "INSERT INTO item_damages (tenant_id,item_name,description,status) VALUES (?,?,?,'reported')",
                [$tenantId, $itemName, $desc]);
            db_audit($pdo, $adminId, 'ADD_DAMAGE', "Damage reported: '{$itemName}' by tenant id={$tenantId}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Damage report added.'];
        }
    } elseif ($act === 'update_damage_status') {
        $id     = (int)$_POST['id'];
        $status = $_POST['status'] ?? 'acknowledged';
        db_execute($pdo, "UPDATE item_damages SET status=? WHERE id=?", [$status, $id]);
        db_audit($pdo, $adminId, 'UPDATE_DAMAGE', "Damage id={$id} → {$status}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Damage status updated.'];
    } elseif ($act === 'delete_damage') {
        $id = (int)$_POST['id'];
        db_execute($pdo, "DELETE FROM item_damages WHERE id=?", [$id]);
        db_audit($pdo, $adminId, 'DELETE_DAMAGE', "Deleted damage report id={$id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Damage report deleted.'];
    }

    header('Location: communications.php'); exit;
}

// ── Fetch data ────────────────────────────────────────────────
$announcements = db_fetch_all($pdo, "SELECT a.*, u.full_name AS posted_by FROM announcements a LEFT JOIN admin_users u ON u.id=a.created_by ORDER BY a.created_at DESC");
$borrows       = db_fetch_all($pdo, "SELECT b.*, t.full_name AS tenant_name FROM borrowed_items b LEFT JOIN tenants t ON t.id=b.tenant_id ORDER BY b.borrow_date DESC");
$damages       = db_fetch_all($pdo, "SELECT d.*, t.full_name AS tenant_name FROM item_damages d LEFT JOIN tenants t ON t.id=d.tenant_id ORDER BY d.reported_at DESC");
$tenants       = db_fetch_all($pdo, SQL_TENANTS_ACTIVE);

// Summary counts
$totalAnnouncements = count($announcements);
$activeBorrows      = count(array_filter($borrows,  fn($b) => $b['status'] === 'borrowed'));
$openDamages        = count(array_filter($damages,   fn($d) => $d['status'] === 'reported'));

$navStats  = db_nav_stats($pdo);
$activeNav = 'communications';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Communications — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
<style>
.comm-tabs { display: flex; gap: 4px; margin-bottom: 24px; background: var(--panel); border: 1px solid var(--border); border-radius: var(--radius); padding: 6px; }
.comm-tab  { flex: 1; padding: 10px; text-align: center; border-radius: var(--radius-sm); border: none; background: transparent; font-family: var(--font-sans); font-size: 13px; font-weight: 500; color: var(--text-mid); cursor: pointer; transition: background var(--trans), color var(--trans); }
.comm-tab:hover  { background: rgba(255,255,255,.05); color: var(--text); }
.comm-tab.active { background: var(--accent-dim); color: var(--accent); font-weight: 600; }
.comm-section { display: none; }
.comm-section.active { display: block; }
.ann-card { background: var(--panel-raised); border: 1px solid var(--border); border-radius: var(--radius-sm); padding: 16px 18px; display: flex; gap: 14px; align-items: flex-start; }
.ann-card + .ann-card { margin-top: 10px; }
.ann-type-dot { width: 8px; height: 8px; border-radius: 50%; flex-shrink: 0; margin-top: 6px; }
.ann-type-dot.general     { background: var(--blue); }
.ann-type-dot.warning     { background: var(--danger); }
.ann-type-dot.maintenance { background: var(--warn); }
.ann-type-dot.reminder    { background: var(--success); }
.ann-body { flex: 1; min-width: 0; }
.ann-title { font-size: 14px; font-weight: 600; color: var(--text); margin-bottom: 4px; }
.ann-text  { font-size: 13px; color: var(--text-mid); line-height: 1.6; margin-bottom: 8px; }
.ann-meta  { font-size: 11.5px; color: var(--muted); }
</style>
</head>
<body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <button class="icon-btn hamburger" onclick="openSidebar()">☰</button>
    <div class="topbar-left"><h2>Communications</h2><p>Announcements, borrowed items &amp; damage reports</p></div>
  </div>
  <div class="topbar-actions">
    <form method="POST" action="process.php" style="margin:0;">
      <input type="hidden" name="action" value="logout">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
      <button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button>
    </form>
  </div>
</header>

<div class="content">
<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div>
<?php endif; ?>

<!-- Stat Cards -->
<div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:24px;">
  <div class="stat-card"><div class="stat-icon blue">📢</div><div class="stat-body"><div class="stat-label">Announcements</div><div class="stat-value"><?= $totalAnnouncements ?></div></div></div>
  <div class="stat-card"><div class="stat-icon warn">📦</div><div class="stat-body"><div class="stat-label">Active Borrows</div><div class="stat-value"><?= $activeBorrows ?></div></div></div>
  <div class="stat-card"><div class="stat-icon red">⚠️</div><div class="stat-body"><div class="stat-label">Open Damages</div><div class="stat-value"><?= $openDamages ?></div></div></div>
</div>

<!-- Tab Bar -->
<div class="comm-tabs">
  <button class="comm-tab active" onclick="switchTab('announcements',this)">📢 Announcements <span style="color:var(--muted);font-size:11px;">(<?= $totalAnnouncements ?>)</span></button>
  <button class="comm-tab" onclick="switchTab('borrows',this)">📦 Borrowed Items <span style="color:var(--muted);font-size:11px;">(<?= $activeBorrows ?> active)</span></button>
  <button class="comm-tab" onclick="switchTab('damages',this)">⚠️ Damage Reports <span style="color:var(--muted);font-size:11px;">(<?= $openDamages ?> open)</span></button>
</div>

<!-- ═══════════ ANNOUNCEMENTS ═══════════ -->
<div class="comm-section active" id="tab-announcements">
  <div style="display:grid;grid-template-columns:1fr 360px;gap:20px;align-items:start;">

    <!-- List -->
    <div class="panel">
      <div class="section-header">
        <span class="section-title">All Announcements</span>
      </div>
      <?php if (empty($announcements)): ?>
        <p style="color:var(--muted);font-style:italic;padding:20px 0;">No announcements yet.</p>
      <?php else: foreach($announcements as $a):
        $typeColors = ['general'=>'badge-blue','warning'=>'badge-red','maintenance'=>'badge-warn','reminder'=>'badge-green'];
        $tc = $typeColors[$a['type']] ?? 'badge-muted';
      ?>
      <div class="ann-card">
        <div class="ann-type-dot <?= $a['type'] ?>"></div>
        <div class="ann-body">
          <div class="ann-title"><?= htmlspecialchars($a['title'],ENT_QUOTES,'UTF-8') ?> <span class="badge <?= $tc ?>" style="font-size:10px;"><?= $a['type'] ?></span></div>
          <div class="ann-text"><?= nl2br(htmlspecialchars($a['body'],ENT_QUOTES,'UTF-8')) ?></div>
          <div class="ann-meta">Posted by <?= htmlspecialchars($a['posted_by'] ?? 'Admin',ENT_QUOTES,'UTF-8') ?> · <?= date('M j, Y H:i', strtotime($a['created_at'])) ?></div>
        </div>
        <form method="POST" style="flex-shrink:0;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
          <input type="hidden" name="act" value="delete_announcement">
          <input type="hidden" name="id" value="<?= $a['id'] ?>">
          <button type="submit" class="tbl-btn danger" onclick="return confirm('Delete this announcement?')">Del</button>
        </form>
      </div>
      <?php endforeach; endif; ?>
    </div>

    <!-- Post Form -->
    <div class="panel" style="position:sticky;top:24px;">
      <div class="section-header"><span class="section-title">Post Announcement</span></div>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
        <input type="hidden" name="act" value="add_announcement">
        <div style="display:flex;flex-direction:column;gap:14px;">
          <div class="field">
            <label>Title *</label>
            <input type="text" name="title" class="form-input" required placeholder="e.g. Water Interruption Notice">
          </div>
          <div class="field">
            <label>Type</label>
            <select name="type" class="form-input">
              <?php foreach(['general'=>'General','warning'=>'Warning','maintenance'=>'Maintenance','reminder'=>'Reminder'] as $v=>$l): ?>
              <option value="<?=$v?>"><?=$l?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>Message *</label>
            <textarea name="body" class="form-input" rows="5" required placeholder="Type your announcement here…"></textarea>
          </div>
          <button type="submit" class="btn-primary" style="width:100%;">📢 Post Announcement</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- ═══════════ BORROWED ITEMS ═══════════ -->
<div class="comm-section" id="tab-borrows">
  <div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start;">

    <!-- Table -->
    <div class="panel">
      <div class="section-header"><span class="section-title">Borrowed Items <small style="color:var(--muted);font-size:13px;">(<?= count($borrows) ?>)</small></span></div>
      <div class="table-wrap"><table>
        <thead><tr><th>Item</th><th>Qty</th><th>Tenant</th><th>Borrowed</th><th>Returned</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (empty($borrows)): ?>
          <tr class="empty-row"><td colspan="7">No borrowed items recorded.</td></tr>
        <?php else: foreach($borrows as $b):
          $bMap = ['borrowed'=>'badge-warn','returned'=>'badge-green','damaged'=>'badge-red'];
          $bc   = $bMap[$b['status']] ?? 'badge-muted'; ?>
        <tr>
          <td><strong><?= htmlspecialchars($b['item_name'],ENT_QUOTES,'UTF-8') ?></strong><?= $b['notes'] ? '<br><small style="color:var(--muted)">'.htmlspecialchars(substr($b['notes'],0,50),ENT_QUOTES,'UTF-8').'</small>' : '' ?></td>
          <td><?= $b['quantity'] ?></td>
          <td><?= htmlspecialchars($b['tenant_name'] ?? '—',ENT_QUOTES,'UTF-8') ?></td>
          <td><?= date('M j, Y', strtotime($b['borrow_date'])) ?></td>
          <td><?= $b['return_date'] ? date('M j, Y', strtotime($b['return_date'])) : '<span style="color:var(--muted)">—</span>' ?></td>
          <td><span class="badge <?= $bc ?>"><?= $b['status'] ?></span></td>
          <td style="white-space:nowrap;">
            <?php if ($b['status'] === 'borrowed'): ?>
            <button class="tbl-btn success" onclick="openReturnModal(<?= $b['id'] ?>, '<?= htmlspecialchars($b['item_name'],ENT_JS,'UTF-8') ?>')">✓ Return</button>
            <?php endif; ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
              <input type="hidden" name="act" value="delete_borrow">
              <input type="hidden" name="id" value="<?= $b['id'] ?>">
              <button type="submit" class="tbl-btn danger" onclick="return confirm('Delete this record?')">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table></div>
    </div>

    <!-- Add Borrow Form -->
    <div class="panel" style="position:sticky;top:24px;">
      <div class="section-header"><span class="section-title">Lend an Item</span></div>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
        <input type="hidden" name="act" value="add_borrow">
        <div style="display:flex;flex-direction:column;gap:14px;">
          <div class="field">
            <label>Tenant *</label>
            <select name="tenant_id" class="form-input" required>
              <option value="">— Select Tenant —</option>
              <?php foreach($tenants as $t): ?>
              <option value="<?=$t['id']?>"><?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>Item Name *</label>
            <input type="text" name="item_name" class="form-input" required placeholder="e.g. Extension cord, Fan">
          </div>
          <div class="field">
            <label>Quantity</label>
            <input type="number" name="quantity" class="form-input" value="1" min="1">
          </div>
          <div class="field">
            <label>Borrow Date</label>
            <input type="date" name="borrow_date" class="form-input" value="<?= date('Y-m-d') ?>">
          </div>
          <div class="field">
            <label>Notes</label>
            <textarea name="notes" class="form-input" rows="2" placeholder="Condition, remarks…"></textarea>
          </div>
          <button type="submit" class="btn-primary" style="width:100%;">📦 Record Borrow</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- ═══════════ DAMAGE REPORTS ═══════════ -->
<div class="comm-section" id="tab-damages">
  <div style="display:grid;grid-template-columns:1fr 340px;gap:20px;align-items:start;">

    <!-- Table -->
    <div class="panel">
      <div class="section-header"><span class="section-title">Damage Reports <small style="color:var(--muted);font-size:13px;">(<?= count($damages) ?>)</small></span></div>
      <div class="table-wrap"><table>
        <thead><tr><th>Item</th><th>Tenant</th><th>Description</th><th>Status</th><th>Reported</th><th>Actions</th></tr></thead>
        <tbody>
        <?php if (empty($damages)): ?>
          <tr class="empty-row"><td colspan="6">No damage reports.</td></tr>
        <?php else: foreach($damages as $d):
          $dMap = ['reported'=>'badge-red','acknowledged'=>'badge-warn','resolved'=>'badge-green'];
          $dc   = $dMap[$d['status']] ?? 'badge-muted'; ?>
        <tr>
          <td><strong><?= htmlspecialchars($d['item_name'],ENT_QUOTES,'UTF-8') ?></strong></td>
          <td><?= htmlspecialchars($d['tenant_name'] ?? '—',ENT_QUOTES,'UTF-8') ?></td>
          <td><small style="color:var(--text-mid)"><?= htmlspecialchars(substr($d['description'],0,60),ENT_QUOTES,'UTF-8') ?><?= strlen($d['description'])>60?'…':'' ?></small></td>
          <td><span class="badge <?= $dc ?>"><?= $d['status'] ?></span></td>
          <td><?= date('M j, Y', strtotime($d['reported_at'])) ?></td>
          <td style="white-space:nowrap;">
            <?php if ($d['status'] === 'reported'): ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
              <input type="hidden" name="act" value="update_damage_status">
              <input type="hidden" name="id" value="<?= $d['id'] ?>">
              <input type="hidden" name="status" value="acknowledged">
              <button type="submit" class="tbl-btn">Acknowledge</button>
            </form>
            <?php endif; ?>
            <?php if ($d['status'] === 'acknowledged'): ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
              <input type="hidden" name="act" value="update_damage_status">
              <input type="hidden" name="id" value="<?= $d['id'] ?>">
              <input type="hidden" name="status" value="resolved">
              <button type="submit" class="tbl-btn success">✓ Resolve</button>
            </form>
            <?php endif; ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
              <input type="hidden" name="act" value="delete_damage">
              <input type="hidden" name="id" value="<?= $d['id'] ?>">
              <button type="submit" class="tbl-btn danger" onclick="return confirm('Delete this damage report?')">Del</button>
            </form>
          </td>
        </tr>
        <?php endforeach; endif; ?>
        </tbody>
      </table></div>
    </div>

    <!-- Add Damage Form -->
    <div class="panel" style="position:sticky;top:24px;">
      <div class="section-header"><span class="section-title">Report Damage</span></div>
      <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
        <input type="hidden" name="act" value="add_damage">
        <div style="display:flex;flex-direction:column;gap:14px;">
          <div class="field">
            <label>Tenant *</label>
            <select name="tenant_id" class="form-input" required>
              <option value="">— Select Tenant —</option>
              <?php foreach($tenants as $t): ?>
              <option value="<?=$t['id']?>"><?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>Item Name *</label>
            <input type="text" name="item_name" class="form-input" required placeholder="e.g. Window, Door lock, Furniture">
          </div>
          <div class="field">
            <label>Description *</label>
            <textarea name="description" class="form-input" rows="4" required placeholder="Describe the damage in detail…"></textarea>
          </div>
          <button type="submit" class="btn-primary" style="width:100%;">⚠️ Submit Report</button>
        </div>
      </form>
    </div>
  </div>
</div>

</div><!-- /content -->
</div><!-- /main -->

<!-- Return Item Modal -->
<div class="modal-overlay" id="returnModal">
  <div class="modal" style="max-width:380px;">
    <div class="modal-header">
      <span class="modal-title">Return Item</span>
      <button class="modal-close" onclick="closeModal('returnModal')">✕</button>
    </div>
    <p style="padding:16px 24px 0;color:var(--text-mid);font-size:13.5px;">Mark <strong id="returnItemName"></strong> as returned.</p>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
      <input type="hidden" name="act" value="return_item">
      <input type="hidden" name="id" id="return_id">
      <div class="form-grid">
        <div class="field field-full">
          <label>Return Date</label>
          <input type="date" name="return_date" id="return_date" class="form-input" value="<?= date('Y-m-d') ?>">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn-ghost" onclick="closeModal('returnModal')">Cancel</button>
        <button type="submit" class="btn-primary">✓ Confirm Return</button>
      </div>
    </form>
  </div>
</div>

<script>
function switchTab(name, btn) {
    document.querySelectorAll('.comm-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.comm-tab').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
    history.replaceState(null,'','#'+name);
}

// Restore tab from URL hash on load
(function(){
    const hash = location.hash.replace('#','');
    const valid = ['announcements','borrows','damages'];
    if (valid.includes(hash)) {
        const btn = document.querySelector('[onclick*="switchTab(\''+hash+'\'"]');
        if (btn) switchTab(hash, btn);
    }
})();

function openModal(id)  { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }

function openReturnModal(id, name) {
    document.getElementById('return_id').value = id;
    document.getElementById('returnItemName').textContent = name;
    openModal('returnModal');
}

document.querySelectorAll('.modal-overlay').forEach(o => o.addEventListener('click', e => {
    if (e.target === o) o.classList.remove('active');
}));

function openSidebar()  { document.getElementById('sidebar').classList.add('open'); document.getElementById('overlay').classList.add('visible'); }
function closeSidebar() { document.getElementById('sidebar').classList.remove('open'); document.getElementById('overlay').classList.remove('visible'); }
</script>
</body>
</html>