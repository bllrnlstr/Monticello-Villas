<?php
require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';