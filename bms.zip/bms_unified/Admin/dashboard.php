<?php
  /**
   * dashboard.php
   * Boarding House Management System — Admin Dashboard
   *
   * ✔ Session-guarded (redirects to login if not authenticated)
   *   ✔ Session hijack protection (IP + User-Agent binding)
   *   ✔ All stats fetched live from DB — zero mock data
   */

  session_start();

  require_once __DIR__ . '/db_connection.php';

  // ── Auth guard ───────────────────────────────────────────────
  if (!isset($_SESSION['admin_id'])) {
      header('Location: login.php');
      exit;
  }

  // ── Session timeout (2 hours idle) ───────────────────────────
  if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > 7200) {
      session_destroy();
      header('Location: login.php');
      exit;
  }
  $_SESSION['login_time'] = time();

  // ─── Dashboard data from DB ───────────────────────────────────────────────────
  $pdo   = getDBConnection(); // bms_unified — single database
  $stats = fetchDashboardStats($pdo, null);
  $adminName = htmlspecialchars($_SESSION['admin_name'] ?? 'Admin', ENT_QUOTES, 'UTF-8');
  $adminRole = htmlspecialchars($_SESSION['admin_role'] ?? '', ENT_QUOTES, 'UTF-8');

  // Generate CSRF for the logout form
  if (empty($_SESSION['csrf_token'])) {
      $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
  }
  $csrf = $_SESSION['csrf_token'];

  // ══════════════════════════════════════════════════════════════════════════════
  // ── DB QUERY FUNCTIONS ────────────────────────────────────────────────────────
  // ══════════════════════════════════════════════════════════════════════════════
  function fetchDashboardStats(PDO $pdo, ?PDO $tpdo): array {
      $stats = [
          'total_rooms'         => 0,
          'occupied_rooms'      => 0,
          'vacant_rooms'        => 0,
          'total_tenants'       => 0,
          'active_tenants'      => 0,
          'monthly_revenue'     => 0.00,
          'pending_payments'    => 0,
          'overdue_payments'    => 0,
          'maintenance_requests'=> 0,
          'new_inquiries'       => 0,
          'recent_tenants'      => [],
          'recent_payments'     => [],
          'room_type_breakdown' => [],
          'monthly_revenue_trend' => [],
      ];

      try {
          // ── Rooms (from bms) ──────────────────────────────────────────────────
          $row = $pdo->query('SELECT COUNT(*) AS total FROM rooms')->fetch();
          $stats['total_rooms'] = (int)($row['total'] ?? 0);

          $row = $pdo->query("SELECT COUNT(*) AS cnt FROM rooms WHERE status = 'occupied'")->fetch();
          $stats['occupied_rooms'] = (int)($row['cnt'] ?? 0);

          $row = $pdo->query("SELECT COUNT(*) AS cnt FROM rooms WHERE status = 'vacant'")->fetch();
          $stats['vacant_rooms'] = (int)($row['cnt'] ?? 0);

          // ── Tenants (from bms_unified) ───────────────────────────────────
          $row = $pdo->query('SELECT COUNT(*) AS total FROM tenants')->fetch();
          $stats['total_tenants'] = (int)($row['total'] ?? 0);

          $row = $pdo->query("SELECT COUNT(*) AS cnt FROM tenants WHERE approval_status='approved' AND status='active'")->fetch();
          $stats['active_tenants'] = (int)($row['cnt'] ?? 0);

          // ── Payments (from bms_unified) ──────────────────────────────────────
          $row = $pdo->query(
              "SELECT COALESCE(SUM(amount),0) AS total FROM payments
               WHERE status='paid'
               AND MONTH(paid_at)=MONTH(NOW())
               AND YEAR(paid_at)=YEAR(NOW())"
          )->fetch();
          $stats['monthly_revenue'] = (float)($row['total'] ?? 0);

          $row = $pdo->query("SELECT COUNT(*) AS cnt FROM payments WHERE status='pending'")->fetch();
          $stats['pending_payments'] = (int)($row['cnt'] ?? 0);

          $row = $pdo->query("SELECT COUNT(*) AS cnt FROM payments WHERE status='overdue'")->fetch();
          $stats['overdue_payments'] = (int)($row['cnt'] ?? 0);

          // ── Maintenance (from bms_unified) ───────────────────────────────────
          $row = $pdo->query("SELECT COUNT(*) AS cnt FROM maintenance_requests WHERE status IN ('pending','open')")->fetch();
          $stats['maintenance_requests'] = (int)($row['cnt'] ?? 0);

          // ── Recent tenants ────────────────────────────────────────────────────
          $stats['recent_tenants'] = $pdo->query(
              "SELECT t.id, t.full_name, t.phone AS contact_number, t.move_in_date,
                      t.status, t.room_number
               FROM tenants t
               WHERE t.approval_status='approved'
               ORDER BY t.created_at DESC LIMIT 5"
          )->fetchAll();

          // ── Recent payments ───────────────────────────────────────────────────
          $stats['recent_payments'] = $pdo->query(
              "SELECT p.id, p.amount, p.status, p.paid_at, p.due_date,
                      t.full_name AS tenant_name, r.room_number
               FROM payments p
               LEFT JOIN tenants t ON t.id=p.tenant_id
               LEFT JOIN rooms r ON r.id=p.room_id
               ORDER BY p.created_at DESC LIMIT 5"
          )->fetchAll();

          // ── Monthly revenue trend ─────────────────────────────────────────────
          $stats['monthly_revenue_trend'] = $pdo->query(
              "SELECT DATE_FORMAT(paid_at, '%b %Y') AS month_label,
                      COALESCE(SUM(amount),0) AS total
               FROM payments
               WHERE status='paid'
               AND paid_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
               GROUP BY YEAR(paid_at), MONTH(paid_at)
               ORDER BY YEAR(paid_at), MONTH(paid_at)"
          )->fetchAll();

          // ── Room type breakdown (from bms) ────────────────────────────────────
          $stats['room_type_breakdown'] = $pdo->query(
              "SELECT room_type, COUNT(*) AS total,
                      SUM(status = 'occupied') AS occupied,
                      SUM(status = 'vacant')   AS vacant
               FROM rooms GROUP BY room_type"
          )->fetchAll();

          // ── Inquiries (from bms if exists) ────────────────────────────────────
          try {
              $row = $pdo->query("SELECT COUNT(*) AS cnt FROM inquiries WHERE status = 'new'")->fetch();
              $stats['new_inquiries'] = (int)($row['cnt'] ?? 0);
          } catch (PDOException $e) { $stats['new_inquiries'] = 0; }

      } catch (PDOException $e) {
          error_log('[DASHBOARD_ERROR] ' . $e->getMessage());
      }

      return $stats;
  }

  // ─── Occupancy rate helper ────────────────────────────────────────────────────
  $occupancyRate = $stats['total_rooms'] > 0
      ? round(($stats['occupied_rooms'] / $stats['total_rooms']) * 100)
      : 0;

  // navStats — all from bms_unified
  $navStats = [
      'pending_payments'      => $stats['pending_payments'],
      'maintenance_requests'  => $stats['maintenance_requests'],
      'new_inquiries'         => $stats['new_inquiries'],
      'overdue_payments'      => $stats['overdue_payments'],
      'pending_registrations' => (int)$pdo->query("SELECT COUNT(*) FROM tenants WHERE approval_status='pending'")->fetchColumn(),
  ];
  $activeNav = 'dashboard';

  // JSON encode trend data for Chart.js
  $trendLabels = json_encode(array_column($stats['monthly_revenue_trend'], 'month_label'));
  $trendValues = json_encode(array_column($stats['monthly_revenue_trend'], 'total'));
  ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard — BH Management System</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
  <style>
    /* ══════════════════════════════════
      CSS RESET & VARIABLES
    ══════════════════════════════════ */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --bg:          #0b0e14;
      --sidebar-bg:  #0e1119;
      --panel:       #131720;
      --panel-raised:#181e2c;
      --border:      #1f2633;
      --border-light:#29324a;
      --accent:      #e8b86d;
      --accent2:     #c47f2e;
      --accent-dim:  rgba(232,184,109,.12);
      --success:     #4caf82;
      --success-dim: rgba(76,175,130,.12);
      --danger:      #e05c5c;
      --danger-dim:  rgba(224,92,92,.12);
      --warn:        #e8a84d;
      --warn-dim:    rgba(232,168,77,.12);
      --blue:        #5c8fe8;
      --blue-dim:    rgba(92,143,232,.12);
      --text:        #e8eaf0;
      --text-mid:    #9aa3ba;
      --muted:       #5a6380;
      --sidebar-w:   260px;
      --topbar-h:    64px;
      --radius:      12px;
      --radius-sm:   8px;
      --font-serif:  'DM Serif Display', serif;
      --font-sans:   'DM Sans', sans-serif;
      --trans:       .2s ease;
    }

    html, body { height: 100%; }
    body {
      font-family: var(--font-sans);
      background: var(--bg);
      color: var(--text);
      font-size: 14px;
      line-height: 1.55;
      display: flex;
      overflow: hidden;
    }

    /* ══════════════════════════════════
      SIDEBAR
    ══════════════════════════════════ */
    .sidebar {
      width: var(--sidebar-w);
      min-height: 100vh;
      background: var(--sidebar-bg);
      border-right: 1px solid var(--border);
      display: flex;
      flex-direction: column;
      flex-shrink: 0;
      position: fixed;
      left: 0; top: 0; bottom: 0;
      z-index: 100;
      transition: transform var(--trans);
    }

    .sidebar-brand {
      display: flex;
      align-items: center;
      gap: 11px;
      padding: 20px 20px 18px;
      border-bottom: 1px solid var(--border);
    }
    .brand-icon {
      width: 38px; height: 38px;
      background: linear-gradient(135deg, var(--accent), var(--accent2));
      border-radius: 9px;
      display: grid;
      place-items: center;
      font-size: 18px;
      flex-shrink: 0;
      box-shadow: 0 4px 12px rgba(232,184,109,.25);
    }
    .brand-info { line-height: 1.25; overflow: hidden; }
    .brand-info strong {
      font-family: var(--font-serif);
      font-size: 15px;
      color: var(--text);
      white-space: nowrap;
      display: block;
    }
    .brand-info span {
      font-size: 10.5px;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: .1em;
    }

    .sidebar-nav {
      flex: 1;
      overflow-y: auto;
      padding: 16px 12px;
      scrollbar-width: thin;
      scrollbar-color: var(--border) transparent;
    }

    .nav-section {
      margin-bottom: 24px;
    }
    .nav-section-label {
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: .14em;
      color: var(--muted);
      padding: 0 10px;
      margin-bottom: 8px;
    }

    .nav-item {
      display: flex;
      align-items: center;
      gap: 11px;
      padding: 10px 12px;
      border-radius: var(--radius-sm);
      color: var(--text-mid);
      text-decoration: none;
      font-size: 13.5px;
      font-weight: 500;
      cursor: pointer;
      transition: background var(--trans), color var(--trans);
      user-select: none;
      position: relative;
    }
    .nav-item:hover { background: rgba(255,255,255,.045); color: var(--text); }
    .nav-item.active {
      background: var(--accent-dim);
      color: var(--accent);
    }
    .nav-item.active::before {
      content: '';
      position: absolute;
      left: 0; top: 20%; bottom: 20%;
      width: 3px;
      background: var(--accent);
      border-radius: 0 3px 3px 0;
    }
    .nav-icon { font-size: 17px; flex-shrink: 0; width: 20px; text-align: center; }
    .nav-badge {
      margin-left: auto;
      background: var(--danger);
      color: #fff;
      font-size: 10px;
      font-weight: 700;
      padding: 1px 6px;
      border-radius: 99px;
      min-width: 18px;
      text-align: center;
    }
    .nav-badge.warn { background: var(--warn); }

    .sidebar-footer {
      border-top: 1px solid var(--border);
      padding: 14px 12px;
    }
    .admin-card {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 12px;
      border-radius: var(--radius-sm);
      background: rgba(255,255,255,.03);
    }
    .admin-avatar {
      width: 34px; height: 34px;
      background: linear-gradient(135deg, #5c8fe8, #3b6bc4);
      border-radius: 50%;
      display: grid;
      place-items: center;
      font-size: 14px;
      font-weight: 700;
      color: #fff;
      flex-shrink: 0;
    }
    .admin-info { flex: 1; overflow: hidden; }
    .admin-info strong { font-size: 13px; color: var(--text); display: block; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .admin-info span { font-size: 11px; color: var(--muted); text-transform: capitalize; }

    /* ══════════════════════════════════
      MAIN CONTENT
    ══════════════════════════════════ */
    .main {
      margin-left: var(--sidebar-w);
      flex: 1;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      min-width: 0;
    }

    /* ── Top Bar ── */
    .topbar {
      height: var(--topbar-h);
      background: var(--sidebar-bg);
      border-bottom: 1px solid var(--border);
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 28px;
      position: sticky;
      top: 0;
      z-index: 90;
      flex-shrink: 0;
    }
    .topbar-left h2 {
      font-family: var(--font-serif);
      font-size: 20px;
      font-weight: 400;
      color: var(--text);
    }
    .topbar-left p {
      font-size: 12px;
      color: var(--muted);
      margin-top: 1px;
    }

    .topbar-actions { display: flex; align-items: center; gap: 10px; }
    .icon-btn {
      width: 36px; height: 36px;
      background: rgba(255,255,255,.04);
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      display: grid;
      place-items: center;
      cursor: pointer;
      font-size: 16px;
      color: var(--text-mid);
      transition: background var(--trans), color var(--trans);
      position: relative;
      text-decoration: none;
    }
    .icon-btn:hover { background: rgba(255,255,255,.08); color: var(--text); }
    .notif-dot {
      width: 7px; height: 7px;
      background: var(--danger);
      border-radius: 50%;
      position: absolute;
      top: 6px; right: 7px;
      border: 1.5px solid var(--sidebar-bg);
    }

    .btn-logout {
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 8px 16px;
      background: rgba(224,92,92,.1);
      border: 1px solid rgba(224,92,92,.25);
      border-radius: var(--radius-sm);
      color: var(--danger);
      font-family: var(--font-sans);
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      transition: background var(--trans);
      white-space: nowrap;
    }
    .btn-logout:hover { background: rgba(224,92,92,.18); }
    .hamburger { display: none; }

    /* ── Content Area ── */
    .content {
      flex: 1;
      overflow-y: auto;
      padding: 28px 28px 40px;
      scrollbar-width: thin;
      scrollbar-color: var(--border) transparent;
    }

    /* ── Section headers ── */
    .section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 18px;
    }
    .section-title {
      font-family: var(--font-serif);
      font-size: 17px;
      font-weight: 400;
      color: var(--text);
    }
    .section-link {
      font-size: 12.5px;
      color: var(--accent);
      text-decoration: none;
      font-weight: 500;
    }
    .section-link:hover { text-decoration: underline; }

    /* ══════════════════════════════════
      STAT CARDS
    ══════════════════════════════════ */
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 16px;
      margin-bottom: 28px;
    }

    .stat-card {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 20px 22px;
      display: flex;
      align-items: flex-start;
      gap: 14px;
      transition: border-color var(--trans), transform .15s;
      animation: fadeUp .45s ease both;
    }
    .stat-card:hover { border-color: var(--border-light); transform: translateY(-1px); }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(14px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    .stat-card:nth-child(1) { animation-delay: .05s; }
    .stat-card:nth-child(2) { animation-delay: .10s; }
    .stat-card:nth-child(3) { animation-delay: .15s; }
    .stat-card:nth-child(4) { animation-delay: .20s; }
    .stat-card:nth-child(5) { animation-delay: .25s; }
    .stat-card:nth-child(6) { animation-delay: .30s; }
    .stat-card:nth-child(7) { animation-delay: .35s; }
    .stat-card:nth-child(8) { animation-delay: .40s; }

    .stat-icon {
      width: 44px; height: 44px;
      border-radius: 10px;
      display: grid;
      place-items: center;
      font-size: 20px;
      flex-shrink: 0;
    }
    .stat-icon.gold    { background: var(--accent-dim);  }
    .stat-icon.green   { background: var(--success-dim); }
    .stat-icon.red     { background: var(--danger-dim);  }
    .stat-icon.blue    { background: var(--blue-dim);    }
    .stat-icon.warn    { background: var(--warn-dim);    }

    .stat-body { flex: 1; min-width: 0; }
    .stat-label {
      font-size: 11.5px;
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: .08em;
      margin-bottom: 4px;
    }
    .stat-value {
      font-family: var(--font-serif);
      font-size: 26px;
      color: var(--text);
      line-height: 1.1;
    }
    .stat-sub {
      font-size: 11.5px;
      color: var(--text-mid);
      margin-top: 4px;
    }
    .stat-sub .up   { color: var(--success); }
    .stat-sub .down { color: var(--danger);  }

    /* Occupancy bar */
    .occ-bar {
      height: 5px;
      background: var(--border);
      border-radius: 99px;
      margin-top: 8px;
      overflow: hidden;
    }
    .occ-fill {
      height: 100%;
      background: linear-gradient(90deg, var(--accent), var(--accent2));
      border-radius: 99px;
      transition: width .6s ease;
    }

    /* ══════════════════════════════════
      MID ROW (chart + quick actions)
    ══════════════════════════════════ */
    .mid-grid {
      display: grid;
      grid-template-columns: 1fr 300px;
      gap: 16px;
      margin-bottom: 28px;
    }

    .panel {
      background: var(--panel);
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 22px 24px;
      animation: fadeUp .45s ease .3s both;
    }

    /* Chart wrapper */
    .chart-wrapper { height: 220px; position: relative; }

    /* Quick actions */
    .quick-actions { display: flex; flex-direction: column; gap: 10px; margin-top: 4px; }
    .qa-btn {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 14px;
      background: var(--panel-raised);
      border: 1px solid var(--border);
      border-radius: var(--radius-sm);
      color: var(--text);
      text-decoration: none;
      font-size: 13.5px;
      font-weight: 500;
      cursor: pointer;
      transition: border-color var(--trans), background var(--trans);
    }
    .qa-btn:hover { border-color: var(--accent); background: var(--accent-dim); color: var(--accent); }
    .qa-btn span { font-size: 18px; flex-shrink: 0; }

    /* ══════════════════════════════════
      BOTTOM TABLES
    ══════════════════════════════════ */
    .bottom-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 13px;
    }
    thead th {
      text-align: left;
      font-size: 11px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: .09em;
      color: var(--muted);
      padding: 0 12px 12px;
      border-bottom: 1px solid var(--border);
      white-space: nowrap;
    }
    tbody tr {
      border-bottom: 1px solid rgba(255,255,255,.04);
      transition: background var(--trans);
    }
    tbody tr:hover { background: rgba(255,255,255,.025); }
    tbody tr:last-child { border-bottom: none; }
    td {
      padding: 11px 12px;
      color: var(--text-mid);
      vertical-align: middle;
    }
    td strong { color: var(--text); font-weight: 500; }

    .empty-row td {
      text-align: center;
      padding: 28px;
      color: var(--muted);
      font-style: italic;
    }

    /* Badges */
    .badge {
      display: inline-block;
      padding: 2px 9px;
      border-radius: 99px;
      font-size: 11px;
      font-weight: 600;
      text-transform: capitalize;
    }
    .badge-green  { background: var(--success-dim); color: var(--success); }
    .badge-red    { background: var(--danger-dim);  color: var(--danger);  }
    .badge-gold   { background: var(--accent-dim);  color: var(--accent);  }
    .badge-blue   { background: var(--blue-dim);    color: var(--blue);    }
    .badge-warn   { background: var(--warn-dim);    color: var(--warn);    }
    .badge-muted  { background: rgba(90,99,128,.2); color: var(--muted);   }

    /* ══════════════════════════════════
      RESPONSIVE
    ══════════════════════════════════ */
    @media (max-width: 1100px) {
      .stats-grid { grid-template-columns: repeat(2, 1fr); }
      .mid-grid   { grid-template-columns: 1fr; }
      .bottom-grid { grid-template-columns: 1fr; }
    }
    @media (max-width: 768px) {
      :root { --sidebar-w: 0px; }
      .sidebar { transform: translateX(-260px); --sidebar-w: 260px; }
      .sidebar.open { transform: translateX(0); }
      .main { margin-left: 0; }
      .hamburger { display: grid; }
      .content { padding: 18px 16px 32px; }
      .topbar { padding: 0 16px; }
      .stats-grid { grid-template-columns: 1fr 1fr; gap: 10px; }
      .stat-value { font-size: 22px; }
    }
    @media (max-width: 480px) {
      .stats-grid { grid-template-columns: 1fr; }
      .btn-logout span { display: none; }
    }

    /* ── Sidebar overlay on mobile ── */
    .overlay {
      display: none;
      position: fixed; inset: 0;
      background: rgba(0,0,0,.5);
      z-index: 99;
    }
    .overlay.visible { display: block; }
  </style>
  </head>
  <body>

  <!-- ── Mobile overlay ── -->
  <div class="overlay" id="overlay" onclick="closeSidebar()"></div>

  <!-- ════════════════════════════════
      SIDEBAR
  ════════════════════════════════ -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <div class="brand-icon">🏠</div>
      <div class="brand-info">
        <strong>BH Management</strong>
        <span>Admin Panel</span>
      </div>
    </div>

    <nav class="sidebar-nav">
      <div class="nav-section">
        <div class="nav-section-label">Main</div>
        <a class="nav-item active" href="dashboard.php">
          <span class="nav-icon">📊</span> Dashboard
        </a>
        <a class="nav-item" href="rooms.php">
          <span class="nav-icon">🛏</span> Rooms
        </a>
        <a class="nav-item" href="tenants.php">
          <span class="nav-icon">👥</span> Tenants
        </a>
        <a class="nav-item" href="registrations.php">
          <span class="nav-icon">📝</span> Registrations
        </a>
      </div>
      

      <div class="nav-section">
        <div class="nav-section-label">Finance</div>
        <a class="nav-item" href="payments.php">
          <span class="nav-icon">💳</span> Payments
          <?php if ($stats['pending_payments'] > 0): ?>
            <span class="nav-badge warn"><?= $stats['pending_payments'] ?></span>
          <?php endif; ?>
        </a>
        <a class="nav-item" href="invoices.php">
          <span class="nav-icon">📄</span> Invoices
        </a>
      </div>

      <div class="nav-section">
        <div class="nav-section-label">Operations</div>
        <a class="nav-item" href="maintenance.php">
          <span class="nav-icon">🔧</span> Maintenance
          <?php if ($stats['maintenance_requests'] > 0): ?>
            <span class="nav-badge"><?= $stats['maintenance_requests'] ?></span>
          <?php endif; ?>
        </a>
        <a class="nav-item" href="inquiries.php">
          <span class="nav-icon">📬</span> Inquiries
          <?php if ($stats['new_inquiries'] > 0): ?>
            <span class="nav-badge"><?= $stats['new_inquiries'] ?></span>
          <?php endif; ?>
        </a>
        <a class="nav-item" href="contracts.php">
          <span class="nav-icon">📝</span> Contracts
        </a>
        <a class="nav-item" href="communications.php">
          <span class="nav-icon">💬</span> Announcements
        </a>
      </div>

      <div class="nav-section">
        <div class="nav-section-label">Admin</div>
        <a class="nav-item" href="users.php">
          <span class="nav-icon">👤</span> Admin Users
        </a>
        <a class="nav-item" href="audit_logs.php">
          <span class="nav-icon">🕵️</span> Audit Logs
        </a>
        <a class="nav-item" href="settings.php">
          <span class="nav-icon">⚙️</span> Settings
        </a>
      </div>
    </nav>

    <div class="sidebar-footer">
      <div class="admin-card">
        <div class="admin-avatar">
          <?= strtoupper(substr($_SESSION['admin_name'] ?? 'A', 0, 1)) ?>
        </div>
        <div class="admin-info">
          <strong><?= $adminName ?></strong>
          <span><?= $adminRole ?></span>
        </div>
      </div>
    </div>
  </aside>

  <!-- ════════════════════════════════
      MAIN
  ════════════════════════════════ -->
  <div class="main">

    <!-- Top Bar -->
    <header class="topbar">
      <div style="display:flex;align-items:center;gap:14px;">
        <button class="icon-btn hamburger" id="hamburgerBtn" onclick="openSidebar()" aria-label="Menu">☰</button>
        <div class="topbar-left">
          <h2>Dashboard</h2>
          <p>Welcome back, <?= $adminName ?> — <?= date('l, F j, Y') ?></p>
        </div>
      </div>

      <div class="topbar-actions">
        <a class="icon-btn" href="notifications.php" aria-label="Notifications">
          🔔
          <?php if ($stats['new_inquiries'] + $stats['overdue_payments'] > 0): ?>
            <span class="notif-dot"></span>
          <?php endif; ?>
        </a>
        <a class="icon-btn" href="settings.php" aria-label="Settings">⚙️</a>

        <form method="POST" action="process.php" style="margin:0;">
          <input type="hidden" name="action" value="logout">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
          <button type="submit" class="btn-logout">
            🚪 <span>Sign Out</span>
          </button>
        </form>
      </div>
    </header>

    <!-- ── Main Content ── -->
    <div class="content">

      <!-- ── STAT CARDS ── -->
      <div class="stats-grid">

        <!-- Rooms -->
        <div class="stat-card">
          <div class="stat-icon gold">🛏</div>
          <div class="stat-body">
            <div class="stat-label">Total Rooms</div>
            <div class="stat-value"><?= $stats['total_rooms'] ?></div>
            <div class="occ-bar"><div class="occ-fill" style="width:<?= $occupancyRate ?>%"></div></div>
            <div class="stat-sub"><?= $occupancyRate ?>% occupancy rate</div>
          </div>
        </div>

        <!-- Occupied -->
        <div class="stat-card">
          <div class="stat-icon green">✅</div>
          <div class="stat-body">
            <div class="stat-label">Occupied Rooms</div>
            <div class="stat-value"><?= $stats['occupied_rooms'] ?></div>
            <div class="stat-sub">
              <?= $stats['vacant_rooms'] ?> <span>vacant available</span>
            </div>
          </div>
        </div>

        <!-- Active Tenants -->
        <div class="stat-card">
          <div class="stat-icon blue">👥</div>
          <div class="stat-body">
            <div class="stat-label">Active Tenants</div>
            <div class="stat-value"><?= $stats['active_tenants'] ?></div>
            <div class="stat-sub"><?= $stats['total_tenants'] ?> total registered</div>
          </div>
        </div>

        <!-- Monthly Revenue -->
        <div class="stat-card">
          <div class="stat-icon gold">💰</div>
          <div class="stat-body">
            <div class="stat-label">Revenue This Month</div>
            <div class="stat-value">₱<?= number_format($stats['monthly_revenue'], 2) ?></div>
            <div class="stat-sub">Payments received</div>
          </div>
        </div>

        <!-- Pending Payments -->
        <div class="stat-card">
          <div class="stat-icon warn">⏳</div>
          <div class="stat-body">
            <div class="stat-label">Pending Payments</div>
            <div class="stat-value"><?= $stats['pending_payments'] ?></div>
            <div class="stat-sub">Awaiting settlement</div>
          </div>
        </div>

        <!-- Overdue -->
        <div class="stat-card">
          <div class="stat-icon red">⚠️</div>
          <div class="stat-body">
            <div class="stat-label">Overdue Payments</div>
            <div class="stat-value"><?= $stats['overdue_payments'] ?></div>
            <div class="stat-sub">Require immediate action</div>
          </div>
        </div>

        <!-- Maintenance -->
        <div class="stat-card">
          <div class="stat-icon warn">🔧</div>
          <div class="stat-body">
            <div class="stat-label">Open Maintenance</div>
            <div class="stat-value"><?= $stats['maintenance_requests'] ?></div>
            <div class="stat-sub">Active requests</div>
          </div>
        </div>

        <!-- Inquiries -->
        <div class="stat-card">
          <div class="stat-icon blue">📬</div>
          <div class="stat-body">
            <div class="stat-label">New Inquiries</div>
            <div class="stat-value"><?= $stats['new_inquiries'] ?></div>
            <div class="stat-sub">Unread / unassigned</div>
          </div>
        </div>

      </div><!-- /stats-grid -->

      <!-- ── MID ROW: chart + quick actions ── -->
      <div class="mid-grid">

        <!-- Revenue Chart -->
        <div class="panel">
          <div class="section-header" style="margin-bottom:16px;">
            <span class="section-title">Revenue Trend (Last 6 Months)</span>
          </div>
          <div class="chart-wrapper">
            <canvas id="revenueChart"></canvas>
          </div>
        </div>

        <!-- Quick Actions -->
        <div class="panel">
          <div class="section-header" style="margin-bottom:16px;">
            <span class="section-title">Quick Actions</span>
          </div>
          <div class="quick-actions">
            <a class="qa-btn" href="rooms.php?action=add">
              <span>➕</span> Add New Room
            </a>
            <a class="qa-btn" href="tenants.php?action=add">
              <span>👤</span> Register Tenant
            </a>
            <a class="qa-btn" href="payments.php?action=record">
              <span>💳</span> Record Payment
            </a>
            <a class="qa-btn" href="maintenance.php?action=add">
              <span>🔧</span> Log Maintenance
            </a>
            <a class="qa-btn" href="invoices.php?action=generate">
              <span>📄</span> Generate Invoice
            </a>
            <a class="qa-btn" href="inquiries.php">
              <span>📬</span> View Inquiries
            </a>
          </div>
        </div>

      </div><!-- /mid-grid -->

      <!-- ── BOTTOM TABLES ── -->
      <div class="bottom-grid">

        <!-- Recent Tenants -->
        <div class="panel">
          <div class="section-header">
            <span class="section-title">Recent Tenants</span>
            <a class="section-link" href="tenants.php">View all →</a>
          </div>
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Room</th>
                <th>Move-In</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($stats['recent_tenants'])): ?>
                <tr class="empty-row"><td colspan="4">No tenant records found.</td></tr>
              <?php else: ?>
                <?php foreach ($stats['recent_tenants'] as $t): ?>
                <tr>
                  <td><strong><?= htmlspecialchars($t['full_name'], ENT_QUOTES, 'UTF-8') ?></strong><br>
                      <small style="color:var(--muted)"><?= htmlspecialchars($t['contact_number'] ?? '—', ENT_QUOTES, 'UTF-8') ?></small>
                  </td>
                  <td><?= htmlspecialchars($t['room_number'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></td>
                  <td><?= $t['move_in_date'] ? date('M j, Y', strtotime($t['move_in_date'])) : '—' ?></td>
                  <td>
                    <?php
                      $badgeMap = ['active'=>'badge-green','inactive'=>'badge-muted','pending'=>'badge-warn'];
                      $cls = $badgeMap[$t['status']] ?? 'badge-muted';
                    ?>
                    <span class="badge <?= $cls ?>"><?= htmlspecialchars($t['status'], ENT_QUOTES, 'UTF-8') ?></span>
                  </td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <!-- Recent Payments -->
        <div class="panel">
          <div class="section-header">
            <span class="section-title">Recent Payments</span>
            <a class="section-link" href="payments.php">View all →</a>
          </div>
          <table>
            <thead>
              <tr>
                <th>Tenant</th>
                <th>Room</th>
                <th>Amount</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <?php if (empty($stats['recent_payments'])): ?>
                <tr class="empty-row"><td colspan="4">No payment records found.</td></tr>
              <?php else: ?>
                <?php foreach ($stats['recent_payments'] as $p): ?>
                <tr>
                  <td><strong><?= htmlspecialchars($p['tenant_name'] ?? 'Unknown', ENT_QUOTES, 'UTF-8') ?></strong><br>
                      <small style="color:var(--muted)">
                        <?= $p['paid_at'] ? date('M j, Y', strtotime($p['paid_at'])) : 'Due: ' . ($p['due_date'] ? date('M j', strtotime($p['due_date'])) : '—') ?>
                      </small>
                  </td>
                  <td><?= htmlspecialchars($p['room_number'] ?? 'N/A', ENT_QUOTES, 'UTF-8') ?></td>
                  <td><strong>₱<?= number_format((float)$p['amount'], 2) ?></strong></td>
                  <td>
                    <?php
                      $pMap = ['paid'=>'badge-green','pending'=>'badge-warn','overdue'=>'badge-red','partial'=>'badge-blue'];
                      $cls = $pMap[$p['status']] ?? 'badge-muted';
                    ?>
                    <span class="badge <?= $cls ?>"><?= htmlspecialchars($p['status'], ENT_QUOTES, 'UTF-8') ?></span>
                  </td>
                </tr>
                <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

      </div><!-- /bottom-grid -->

    </div><!-- /content -->
  </div><!-- /main -->

  <!-- ════════════════════════════════
      JAVASCRIPT
  ════════════════════════════════ -->
  <script>
    // ── Revenue Chart (Chart.js) ──────────────────────────────────────────────
    const trendLabels = <?= $trendLabels ?>;
    const trendValues = <?= $trendValues ?>;

    const ctx = document.getElementById('revenueChart').getContext('2d');

    const gradient = ctx.createLinearGradient(0, 0, 0, 220);
    gradient.addColorStop(0, 'rgba(232, 184, 109, 0.28)');
    gradient.addColorStop(1, 'rgba(232, 184, 109, 0.01)');

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: trendLabels.length ? trendLabels : ['No data'],
        datasets: [{
          label: 'Revenue (₱)',
          data: trendValues.length ? trendValues : [0],
          borderColor: '#e8b86d',
          borderWidth: 2.5,
          backgroundColor: gradient,
          tension: 0.42,
          fill: true,
          pointRadius: 4,
          pointBackgroundColor: '#e8b86d',
          pointBorderColor: '#0b0e14',
          pointBorderWidth: 2,
          pointHoverRadius: 6,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: '#131720',
            borderColor: '#1f2633',
            borderWidth: 1,
            titleColor: '#e8eaf0',
            bodyColor: '#9aa3ba',
            padding: 12,
            callbacks: {
              label: ctx => ' ₱' + Number(ctx.raw).toLocaleString('en-PH', { minimumFractionDigits: 2 })
            }
          }
        },
        scales: {
          x: {
            grid: { color: 'rgba(255,255,255,.05)', drawBorder: false },
            ticks: { color: '#5a6380', font: { size: 11 } }
          },
          y: {
            grid: { color: 'rgba(255,255,255,.05)', drawBorder: false },
            ticks: {
              color: '#5a6380', font: { size: 11 },
              callback: v => '₱' + (v >= 1000 ? (v/1000).toFixed(1)+'k' : v)
            },
            beginAtZero: true,
          }
        }
      }
    });

    // ── Sidebar mobile toggle ─────────────────────────────────────────────────
    function openSidebar() {
      document.getElementById('sidebar').classList.add('open');
      document.getElementById('overlay').classList.add('visible');
    }
    function closeSidebar() {
      document.getElementById('sidebar').classList.remove('open');
      document.getElementById('overlay').classList.remove('visible');
    }
  </script>
  </body>
  </html>