<?php
// shared_sidebar.php
// Requires: $navStats, $activeNav, $csrf to be set by the including page
$pendingReg = (int)($navStats['pending_registrations'] ?? 0);
?>
<div class="overlay" id="overlay" onclick="closeSidebar()"></div>
<aside class="sidebar" id="sidebar">
  <div class="sidebar-brand">
    <div class="brand-icon">🏠</div>
    <div class="brand-info">
      <strong>BH Management</strong>
      <span>Admin Panel</span>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section">
      <div class="nav-section-label">Main</div>
      <a class="nav-item <?= ($activeNav ?? '') === 'dashboard' ? 'active' : '' ?>" href="dashboard.php">
        <span class="nav-icon">📊</span> Dashboard
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'rooms' ? 'active' : '' ?>" href="rooms.php">
        <span class="nav-icon">🛏</span> Rooms
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'tenants' ? 'active' : '' ?>" href="tenants.php">
        <span class="nav-icon">👥</span> Tenants
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'registrations' ? 'active' : '' ?>" href="registrations.php">
        <span class="nav-icon">📝</span> Registrations
        <?php if ($pendingReg > 0): ?>
          <span class="nav-badge warn"><?= $pendingReg ?></span>
        <?php endif; ?>
      </a>
    </div>

    <div class="nav-section">
      <div class="nav-section-label">Finance</div>
      <a class="nav-item <?= ($activeNav ?? '') === 'payments' ? 'active' : '' ?>" href="payments.php">
        <span class="nav-icon">💳</span> Payments
        <?php if (($navStats['pending_payments'] ?? 0) > 0): ?>
          <span class="nav-badge warn"><?= $navStats['pending_payments'] ?></span>
        <?php endif; ?>
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'invoices' ? 'active' : '' ?>" href="invoices.php">
        <span class="nav-icon">📄</span> Invoices
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'rents' ? 'active' : '' ?>" href="rents.php">
        <span class="nav-icon">💰</span> Rent Settings
      </a>
    </div>

    <div class="nav-section">
      <div class="nav-section-label">Operations</div>
      <a class="nav-item <?= ($activeNav ?? '') === 'maintenance' ? 'active' : '' ?>" href="maintenance.php">
        <span class="nav-icon">🔧</span> Maintenance
        <?php if (($navStats['maintenance_requests'] ?? 0) > 0): ?>
          <span class="nav-badge"><?= $navStats['maintenance_requests'] ?></span>
        <?php endif; ?>
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'inquiries' ? 'active' : '' ?>" href="inquiries.php">
        <span class="nav-icon">📬</span> Inquiries
        <?php if (($navStats['new_inquiries'] ?? 0) > 0): ?>
          <span class="nav-badge"><?= $navStats['new_inquiries'] ?></span>
        <?php endif; ?>
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'contracts' ? 'active' : '' ?>" href="contracts.php">
        <span class="nav-icon">📋</span> Contracts
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'communications' ? 'active' : '' ?>" href="communications.php">
        <span class="nav-icon">💬</span> Communications
        <?php if ((($navStats['borrowed_items'] ?? 0) + ($navStats['damage_reports'] ?? 0)) > 0): ?>
          <span class="nav-badge"><?= ($navStats['borrowed_items'] ?? 0) + ($navStats['damage_reports'] ?? 0) ?></span>
        <?php endif; ?>
      </a>
    </div>

    <div class="nav-section">
      <div class="nav-section-label">Admin</div>
      <a class="nav-item <?= ($activeNav ?? '') === 'users' ? 'active' : '' ?>" href="users.php">
        <span class="nav-icon">👤</span> Admin Users
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'audit_logs' ? 'active' : '' ?>" href="audit_logs.php">
        <span class="nav-icon">🕵️</span> Audit Logs
      </a>
      <a class="nav-item <?= ($activeNav ?? '') === 'settings' ? 'active' : '' ?>" href="settings.php">
        <span class="nav-icon">⚙️</span> Settings
      </a>
    </div>
  </nav>

  <div class="sidebar-footer">
    <div class="admin-card">
      <div class="admin-avatar">
        <?= strtoupper(substr($_SESSION['admin_name'] ?? 'A', 0, 1)) ?>
      </div>
      <div class="admin-info">
        <strong><?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin', ENT_QUOTES, 'UTF-8') ?></strong>
        <span><?= htmlspecialchars($_SESSION['admin_role'] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
      </div>
    </div>
  </div>
</aside>