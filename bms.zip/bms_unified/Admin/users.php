<?php
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf        = $_SESSION['csrf_token'];
$adminId     = (int)$_SESSION['admin_id'];
$pdo         = getDBConnection();
$isSuperAdmin = ($_SESSION['admin_role'] ?? '') === 'super_admin';
$flash        = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isSuperAdmin) {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';
    if ($act === 'add') {
        $un   = trim($_POST['username']  ?? '');
        $em   = trim($_POST['email']     ?? '');
        $fn   = trim($_POST['full_name'] ?? '');
        $pw   = $_POST['password']       ?? '';
        $role = $_POST['role']           ?? 'admin';
        if ($un && $em && $fn && $pw) {
            $hash = password_hash($pw, PASSWORD_BCRYPT);
            try {
                db_execute($pdo, SQL_USER_INSERT, [$un, $em, $hash, $fn, $role]);
                db_audit($pdo, $adminId, 'CREATE_USER', "Created admin user: {$un}");
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Admin user created.'];
            } catch (PDOException $e) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Username or email already exists.'];
            }
        }
    } elseif ($act === 'toggle') {
        $id = (int)$_POST['id'];
        if ($id !== $adminId) {
            db_execute($pdo, SQL_USER_TOGGLE_ACTIVE, [$id]);
            db_audit($pdo, $adminId, 'TOGGLE_USER', "Toggled active status for user id={$id}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Status toggled.'];
        }
    } elseif ($act === 'reset_pw') {
        $id = (int)$_POST['id'];
        $pw = $_POST['new_password'] ?? '';
        if ($pw !== '') {
            $hash = password_hash($pw, PASSWORD_BCRYPT);
            db_execute($pdo, SQL_USER_RESET_PASSWORD, [$hash, $id]);
            db_audit($pdo, $adminId, 'RESET_PASSWORD', "Reset password for user id={$id}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Password reset.'];
        }
    } elseif ($act === 'delete') {
        $id = (int)$_POST['id'];
        if ($id !== $adminId) {
            $user = db_get_by_id($pdo, SQL_USER_GET_BY_ID, $id);
            db_execute($pdo, SQL_USER_DELETE, [$id]);
            db_audit($pdo, $adminId, 'DELETE_USER', "Deleted admin user: " . ($user['username'] ?? $id));
            $_SESSION['flash'] = ['type'=>'success','msg'=>'User deleted.'];
        }
    }
    header('Location: users.php'); exit;
}

$users     = db_fetch_all($pdo, SQL_USERS_LIST);
$navStats  = db_nav_stats($pdo);
$activeNav = 'users';
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Admin Users — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?></head><body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;"><button class="icon-btn hamburger" onclick="openSidebar()">☰</button><div class="topbar-left"><h2>Admin Users</h2><p>Manage system administrators</p></div></div>
  <div class="topbar-actions">
    <?php if($isSuperAdmin): ?><button class="btn-primary" onclick="openModal('addModal')">+ Add Admin</button><?php endif; ?>
    <form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form>
  </div>
</header>
<div class="content">
<?php if (!$isSuperAdmin): ?><div class="alert alert-error">⚠ Only Super Admins can manage users.</div><?php endif; ?>
<?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div><?php endif; ?>
<div class="panel">
  <div class="section-header"><span class="section-title">Administrators <small style="color:var(--muted);font-size:13px;">(<?= count($users) ?>)</small></span></div>
  <div class="table-wrap"><table>
    <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Last Login</th><th>Actions</th></tr></thead>
    <tbody>
    <?php foreach($users as $u): $isMe=((int)$u['id']===(int)$_SESSION['admin_id']); ?>
    <tr>
      <td><strong><?= htmlspecialchars($u['full_name'],ENT_QUOTES,'UTF-8') ?></strong><?= $isMe?' <span class="badge badge-gold">You</span>':'' ?></td>
      <td><code style="font-size:12px;color:var(--text-mid)"><?= htmlspecialchars($u['username'],ENT_QUOTES,'UTF-8') ?></code></td>
      <td><small><?= htmlspecialchars($u['email'],ENT_QUOTES,'UTF-8') ?></small></td>
      <td><span class="badge <?= $u['role']==='super_admin'?'badge-gold':'badge-blue' ?>"><?= str_replace('_',' ',$u['role']) ?></span></td>
      <td><span class="badge <?= $u['is_active']?'badge-green':'badge-red' ?>"><?= $u['is_active']?'Active':'Disabled' ?></span></td>
      <td><?= $u['last_login']?date('M j, Y H:i',strtotime($u['last_login'])):'Never' ?></td>
      <td style="white-space:nowrap;">
        <?php if($isSuperAdmin && !$isMe): ?>
          <form method="POST" style="display:inline;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="toggle"><input type="hidden" name="id" value="<?=$u['id']?>"><button type="submit" class="tbl-btn"><?= $u['is_active']?'Disable':'Enable' ?></button></form>
          <button class="tbl-btn" onclick="openResetPw(<?=$u['id']?>, '<?= htmlspecialchars($u['username'],ENT_JS,'UTF-8') ?>')">Reset PW</button>
          <button class="tbl-btn danger" onclick="confirmDelete(<?=$u['id']?>,'<?= htmlspecialchars($u['full_name'],ENT_JS,'UTF-8') ?>')">Del</button>
        <?php else: ?><span style="color:var(--muted);font-size:12px;">—</span><?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
</div></div>

<!-- ADD -->
<div class="modal-overlay" id="addModal"><div class="modal">
<div class="modal-header"><span class="modal-title">Add Admin User</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="add">
<div class="form-grid">
  <div class="field"><label>Full Name *</label><input type="text" name="full_name" class="form-input" required></div>
  <div class="field"><label>Username *</label><input type="text" name="username" class="form-input" required></div>
  <div class="field"><label>Email *</label><input type="email" name="email" class="form-input" required></div>
  <div class="field"><label>Password *</label><input type="password" name="password" class="form-input" required minlength="8"></div>
  <div class="field"><label>Role</label><select name="role" class="form-input"><option value="admin">Admin</option><option value="super_admin">Super Admin</option><option value="viewer">Viewer</option></select></div>
</div>
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('addModal')">Cancel</button><button type="submit" class="btn-primary">Create</button></div>
</form></div></div>

<!-- RESET PW -->
<div class="modal-overlay" id="resetModal"><div class="modal" style="max-width:380px;">
<div class="modal-header"><span class="modal-title">Reset Password</span><button class="modal-close" onclick="closeModal('resetModal')">✕</button></div>
<p style="padding:16px 24px 0;color:var(--text-mid);font-size:13.5px;">Set new password for <strong id="reset_username"></strong>:</p>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="reset_pw"><input type="hidden" name="id" id="reset_id">
<div class="form-grid"><div class="field field-full"><label>New Password</label><input type="password" name="new_password" class="form-input" minlength="8" required></div></div>
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('resetModal')">Cancel</button><button type="submit" class="btn-primary">Reset</button></div>
</form></div></div>

<!-- DELETE -->
<div class="modal-overlay" id="deleteModal"><div class="modal" style="max-width:380px;"><div class="modal-header"><span class="modal-title">Delete Admin</span><button class="modal-close" onclick="closeModal('deleteModal')">✕</button></div>
<p style="padding:20px 24px;color:var(--text-mid);">Delete admin <strong id="delName"></strong>?</p>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" id="del_id">
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('deleteModal')">Cancel</button><button type="submit" class="btn-danger">Delete</button></div>
</form></div></div>

<script>
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
function openResetPw(id,un){document.getElementById('reset_id').value=id;document.getElementById('reset_username').textContent=un;openModal('resetModal');}
function confirmDelete(id,name){document.getElementById('del_id').value=id;document.getElementById('delName').textContent=name;openModal('deleteModal');}
document.querySelectorAll('.modal-overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('active');}));
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
</script>
</body></html>