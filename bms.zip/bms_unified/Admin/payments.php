<?php
session_start();
require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDB();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';

    if ($act === 'accept') {
        $id    = (int)$_POST['id'];
        $notes = trim($_POST['admin_notes'] ?? '');
        // Set paid_at AND payment_date for full tenant-portal compatibility
        db_execute($pdo, "UPDATE payments SET status='paid', paid_at=NOW(), payment_date=CURDATE(), admin_notes=? WHERE id=?", [$notes, $id]);
        db_audit_admin($pdo, $adminId, 'PAYMENT_ACCEPT', "Accepted payment ID: $id");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'✅ Payment accepted and marked as paid.'];
    }
    elseif ($act === 'reject') {
        $id    = (int)$_POST['id'];
        $notes = trim($_POST['admin_notes'] ?? '');
        // Set status=rejected so tenant can resubmit (pending block only checks pending/paid)
        db_execute($pdo, "UPDATE payments SET status='rejected', paid_at=NULL, payment_date=NULL, admin_notes=? WHERE id=?", [$notes, $id]);
        db_audit_admin($pdo, $adminId, 'PAYMENT_REJECT', "Rejected payment ID: $id");
        $_SESSION['flash'] = ['type'=>'error','msg'=>'❌ Payment rejected. Tenant can now resubmit.'];
    }

    elseif ($act === 'add_payment') {
        $tenantId = (int)$_POST['tenant_id'];
        $amount   = (float)$_POST['amount'];
        $dueDate  = $_POST['due_date'] ?? date('Y-m-d');
        $method   = trim($_POST['payment_method'] ?? 'Cash');
        $status   = $_POST['pay_status'] ?? 'paid';
        $paidAt   = ($status === 'paid') ? date('Y-m-d H:i:s') : null;
        $notes    = trim($_POST['admin_notes'] ?? '');
        $roomId   = db_scalar($pdo, "SELECT room_id FROM tenants WHERE id=?", [$tenantId]);
        // Warn admin if duplicate exists this month (admin can still override)
        $dupCheck = (int)db_scalar($pdo, "SELECT COUNT(*) FROM payments WHERE tenant_id=? AND MONTH(due_date)=MONTH(?) AND YEAR(due_date)=YEAR(?)", [$tenantId, $dueDate, $dueDate]);
        db_execute($pdo, SQL_PAYMENT_INSERT, [$tenantId, $roomId ?: null, $amount, 'rent', $status, $dueDate, null, $paidAt, $method, null, $notes ?: null, 'admin']);
        db_audit_admin($pdo, $adminId, 'PAYMENT_ADD', "Recorded ₱{$amount} for tenant ID: $tenantId");
        $dupMsg = $dupCheck > 0 ? ' (Warning: tenant already had a payment this month.)' : '';
        $_SESSION['flash'] = ['type'=>'success','msg'=>'✅ Payment recorded.' . $dupMsg];
    }
    elseif ($act === 'edit_payment') {
        $id      = (int)$_POST['id'];
        // Block editing paid payments — prevents admin from modifying confirmed payments
        $existing = db_fetch_one($pdo, "SELECT tenant_id, room_id, status FROM payments WHERE id=?", [$id]);
        if (($existing['status'] ?? '') === 'paid') {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'❌ Cannot edit a confirmed paid payment. This protects tenant payment records.'];
            header('Location: payments.php'); exit;
        }
        $amount  = (float)$_POST['amount'];
        $dueDate = $_POST['due_date'] ?? date('Y-m-d');
        $method  = trim($_POST['payment_method'] ?? 'Cash');
        $status  = $_POST['pay_status'] ?? 'pending';
        // Also prevent changing status TO paid via edit — must use Accept button
        if ($status === 'paid') {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'❌ Use the Accept button to confirm payments, not Edit.'];
            header('Location: payments.php'); exit;
        }
        $notes   = trim($_POST['admin_notes'] ?? '');
        db_execute($pdo, SQL_PAYMENT_UPDATE, [$existing['tenant_id'], $existing['room_id'], $amount, 'rent', $status, $dueDate, null, null, $method, null, $notes ?: null, $id]);
        db_audit_admin($pdo, $adminId, 'PAYMENT_EDIT', "Edited payment ID: $id");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'✅ Payment updated.'];
    }
    elseif ($act === 'delete') {
        $id  = (int)$_POST['id'];
        $pay = db_fetch_one($pdo, "SELECT status FROM payments WHERE id=?", [$id]);
        if (($pay['status'] ?? '') === 'paid') {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'❌ Cannot delete a confirmed paid payment. This protects tenant payment records.'];
            header('Location: payments.php'); exit;
        }
        db_execute($pdo, SQL_PAYMENT_DELETE, [$id]);
        db_audit_admin($pdo, $adminId, 'PAYMENT_DELETE', "Deleted payment ID: $id");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Payment deleted.'];
    }
    header('Location: payments.php'); exit;
}

$filterStatus = $_GET['status'] ?? '';
$search       = trim($_GET['q'] ?? '');
$page         = max(1, (int)($_GET['page'] ?? 1));
$perPage      = 20;

$sql = SQL_PAYMENTS_LIST;
$params = [];
if ($filterStatus !== '') { $sql .= SQL_PAYMENTS_LIST_STATUS_APPEND; $params[] = $filterStatus; }
if ($search !== '') { $sql .= SQL_PAYMENTS_LIST_SEARCH_APPEND; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }
$sql .= SQL_PAYMENTS_LIST_ORDER;

$paginated = db_paginate($pdo, $sql, $params, $page, $perPage);
$payments  = $paginated['rows'];
$total     = $paginated['total'];
$pages     = $paginated['pages'];

$summary  = db_fetch_one($pdo, "
    SELECT
        COUNT(CASE WHEN status='pending'  THEN 1 END) AS pending_cnt,
        COUNT(CASE WHEN status='paid'     THEN 1 END) AS paid_cnt,
        COUNT(CASE WHEN status='overdue'  THEN 1 END) AS overdue_cnt,
        COUNT(CASE WHEN status='rejected' THEN 1 END) AS rejected_cnt,
        COALESCE(SUM(CASE WHEN status='paid' AND paid_at >= DATE_FORMAT(NOW(),'%Y-%m-01') THEN amount ELSE 0 END),0) AS month_rev,
        COALESCE(SUM(CASE WHEN status='pending' THEN amount ELSE 0 END),0) AS pending_amt
    FROM payments
");
$tenants  = db_fetch_all($pdo, "SELECT id, full_name, room_number, monthly_due_day, monthly_rent FROM tenants WHERE approval_status='approved' ORDER BY full_name");
$navStats  = db_nav_stats($pdo);
$activeNav = 'payments';
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Payments — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
<style>
/* Fix modal clipping */
.modal-overlay{z-index:9999!important;}
body{overflow:auto!important;}
.main{overflow:visible!important;}
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:24px;}
.stat-card{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);padding:18px 20px;display:flex;align-items:flex-start;gap:12px;}
.stat-icon{width:42px;height:42px;border-radius:10px;display:grid;place-items:center;font-size:20px;flex-shrink:0;}
.stat-icon.gold{background:var(--accent-dim)}.stat-icon.green{background:var(--success-dim)}.stat-icon.red{background:var(--danger-dim)}.stat-icon.warn{background:var(--warn-dim)}
.stat-body{flex:1;}.stat-label{font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:3px;}
.stat-value{font-family:var(--font-serif);font-size:24px;color:var(--text);line-height:1.1;}
.stat-sub{font-size:11px;color:var(--text-mid);margin-top:3px;}
.receipt-card{background:var(--panel-raised);border:1px solid var(--border);border-radius:var(--radius);padding:18px 20px;margin-bottom:10px;}
.receipt-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;}
.receipt-name{font-size:15px;font-weight:600;color:var(--text);}
.receipt-room{font-size:12px;color:var(--muted);margin-top:2px;}
.receipt-amount{font-family:var(--font-serif);font-size:26px;color:var(--accent);line-height:1;}
.receipt-meta{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px;}
.meta-item{display:flex;flex-direction:column;gap:2px;}
.meta-key{font-size:10px;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);}
.meta-val{font-size:13px;color:var(--text-mid);}
.receipt-actions{display:flex;gap:8px;padding-top:14px;border-top:1px solid var(--border);align-items:center;flex-wrap:wrap;}
.btn-accept{display:flex;align-items:center;gap:6px;padding:8px 16px;background:var(--success-dim);border:1px solid rgba(76,175,130,.3);border-radius:var(--radius-sm);color:var(--success);font-size:13px;font-weight:600;cursor:pointer;font-family:var(--font-sans);transition:background .2s;}
.btn-accept:hover{background:rgba(76,175,130,.22);}
.btn-reject-pay{display:flex;align-items:center;gap:6px;padding:8px 16px;background:var(--danger-dim);border:1px solid rgba(224,92,92,.3);border-radius:var(--radius-sm);color:var(--danger);font-size:13px;font-weight:600;cursor:pointer;font-family:var(--font-sans);transition:background .2s;}
.btn-reject-pay:hover{background:rgba(224,92,92,.22);}
.pending-badge{background:rgba(232,168,77,.15);border:1px solid rgba(232,168,77,.3);color:var(--warn);font-size:11px;font-weight:700;padding:3px 10px;border-radius:99px;}
.paid-badge{background:var(--success-dim);border:1px solid rgba(76,175,130,.3);color:var(--success);font-size:11px;font-weight:700;padding:3px 10px;border-radius:99px;}
.overdue-badge{background:var(--danger-dim);border:1px solid rgba(224,92,92,.3);color:var(--danger);font-size:11px;font-weight:700;padding:3px 10px;border-radius:99px;}
.rejected-badge{background:rgba(90,99,128,.2);border:1px solid rgba(90,99,128,.3);color:var(--muted);font-size:11px;font-weight:700;padding:3px 10px;border-radius:99px;}
.view-tabs{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;}
.view-tab{padding:8px 18px;background:var(--panel);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text-mid);font-size:13px;font-weight:500;cursor:pointer;transition:all .2s;text-decoration:none;}
.view-tab.active{background:var(--accent-dim);border-color:var(--accent);color:var(--accent);}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.65);display:none;align-items:center;justify-content:center;padding:20px;}
.modal-overlay.active{display:flex;}
.modal{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);width:100%;max-width:480px;box-shadow:0 24px 48px rgba(0,0,0,.5);max-height:90vh;overflow-y:auto;}
.modal-header{display:flex;align-items:center;justify-content:space-between;padding:20px 24px 16px;border-bottom:1px solid var(--border);}
.modal-title{font-family:var(--font-serif);font-size:19px;}
.modal-close{width:30px;height:30px;display:grid;place-items:center;background:none;border:1px solid var(--border);border-radius:var(--radius-sm);cursor:pointer;font-size:16px;color:var(--muted);}
.modal-body{padding:20px 24px;}
.modal-footer{display:flex;gap:10px;justify-content:flex-end;padding:14px 24px;border-top:1px solid var(--border);}
.form-field{display:flex;flex-direction:column;gap:6px;margin-bottom:14px;}
.form-field label{font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);}
.form-field input,.form-field select,.form-field textarea{background:var(--panel-raised);border:1.5px solid var(--border);border-radius:var(--radius-sm);padding:9px 12px;font-size:14px;color:var(--text);font-family:inherit;outline:none;transition:border-color .2s;width:100%;}
.form-field input:focus,.form-field select:focus,.form-field textarea:focus{border-color:var(--accent);}
.form-grid-2{display:grid;grid-template-columns:1fr 1fr;gap:12px;}
.empty-state{text-align:center;padding:48px;color:var(--muted);}
.empty-state .icon{font-size:36px;opacity:.3;margin-bottom:12px;}
</style>
</head>
<body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <button class="icon-btn hamburger" onclick="openSidebar()">☰</button>
    <div class="topbar-left"><h2>Payments</h2><p>Review and confirm tenant payment requests</p></div>
  </div>
  <div class="topbar-actions">
    <button class="btn-primary" onclick="openModal('addPaymentModal')" style="margin-right:6px;">➕ Record Payment</button>
    <form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form>
  </div>
</header>
<div class="content">
<?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>" style="margin-bottom:20px;"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div><?php endif; ?>

<div class="stats-grid">
  <div class="stat-card"><div class="stat-icon gold">💰</div><div class="stat-body"><div class="stat-label">Revenue This Month</div><div class="stat-value">₱<?= number_format($summary['month_rev'],2) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon warn">⏳</div><div class="stat-body"><div class="stat-label">Pending</div><div class="stat-value"><?= $summary['pending_cnt'] ?></div><div class="stat-sub">₱<?= number_format($summary['pending_amt'],2) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon red">⚠️</div><div class="stat-body"><div class="stat-label">Overdue</div><div class="stat-value"><?= $summary['overdue_cnt'] ?></div></div></div>
  <div class="stat-card"><div class="stat-icon green">✅</div><div class="stat-body"><div class="stat-label">Paid</div><div class="stat-value"><?= $summary['paid_cnt'] ?></div></div></div>
</div>

<div class="view-tabs">
  <a href="?status=pending"  class="view-tab <?= $filterStatus==='pending'?'active':'' ?>">⏳ Pending <?php if((int)$summary['pending_cnt']>0): ?><span style="background:var(--warn);color:#fff;font-size:10px;padding:1px 6px;border-radius:99px;margin-left:4px;"><?= $summary['pending_cnt'] ?></span><?php endif; ?></a>
  <a href="?status=overdue"  class="view-tab <?= $filterStatus==='overdue'?'active':'' ?>">⚠️ Overdue</a>
  <a href="?status=paid"     class="view-tab <?= $filterStatus==='paid'?'active':'' ?>">✅ Paid</a>
  <a href="?status=rejected" class="view-tab <?= $filterStatus==='rejected'?'active':'' ?>">❌ Rejected <?php if((int)($summary['rejected_cnt']??0)>0): ?><span style="background:var(--muted);color:#fff;font-size:10px;padding:1px 6px;border-radius:99px;margin-left:4px;"><?= $summary['rejected_cnt'] ?></span><?php endif; ?></a>
  <a href="?"                class="view-tab <?= $filterStatus===''?'active':'' ?>">All</a>
</div>

<div class="panel" style="margin-bottom:18px;">
  <form method="GET" class="filter-row">
    <input type="hidden" name="status" value="<?= htmlspecialchars($filterStatus,ENT_QUOTES,'UTF-8') ?>">
    <input type="text" name="q" class="form-input" placeholder="Search tenant or room…" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:280px;">
    <button type="submit" class="btn-secondary">Search</button>
    <a href="?status=<?= urlencode($filterStatus) ?>" class="btn-ghost">Clear</a>
  </form>
</div>

<?php if (empty($payments)): ?>
<div class="panel"><div class="empty-state"><div class="icon">🧾</div>No <?= htmlspecialchars($filterStatus ?: 'payment', ENT_QUOTES, 'UTF-8') ?> records found.</div></div>
<?php else: ?>
<div style="display:flex;flex-direction:column;gap:12px;">
<?php foreach($payments as $p):
  $badgeClass = match($p['status']) {
      'paid'     => 'paid-badge',
      'overdue'  => 'overdue-badge',
      'rejected' => 'rejected-badge',
      default    => 'pending-badge',
  };
  $isOverdue = $p['status']==='pending' && $p['due_date'] && strtotime($p['due_date']) < time();
?>
<div class="receipt-card">
  <div class="receipt-header">
    <div>
      <div class="receipt-name"><?= htmlspecialchars($p['tenant_name']??'Unknown',ENT_QUOTES,'UTF-8') ?></div>
      <div class="receipt-room">Room <?= htmlspecialchars($p['room_number']??'—',ENT_QUOTES,'UTF-8') ?> &nbsp;·&nbsp; Submitted <?= date('M j, Y g:i A',strtotime($p['created_at'])) ?></div>
    </div>
    <div style="text-align:right;">
      <div class="receipt-amount">₱<?= number_format($p['amount'],2) ?></div>
      <div style="margin-top:6px;"><span class="<?= $badgeClass ?>"><?= $isOverdue ? 'OVERDUE' : strtoupper($p['status']) ?></span></div>
    </div>
  </div>
  <div class="receipt-meta">
    <div class="meta-item"><span class="meta-key">Due Date</span><span class="meta-val" <?= $isOverdue?'style="color:var(--danger)"':'' ?>><?= $p['due_date']?date('M j, Y',strtotime($p['due_date'])):'—' ?></span></div>
    <div class="meta-item"><span class="meta-key">Method</span><span class="meta-val"><?= htmlspecialchars($p['payment_method']??'—',ENT_QUOTES,'UTF-8') ?></span></div>
    <div class="meta-item"><span class="meta-key">Confirmed On</span><span class="meta-val"><?= $p['paid_at']?date('M j, Y',strtotime($p['paid_at'])):'—' ?></span></div>
  </div>
  <?php if (!empty($p['admin_notes'])): ?>
  <div style="font-size:12px;color:var(--text-mid);background:var(--panel);border:1px solid var(--border);border-radius:var(--radius-sm);padding:8px 12px;margin-bottom:12px;">📝 <strong>Note:</strong> <?= htmlspecialchars($p['admin_notes'],ENT_QUOTES,'UTF-8') ?></div>
  <?php endif; ?>
  <?php if (!empty($p['proof_image'])): ?>
  <div style="margin-bottom:14px;">
    <div style="font-size:10px;text-transform:uppercase;letter-spacing:.07em;color:var(--muted);margin-bottom:6px;">📸 Payment Proof</div>
    <img src="../uploads/payment_proofs/<?= htmlspecialchars($p['proof_image'],ENT_QUOTES,'UTF-8') ?>"
         style="max-height:180px;max-width:320px;border-radius:8px;border:1px solid var(--border);cursor:zoom-in;object-fit:cover;display:block;"
         onclick="openProof(this.src, '<?= htmlspecialchars(addslashes($p['tenant_name']??''),ENT_QUOTES,'UTF-8') ?>', '<?= date('M j, Y g:i A',strtotime($p['created_at'])) ?>')"
         onerror="this.parentElement.style.display='none'">
    <div style="font-size:11px;color:var(--muted);margin-top:4px;">🔍 Click image to view full size</div>
  </div>
  <?php endif; ?>
  <div class="receipt-actions">
    <?php if ($p['status'] === 'pending' || $p['status'] === 'rejected'): ?>
    <button class="btn-accept"     onclick="openAccept(<?= $p['id'] ?>,'<?= htmlspecialchars(addslashes($p['tenant_name']??''),ENT_QUOTES,'UTF-8') ?>','<?= number_format($p['amount'],2) ?>')">✅ Accept</button>
    <?php endif; ?>
    <?php if ($p['status'] === 'pending'): ?>
    <button class="btn-reject-pay" onclick="openReject(<?= $p['id'] ?>,'<?= htmlspecialchars(addslashes($p['tenant_name']??''),ENT_QUOTES,'UTF-8') ?>')">❌ Reject</button>
    <?php endif; ?>
    <?php if ($p['status'] !== 'paid'): ?>
    <button class="tbl-btn" onclick="openEdit(<?= $p['id'] ?>,<?= $p['amount'] ?>,'<?= $p['due_date'] ?>','<?= htmlspecialchars(addslashes($p['payment_method']??'Cash'),ENT_QUOTES,'UTF-8') ?>','<?= $p['status'] ?>','<?= $p['paid_at']??'' ?>','<?= htmlspecialchars(addslashes($p['admin_notes']??''),ENT_QUOTES,'UTF-8') ?>')">✏️ Edit</button>
    <form method="POST" style="margin-left:auto;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button type="submit" class="tbl-btn" onclick="return confirm('Delete this payment?')" style="color:var(--muted)">🗑</button></form>
    <?php else: ?>
    <span style="font-size:12px;color:var(--success);display:flex;align-items:center;gap:5px;margin-left:auto;">🔒 Locked — payment confirmed</span>
    <?php endif; ?>
  </div>
</div>
<?php endforeach; ?>
</div>
<?php if ($pages>1): ?><div class="pagination" style="margin-top:16px;"><?php for($i=1;$i<=$pages;$i++): ?><a href="?page=<?=$i?>&status=<?=urlencode($filterStatus)?>&q=<?=urlencode($search)?>" class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?>
<?php endif; ?>
</div></div>

<!-- PROOF LIGHTBOX MODAL -->
<div class="modal-overlay" id="proofModal" style="align-items:center;justify-content:center;padding:20px;">
  <div style="background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);width:100%;max-width:700px;max-height:92vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 32px 64px rgba(0,0,0,.7);">
    <!-- Header -->
    <div style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--border);flex-shrink:0;">
      <div>
        <div style="font-family:var(--font-serif);font-size:17px;color:var(--text);">📸 Payment Proof</div>
        <div style="font-size:12px;color:var(--muted);margin-top:2px;" id="proof_meta"></div>
      </div>
      <div style="display:flex;gap:8px;align-items:center;">
        <a id="proof_download" href="#" target="_blank" style="padding:7px 14px;background:var(--accent-dim);border:1px solid var(--accent);border-radius:var(--radius-sm);color:var(--accent);font-size:12px;font-weight:600;text-decoration:none;">🔗 Open Full Size</a>
        <button onclick="closeModal('proofModal')" style="padding:7px 14px;background:var(--danger-dim);border:1px solid rgba(224,92,92,.3);border-radius:var(--radius-sm);color:var(--danger);font-size:12px;font-weight:600;cursor:pointer;font-family:var(--font-sans);">✕ Close</button>
      </div>
    </div>
    <!-- Image -->
    <div style="flex:1;overflow:auto;display:flex;align-items:center;justify-content:center;padding:20px;background:#050810;">
      <img id="proof_img" src="" style="max-width:100%;max-height:70vh;border-radius:8px;object-fit:contain;display:block;" alt="Payment proof">
    </div>
    <!-- Footer -->
    <div style="padding:12px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;flex-shrink:0;">
      <button onclick="closeModal('proofModal')" style="padding:8px 24px;background:var(--panel-raised);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text-mid);font-size:13px;font-weight:600;cursor:pointer;font-family:var(--font-sans);">← Back</button>
    </div>
  </div>
</div>


<!-- ACCEPT MODAL -->
<div class="modal-overlay" id="acceptModal"><div class="modal">
  <div class="modal-header"><span class="modal-title">✅ Accept Payment</span><button class="modal-close" onclick="closeModal('acceptModal')">✕</button></div>
  <form method="POST"><div class="modal-body">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="accept"><input type="hidden" name="id" id="accept_id">
    <p style="color:var(--text-mid);font-size:13.5px;margin-bottom:16px;">Confirming <strong id="accept_amount" style="color:var(--accent)"></strong> from <strong id="accept_name" style="color:var(--text)"></strong>.</p>
    <div class="form-field"><label>Admin Note (optional)</label><textarea name="admin_notes" rows="2" placeholder="e.g. Received in person, GCash confirmed…"></textarea></div>
  </div>
  <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('acceptModal')">Cancel</button><button type="submit" class="btn-accept">✅ Confirm Paid</button></div></form>
</div></div>

<!-- REJECT MODAL -->
<div class="modal-overlay" id="rejectModal"><div class="modal">
  <div class="modal-header"><span class="modal-title">❌ Reject Payment</span><button class="modal-close" onclick="closeModal('rejectModal')">✕</button></div>
  <form method="POST"><div class="modal-body">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="reject"><input type="hidden" name="id" id="reject_id">
    <p style="color:var(--text-mid);font-size:13.5px;margin-bottom:16px;">Rejecting from <strong id="reject_name" style="color:var(--text)"></strong>. The tenant will be notified and can resubmit.</p>
    <div class="form-field"><label>Reason (tenant will see this)</label><textarea name="admin_notes" rows="2" placeholder="e.g. Incorrect amount, wrong reference…"></textarea></div>
  </div>
  <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('rejectModal')">Cancel</button><button type="submit" class="btn-reject-pay">❌ Reject</button></div></form>
</div></div>

<!-- ADD PAYMENT MODAL -->
<div class="modal-overlay" id="addPaymentModal"><div class="modal" style="max-width:520px;">
  <div class="modal-header"><span class="modal-title">➕ Record Payment</span><button class="modal-close" onclick="closeModal('addPaymentModal')">✕</button></div>
  <form method="POST"><div class="modal-body">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="add_payment">
    <div class="form-field"><label>Tenant *</label>
      <select name="tenant_id" id="add_tenant" onchange="fillRentAmount(this)" required>
        <option value="">— Select Tenant —</option>
        <?php foreach($tenants as $t): ?>
        <option value="<?= $t['id'] ?>" data-rent="<?= $t['monthly_rent'] ?>">
          <?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?> — Room <?= htmlspecialchars($t['room_number'],ENT_QUOTES,'UTF-8') ?>
          <?php if ($t['monthly_rent']): ?>(₱<?= number_format($t['monthly_rent'],2) ?>)<?php endif; ?>
        </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-grid-2">
      <div class="form-field"><label>Amount (₱) *</label><input type="number" name="amount" id="add_amount" step="0.01" min="1" placeholder="e.g. 3500.00" required></div>
      <div class="form-field"><label>Due Date *</label><input type="date" name="due_date" value="<?= date('Y-m-d') ?>" required></div>
      <div class="form-field"><label>Method</label><select name="payment_method"><option>Cash</option><option>GCash</option><option>Maya</option><option>Bank Transfer</option><option>Online</option></select></div>
      <div class="form-field"><label>Status</label><select name="pay_status"><option value="paid">Paid</option><option value="pending">Pending</option><option value="overdue">Overdue</option></select></div>
    </div>
    <div class="form-field"><label>Admin Note</label><textarea name="admin_notes" rows="2" placeholder="e.g. Received in person…"></textarea></div>
  </div>
  <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('addPaymentModal')">Cancel</button><button type="submit" class="btn-primary" style="width:auto;padding:9px 20px;margin-top:0;">Record</button></div></form>
</div></div>

<!-- EDIT PAYMENT MODAL -->
<div class="modal-overlay" id="editPaymentModal"><div class="modal" style="max-width:520px;">
  <div class="modal-header"><span class="modal-title">✏️ Edit Payment</span><button class="modal-close" onclick="closeModal('editPaymentModal')">✕</button></div>
  <form method="POST"><div class="modal-body">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="edit_payment"><input type="hidden" name="id" id="edit_id">
    <div class="form-grid-2">
      <div class="form-field"><label>Amount (₱)</label><input type="number" name="amount" id="edit_amount" step="0.01" min="1" required></div>
      <div class="form-field"><label>Due Date</label><input type="date" name="due_date" id="edit_due"></div>
      <div class="form-field"><label>Method</label><select name="payment_method" id="edit_method"><option>Cash</option><option>GCash</option><option>Maya</option><option>Bank Transfer</option><option>Online</option></select></div>
      <div class="form-field"><label>Status</label><select name="pay_status" id="edit_status"><option value="paid">Paid</option><option value="pending">Pending</option><option value="overdue">Overdue</option><option value="rejected">Rejected</option></select></div>
      <div class="form-field"><label>Payment Date</label><input type="date" name="payment_date" id="edit_paydate"></div>
    </div>
    <div class="form-field"><label>Admin Note</label><textarea name="admin_notes" id="edit_notes" rows="2"></textarea></div>
  </div>
  <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('editPaymentModal')">Cancel</button><button type="submit" class="btn-primary" style="width:auto;padding:9px 20px;margin-top:0;">Save</button></div></form>
</div></div>


<script>
function openModal(id){var el=document.getElementById(id);el.style.display='flex';el.classList.add('active');}
function closeModal(id){var el=document.getElementById(id);el.style.display='';el.classList.remove('active');}
function openAccept(id,name,amount){document.getElementById('accept_id').value=id;document.getElementById('accept_name').textContent=name;document.getElementById('accept_amount').textContent='₱'+amount;openModal('acceptModal');}
function openReject(id,name){document.getElementById('reject_id').value=id;document.getElementById('reject_name').textContent=name;openModal('rejectModal');}
function openEdit(id,amount,dueDate,method,status,paidAt,notes){
  document.getElementById('edit_id').value=id;
  document.getElementById('edit_amount').value=amount;
  document.getElementById('edit_due').value=dueDate;
  document.getElementById('edit_method').value=method;
  document.getElementById('edit_status').value=status;
  document.getElementById('edit_paydate').value=paidAt?paidAt.substring(0,10):'';
  document.getElementById('edit_notes').value=notes;
  openModal('editPaymentModal');
}
function fillRentAmount(sel){var opt=sel.options[sel.selectedIndex];if(opt.dataset.rent)document.getElementById('add_amount').value=opt.dataset.rent;}
document.querySelectorAll('.modal-overlay').forEach(function(o){o.addEventListener('click',function(e){if(e.target===o)closeModal(o.id);});});
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
function openProof(src, tenant, date) {
    document.getElementById('proof_img').src = src;
    document.getElementById('proof_download').href = src;
    document.getElementById('proof_meta').textContent = tenant + '  ·  ' + date;
    openModal('proofModal');
}
</script>
</body></html>