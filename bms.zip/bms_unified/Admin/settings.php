<?php
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf        = $_SESSION['csrf_token'];
$adminId     = (int)$_SESSION['admin_id'];
$pdo         = getDBConnection();
$isSuperAdmin = ($_SESSION['admin_role'] ?? '') === 'super_admin';

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// ── Handle POST ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';

    // Remember which tab to return to after redirect
    $tabMap = [
        'update_profile'   => 'profile',
        'change_password'  => 'password',
        'generate_invoices'=> 'tools',
        'expire_contracts' => 'tools',
        'clear_old_logs'   => 'danger',
    ];
    $_SESSION['_settings_tab'] = $tabMap[$act] ?? ($_POST['_tab'] ?? 'profile');

    // Change own password
    if ($act === 'change_password') {
        $current  = $_POST['current_password'] ?? '';
        $new      = $_POST['new_password']     ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        $me = db_fetch_one($pdo, "SELECT * FROM admin_users WHERE id=?", [$adminId]);

        if (!password_verify($current, $me['password'])) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Current password is incorrect.'];
        } elseif (strlen($new) < 8) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'New password must be at least 8 characters.'];
        } elseif ($new !== $confirm) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'New passwords do not match.'];
        } else {
            $hash = password_hash($new, PASSWORD_BCRYPT);
            db_execute($pdo, "UPDATE admin_users SET password=? WHERE id=?", [$hash, $adminId]);
            db_audit($pdo, $adminId, 'CHANGE_PASSWORD', 'Admin changed their own password');
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Password updated successfully.'];
        }
    }

    // Update own profile
    elseif ($act === 'update_profile') {
        $fullName = trim($_POST['full_name'] ?? '');
        $email    = trim($_POST['email']     ?? '');
        if (!$fullName || !$email) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Name and email are required.'];
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Invalid email address.'];
        } else {
            // Check email not taken by another user
            $taken = db_fetch_one($pdo, "SELECT id FROM admin_users WHERE email=? AND id!=?", [$email, $adminId]);
            if ($taken) {
                $_SESSION['flash'] = ['type'=>'error','msg'=>'Email already in use by another account.'];
            } else {
                db_execute($pdo, "UPDATE admin_users SET full_name=?, email=? WHERE id=?", [$fullName, $email, $adminId]);
                $_SESSION['admin_name'] = $fullName;
                db_audit($pdo, $adminId, 'UPDATE_PROFILE', "Updated profile: {$fullName}");
                $_SESSION['flash'] = ['type'=>'success','msg'=>'Profile updated.'];
            }
        }
    }

    // Expire all contracts (super admin only)
    elseif ($act === 'expire_contracts' && $isSuperAdmin) {
        $count = db_auto_expire_contracts($pdo);
        db_audit($pdo, $adminId, 'EXPIRE_CONTRACTS', "Manually expired {$count} contract(s)");
        $_SESSION['flash'] = ['type'=>'success','msg'=>"Expired {$count} contract(s)."];
    }

    // Generate monthly invoices (super admin only)
    elseif ($act === 'generate_invoices' && $isSuperAdmin) {
        $count = db_generate_monthly_invoices($pdo, (int)date('n'), (int)date('Y'));
        db_audit($pdo, $adminId, 'GENERATE_INVOICES', "Generated {$count} invoice(s) for ".date('F Y'));
        $_SESSION['flash'] = ['type'=>'success','msg'=>"Generated {$count} invoice(s) for ".date('F Y')."."];
    }

    // Clear audit logs older than 90 days (super admin only)
    elseif ($act === 'clear_old_logs' && $isSuperAdmin) {
        $count = db_execute($pdo, "DELETE FROM audit_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)");
        db_audit($pdo, $adminId, 'CLEAR_AUDIT_LOGS', "Cleared {$count} audit log entries older than 90 days");
        $_SESSION['flash'] = ['type'=>'success','msg'=>"Cleared {$count} old audit log entries."];
    }

    header('Location: settings.php'); exit;
}

// ── Fetch current admin info ──────────────────────────────────
$me       = db_fetch_one($pdo, "SELECT id,username,email,full_name,role,last_login,created_at FROM admin_users WHERE id=?", [$adminId]);
$navStats = db_nav_stats($pdo);
$activeNav = 'settings';

// ── System stats ─────────────────────────────────────────────
$totalTenants    = (int)db_scalar($pdo, "SELECT COUNT(*) FROM tenants WHERE status='active'");
$totalRooms      = (int)db_scalar($pdo, "SELECT COUNT(*) FROM rooms");
$totalPayments   = (int)db_scalar($pdo, "SELECT COUNT(*) FROM payments");
$totalMaint      = (int)db_scalar($pdo, "SELECT COUNT(*) FROM maintenance_requests");
$totalAuditLogs  = (int)db_scalar($pdo, "SELECT COUNT(*) FROM audit_logs");
$dbVersion       = db_scalar($pdo, "SELECT VERSION()");
$oldLogs         = (int)db_scalar($pdo, "SELECT COUNT(*) FROM audit_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Settings — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
<style>
.settings-grid { display: grid; grid-template-columns: 260px 1fr; gap: 24px; align-items: start; }
.settings-nav  { display: flex; flex-direction: column; gap: 4px; position: sticky; top: 24px; }
.settings-nav-item {
    display: flex; align-items: center; gap: 10px;
    padding: 10px 14px; border-radius: var(--radius-sm);
    font-size: 13.5px; font-weight: 500; color: var(--text-mid);
    cursor: pointer; border: none; background: transparent;
    text-align: left; width: 100%; transition: background var(--trans), color var(--trans);
}
.settings-nav-item:hover  { background: rgba(255,255,255,.04); color: var(--text); }
.settings-nav-item.active { background: var(--accent-dim); color: var(--accent); }
.settings-nav-item.active::before { display: none; }
.settings-section { display: none; }
.settings-section.active { display: flex; flex-direction: column; gap: 20px; }
.settings-card {
    background: var(--panel); border: 1px solid var(--border);
    border-radius: var(--radius); overflow: hidden;
}
.settings-card-header {
    padding: 18px 24px; border-bottom: 1px solid var(--border);
    display: flex; align-items: center; gap: 12px;
}
.settings-card-icon {
    width: 36px; height: 36px; border-radius: 9px;
    display: grid; place-items: center; font-size: 17px; flex-shrink: 0;
}
.settings-card-header h3 { font-family: var(--font-serif); font-size: 16px; font-weight: 400; color: var(--text); }
.settings-card-header p  { font-size: 12px; color: var(--muted); margin-top: 2px; }
.settings-card-body { padding: 22px 24px; }
.settings-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.settings-form-grid .field-full { grid-column: 1 / -1; }
.info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
.info-item {
    padding: 14px 16px; background: rgba(255,255,255,.02);
    border: 1px solid var(--border); border-radius: var(--radius-sm);
}
.info-item-label { font-size: 10.5px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: .08em; margin-bottom: 5px; }
.info-item-value { font-size: 14px; color: var(--text); font-weight: 500; }
.info-item-value.accent { color: var(--accent); }
.info-item-value.success { color: var(--success); }
.info-item-value.danger  { color: var(--danger); }
.danger-zone { border-color: rgba(224,92,92,.25) !important; }
.danger-zone .settings-card-header { border-bottom-color: rgba(224,92,92,.15); background: rgba(224,92,92,.04); }
.action-row {
    display: flex; align-items: center; justify-content: space-between;
    padding: 14px 0; border-bottom: 1px solid var(--border);
}
.action-row:last-child { border-bottom: none; padding-bottom: 0; }
.action-row:first-child { padding-top: 0; }
.action-info h4 { font-size: 13.5px; font-weight: 600; color: var(--text); margin-bottom: 3px; }
.action-info p  { font-size: 12px; color: var(--muted); }
.badge-role { display: inline-flex; align-items: center; gap: 6px; padding: 4px 12px; border-radius: 99px; font-size: 12px; font-weight: 600; }
.pw-strength { height: 3px; border-radius: 99px; margin-top: 6px; background: var(--border); overflow: hidden; }
.pw-strength-fill { height: 100%; border-radius: 99px; transition: width .3s, background .3s; width: 0%; }
.session-info { display: flex; align-items: center; gap: 8px; padding: 10px 14px; background: var(--success-dim); border: 1px solid rgba(76,175,130,.2); border-radius: var(--radius-sm); font-size: 12.5px; color: var(--success); margin-bottom: 16px; }
@media(max-width:900px) {
    .settings-grid { grid-template-columns: 1fr; }
    .settings-nav  { flex-direction: row; flex-wrap: wrap; position: static; }
    .settings-form-grid { grid-template-columns: 1fr; }
    .info-grid { grid-template-columns: 1fr; }
}
</style>
</head>
<body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
    <div style="display:flex;align-items:center;gap:14px;">
        <button class="icon-btn hamburger" onclick="openSidebar()">☰</button>
        <div class="topbar-left"><h2>Settings</h2><p>Account, system & preferences</p></div>
    </div>
    <div class="topbar-actions">
        <form method="POST" action="process.php" style="margin:0;">
            <input type="hidden" name="action" value="logout">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
            <button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button>
        </form>
    </div>
</header>

<div class="content">
<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div>
<?php endif; ?>

<div class="settings-grid">

    <!-- ── LEFT NAV ── -->
    <div>
        <div class="settings-nav panel" style="padding:12px;">
            <button class="settings-nav-item active" onclick="switchTab('profile',this)">
                <span>👤</span> My Profile
            </button>
            <button class="settings-nav-item" onclick="switchTab('password',this)">
                <span>🔒</span> Change Password
            </button>
            <button class="settings-nav-item" onclick="switchTab('system',this)">
                <span>🖥️</span> System Info
            </button>
            <?php if ($isSuperAdmin): ?>
            <button class="settings-nav-item" onclick="switchTab('tools',this)">
                <span>⚙️</span> Admin Tools
            </button>
            <button class="settings-nav-item" onclick="switchTab('danger',this)">
                <span>⚠️</span> Danger Zone
            </button>
            <?php endif; ?>
        </div>

        <!-- Session card -->
        <div class="panel" style="margin-top:16px;padding:16px 18px;">
            <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:12px;">Current Session</div>
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;">
                <div class="admin-avatar"><?= strtoupper(substr($me['full_name'],0,1)) ?></div>
                <div>
                    <div style="font-size:13px;font-weight:600;color:var(--text)"><?= htmlspecialchars($me['full_name'],ENT_QUOTES,'UTF-8') ?></div>
                    <div style="font-size:11px;color:var(--muted)"><?= htmlspecialchars($me['email'],ENT_QUOTES,'UTF-8') ?></div>
                </div>
            </div>
            <span class="badge <?= $me['role']==='super_admin'?'badge-gold':'badge-blue' ?>"><?= str_replace('_',' ',ucwords($me['role'])) ?></span>
            <div style="margin-top:12px;font-size:11.5px;color:var(--muted);">
                Member since <?= date('M Y', strtotime($me['created_at'])) ?>
            </div>
        </div>
    </div>

    <!-- ── RIGHT CONTENT ── -->
    <div>

        <!-- ════ PROFILE TAB ════ -->
        <div class="settings-section active" id="tab-profile">
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="settings-card-icon" style="background:var(--blue-dim)">👤</div>
                    <div><h3>Profile Information</h3><p>Update your name and email address</p></div>
                </div>
                <div class="settings-card-body">
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
                        <input type="hidden" name="act" value="update_profile">
                        <div class="settings-form-grid">
                            <div class="field">
                                <label>Full Name</label>
                                <input type="text" name="full_name" class="form-input" required
                                    value="<?= htmlspecialchars($me['full_name'],ENT_QUOTES,'UTF-8') ?>">
                            </div>
                            <div class="field">
                                <label>Username</label>
                                <input type="text" class="form-input" value="<?= htmlspecialchars($me['username'],ENT_QUOTES,'UTF-8') ?>" disabled style="opacity:.5;cursor:not-allowed;">
                            </div>
                            <div class="field field-full">
                                <label>Email Address</label>
                                <input type="email" name="email" class="form-input" required
                                    value="<?= htmlspecialchars($me['email'],ENT_QUOTES,'UTF-8') ?>">
                            </div>
                            <div class="field">
                                <label>Role</label>
                                <input type="text" class="form-input" value="<?= str_replace('_',' ',ucwords($me['role'])) ?>" disabled style="opacity:.5;cursor:not-allowed;">
                            </div>
                            <div class="field">
                                <label>Last Login</label>
                                <input type="text" class="form-input" value="<?= $me['last_login'] ? date('M j, Y H:i', strtotime($me['last_login'])) : 'N/A' ?>" disabled style="opacity:.5;cursor:not-allowed;">
                            </div>
                        </div>
                        <div style="margin-top:20px;display:flex;justify-content:flex-end;">
                            <button type="submit" class="btn-primary">Save Profile</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- ════ PASSWORD TAB ════ -->
        <div class="settings-section" id="tab-password">
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="settings-card-icon" style="background:var(--warn-dim)">🔒</div>
                    <div><h3>Change Password</h3><p>Update your account password</p></div>
                </div>
                <div class="settings-card-body">
                    <div class="session-info">🛡️ You are changing the password for <strong style="margin:0 4px"><?= htmlspecialchars($me['username'],ENT_QUOTES,'UTF-8') ?></strong>. You will stay logged in after the change.</div>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
                        <input type="hidden" name="act" value="change_password">
                        <div style="display:flex;flex-direction:column;gap:16px;max-width:400px;">
                            <div class="field">
                                <label>Current Password</label>
                                <input type="password" name="current_password" id="cur_pw" class="form-input" required autocomplete="current-password">
                            </div>
                            <div class="field">
                                <label>New Password</label>
                                <input type="password" name="new_password" id="new_pw" class="form-input" required minlength="8" autocomplete="new-password" oninput="checkStrength(this.value)">
                                <div class="pw-strength"><div class="pw-strength-fill" id="pw_bar"></div></div>
                                <div style="font-size:11px;color:var(--muted);margin-top:2px" id="pw_hint">Minimum 8 characters</div>
                            </div>
                            <div class="field">
                                <label>Confirm New Password</label>
                                <input type="password" name="confirm_password" id="conf_pw" class="form-input" required autocomplete="new-password" oninput="checkMatch()">
                                <div style="font-size:11px;margin-top:2px;display:none" id="match_msg"></div>
                            </div>
                        </div>
                        <div style="margin-top:20px;display:flex;justify-content:flex-end;">
                            <button type="submit" class="btn-primary">Update Password</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- ════ SYSTEM INFO TAB ════ -->
        <div class="settings-section" id="tab-system">
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="settings-card-icon" style="background:var(--success-dim)">🖥️</div>
                    <div><h3>System Information</h3><p>Server environment and database statistics</p></div>
                </div>
                <div class="settings-card-body">
                    <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:12px;">Environment</div>
                    <div class="info-grid" style="margin-bottom:20px;">
                        <div class="info-item">
                            <div class="info-item-label">PHP Version</div>
                            <div class="info-item-value accent"><?= phpversion() ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">MySQL Version</div>
                            <div class="info-item-value accent"><?= htmlspecialchars($dbVersion,ENT_QUOTES,'UTF-8') ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Database</div>
                            <div class="info-item-value">bms_unified</div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Server Time</div>
                            <div class="info-item-value"><?= date('M j, Y H:i:s') ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Server Software</div>
                            <div class="info-item-value" style="font-size:12px;"><?= htmlspecialchars($_SERVER['SERVER_SOFTWARE'] ?? 'N/A',ENT_QUOTES,'UTF-8') ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Session Status</div>
                            <div class="info-item-value success">● Active</div>
                        </div>
                    </div>
                    <div style="font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:12px;">Database Records</div>
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-item-label">Active Tenants</div>
                            <div class="info-item-value"><?= number_format($totalTenants) ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Total Rooms</div>
                            <div class="info-item-value"><?= number_format($totalRooms) ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Payment Records</div>
                            <div class="info-item-value"><?= number_format($totalPayments) ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Maintenance Requests</div>
                            <div class="info-item-value"><?= number_format($totalMaint) ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Audit Log Entries</div>
                            <div class="info-item-value"><?= number_format($totalAuditLogs) ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-item-label">Old Logs (&gt;90 days)</div>
                            <div class="info-item-value <?= $oldLogs>0?'danger':'' ?>"><?= number_format($oldLogs) ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($isSuperAdmin): ?>

        <!-- ════ ADMIN TOOLS TAB ════ -->
        <div class="settings-section" id="tab-tools">
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="settings-card-icon" style="background:var(--accent-dim)">⚙️</div>
                    <div><h3>Admin Tools</h3><p>System maintenance and automation tasks</p></div>
                </div>
                <div class="settings-card-body">
                    <div class="action-row">
                        <div class="action-info">
                            <h4>Generate Monthly Invoices</h4>
                            <p>Create pending rent invoices for all active tenants for <?= date('F Y') ?>. Skips already-created invoices.</p>
                        </div>
                        <form method="POST" style="margin:0;">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
                            <input type="hidden" name="act" value="generate_invoices">
                            <button type="submit" class="btn-primary" onclick="return confirm('Generate invoices for <?= date('F Y') ?>?')">⚡ Generate</button>
                        </form>
                    </div>
                    <div class="action-row">
                        <div class="action-info">
                            <h4>Expire Past Contracts</h4>
                            <p>Automatically mark contracts past their end date as expired. This runs on every page load in contracts.php too.</p>
                        </div>
                        <form method="POST" style="margin:0;">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
                            <input type="hidden" name="act" value="expire_contracts">
                            <button type="submit" class="btn-secondary" onclick="return confirm('Expire all past contracts now?')">⌛ Run Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- ════ DANGER ZONE TAB ════ -->
        <div class="settings-section" id="tab-danger">
            <div class="settings-card danger-zone">
                <div class="settings-card-header">
                    <div class="settings-card-icon" style="background:var(--danger-dim)">⚠️</div>
                    <div><h3>Danger Zone</h3><p>Irreversible actions — proceed with caution</p></div>
                </div>
                <div class="settings-card-body">
                    <div class="action-row">
                        <div class="action-info">
                            <h4>Clear Old Audit Logs</h4>
                            <p>Permanently delete audit log entries older than 90 days.
                            <?php if ($oldLogs > 0): ?>
                                <strong style="color:var(--danger)"><?= number_format($oldLogs) ?> entries</strong> will be deleted.
                            <?php else: ?>
                                No entries older than 90 days found.
                            <?php endif; ?>
                            </p>
                        </div>
                        <form method="POST" style="margin:0;">
                            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
                            <input type="hidden" name="act" value="clear_old_logs">
                            <button type="submit" class="btn-danger" <?= $oldLogs===0?'disabled style="opacity:.4;cursor:not-allowed;"':'' ?>
                                onclick="return confirm('Permanently delete <?= number_format($oldLogs) ?> old audit log entries? This cannot be undone.')">
                                🗑 Clear Old Logs
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="panel" style="border-color:rgba(224,92,92,.15);background:rgba(224,92,92,.03);">
                <div style="display:flex;gap:12px;align-items:flex-start;">
                    <span style="font-size:20px;flex-shrink:0;margin-top:2px;">🛡️</span>
                    <div>
                        <div style="font-size:13.5px;font-weight:600;color:var(--text);margin-bottom:4px;">Data Safety Reminder</div>
                        <div style="font-size:12.5px;color:var(--text-mid);line-height:1.7;">
                            Always back up your database before running destructive operations.
                            Tenant records, payment history, and contracts are permanent and cannot be batch-deleted from this interface.
                            Use phpMyAdmin or a direct SQL client for full database management.
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </div><!-- /right -->
</div><!-- /settings-grid -->
</div><!-- /content -->
</div><!-- /main -->

<script>
const VALID_TABS = ['profile','password','system','tools','danger'];

function switchTab(name, btn) {
    if (!document.getElementById('tab-' + name)) return;
    document.querySelectorAll('.settings-section').forEach(s => s.classList.remove('active'));
    document.querySelectorAll('.settings-nav-item').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
    // Persist tab in URL hash without page reload
    history.replaceState(null, '', '#' + name);
}

// On page load: restore tab from hash, or from PHP flash hint, or default to profile
(function initTab() {
    const hash = location.hash.replace('#','');
    <?php
    // After a POST, hint which tab to restore based on the action
    $tabHint = 'profile';
    if (isset($_SESSION['_settings_tab'])) {
        $tabHint = $_SESSION['_settings_tab'];
        unset($_SESSION['_settings_tab']);
    }
    ?>
    const phpTab = '<?= htmlspecialchars($tabHint, ENT_QUOTES, 'UTF-8') ?>';
    const target = (hash && VALID_TABS.includes(hash)) ? hash : phpTab;
    const tabEl  = document.getElementById('tab-' + target);
    const btnEl  = document.querySelector('[onclick="switchTab(\'' + target + '\',this)"]');
    if (tabEl && btnEl) {
        document.querySelectorAll('.settings-section').forEach(s => s.classList.remove('active'));
        document.querySelectorAll('.settings-nav-item').forEach(b => b.classList.remove('active'));
        tabEl.classList.add('active');
        btnEl.classList.add('active');
    }
})();

// Store active tab in a hidden field before form submit so we can restore it after redirect
document.querySelectorAll('form').forEach(function(form) {
    form.addEventListener('submit', function() {
        const activeTab = location.hash.replace('#','') || 'profile';
        // Pass tab hint via hidden input
        const inp = document.createElement('input');
        inp.type  = 'hidden';
        inp.name  = '_tab';
        inp.value = activeTab;
        form.appendChild(inp);
    });
});

// Password strength checker
function checkStrength(val) {
    const bar  = document.getElementById('pw_bar');
    const hint = document.getElementById('pw_hint');
    let score  = 0;
    if (val.length >= 8)  score++;
    if (val.length >= 12) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    const colors = ['','#e05c5c','#e8a84d','#e8b86d','#4caf82','#4caf82'];
    const labels = ['','Very Weak','Weak','Fair','Strong','Very Strong'];
    bar.style.width      = (score * 20) + '%';
    bar.style.background = colors[score] || 'var(--border)';
    hint.textContent     = score > 0 ? labels[score] : 'Minimum 8 characters';
    hint.style.color     = colors[score] || 'var(--muted)';
}

// Password match checker
function checkMatch() {
    const np  = document.getElementById('new_pw').value;
    const cp  = document.getElementById('conf_pw').value;
    const msg = document.getElementById('match_msg');
    if (!cp) { msg.style.display='none'; return; }
    msg.style.display = 'block';
    if (np === cp) {
        msg.textContent = '✓ Passwords match';
        msg.style.color = 'var(--success)';
    } else {
        msg.textContent = '✗ Passwords do not match';
        msg.style.color = 'var(--danger)';
    }
}

// Mobile sidebar
function openSidebar()  { document.getElementById('sidebar').classList.add('open'); document.getElementById('overlay').classList.add('visible'); }
function closeSidebar() { document.getElementById('sidebar').classList.remove('open'); document.getElementById('overlay').classList.remove('visible'); }
</script>
</body>
</html>