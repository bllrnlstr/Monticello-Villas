<?php
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDBConnection();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';

    if ($act === 'add' || $act === 'edit') {
        $roomId    = ($_POST['room_id']    ?? '') ?: null;
        $fullName  = trim($_POST['full_name']  ?? '');
        $email     = trim($_POST['email']      ?? '') ?: null;
        $phone     = trim($_POST['contact_number'] ?? '') ?: null;
        $address   = trim($_POST['address']    ?? '') ?: null;
        $emContact = trim($_POST['emergency_contact_name']   ?? '') ?: null;
        $emPhone   = trim($_POST['emergency_contact_number'] ?? '') ?: null;
        $idType    = trim($_POST['id_type']    ?? '') ?: null;
        $idNumber  = trim($_POST['id_number']  ?? '') ?: null;
        $moveIn    = ($_POST['move_in_date']   ?? '') ?: null;
        $moveOut   = ($_POST['move_out_date']  ?? '') ?: null;
        $status    = $_POST['status'] ?? 'active';
        $notes     = trim($_POST['notes'] ?? '') ?: null;

        if ($fullName === '') {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Full name is required.'];
            header('Location: tenants.php'); exit;
        }

        if ($act === 'add') {
            $roomNumber = '';
            if ($roomId) {
                $rn = $pdo->prepare("SELECT room_number FROM rooms WHERE id=? LIMIT 1");
                $rn->execute([$roomId]);
                $roomNumber = $rn->fetchColumn() ?: '';
            }
            $pdo->prepare("INSERT INTO tenants
                (room_id,full_name,email,phone,address,emergency_contact,emergency_phone,
                 id_type,id_number,move_in_date,move_out_date,status,approval_status,notes,room_number,password_hash)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,'active','approved',?,?,'')
            ")->execute([$roomId,$fullName,$email,$phone,$address,$emContact,$emPhone,
                         $idType,$idNumber,$moveIn,$moveOut,$notes,$roomNumber]);
            if ($roomId) {
                $pdo->prepare("UPDATE rooms SET status='occupied' WHERE id=?")->execute([$roomId]);
            }
            db_audit_admin($pdo, $adminId, 'CREATE_TENANT', "Registered: {$fullName}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Tenant registered successfully.'];
        } else {
            $id = (int)$_POST['id'];
            $pdo->prepare("UPDATE tenants SET
                room_id=?,full_name=?,email=?,phone=?,address=?,
                emergency_contact=?,emergency_phone=?,id_type=?,id_number=?,
                move_in_date=?,move_out_date=?,status=?,notes=?
                WHERE id=?
            ")->execute([$roomId,$fullName,$email,$phone,$address,
                         $emContact,$emPhone,$idType,$idNumber,
                         $moveIn,$moveOut,$status,$notes,$id]);
            if ($roomId) {
                $pdo->prepare("UPDATE rooms SET status='occupied' WHERE id=?")->execute([$roomId]);
            }
            db_audit_admin($pdo, $adminId, 'UPDATE_TENANT', "Updated id={$id}: {$fullName}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Tenant updated.'];
        }
    } elseif ($act === 'delete') {
        $id  = (int)$_POST['id'];
        $row = $pdo->prepare("SELECT full_name FROM tenants WHERE id=?");
        $row->execute([$id]);
        $name = $row->fetchColumn() ?: $id;
        $pdo->prepare("DELETE FROM tenants WHERE id=?")->execute([$id]);
        db_audit_admin($pdo, $adminId, 'DELETE_TENANT', "Deleted: {$name}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Tenant removed.'];
    }
    header('Location: tenants.php'); exit;
}

// ── BUILD WHERE ───────────────────────────────────────────────
// NOTE: No approval_status filter here — we show ALL tenants in the list
// (pending-approval tenants registered from the tenant portal must still be visible).
// Approval filtering only happens in registrations.php.
$filterStatus = $_GET['status'] ?? '';
$search       = trim($_GET['q'] ?? '');
$page         = max(1, (int)($_GET['page'] ?? 1));
$perPage      = 15;

$conditions = [];
$params     = [];
if ($filterStatus !== '') {
    if ($filterStatus === 'active') {
        $conditions[] = "(t.status = 'active' OR t.status IS NULL)";
    } else {
        $conditions[] = 't.status = ?';
        $params[]     = $filterStatus;
    }
}
if ($search !== '') {
    $conditions[] = '(t.full_name LIKE ? OR t.email LIKE ? OR t.phone LIKE ? OR t.room_number LIKE ?)';
    $params[]     = "%{$search}%";
    $params[]     = "%{$search}%";
    $params[]     = "%{$search}%";
    $params[]     = "%{$search}%";
}
$whereSQL = $conditions ? 'WHERE ' . implode(' AND ', $conditions) : '';

// ── COUNT (no join to avoid issues) ───────────────────────────
$cntStmt = $pdo->prepare("SELECT COUNT(*) FROM tenants t {$whereSQL}");
$cntStmt->execute($params);
$total  = (int)$cntStmt->fetchColumn();
$pages  = max(1, (int)ceil($total / $perPage));
$offset = ($page - 1) * $perPage;

// ── LIST (explicit columns — no t.* to avoid shadowing) ───────
$listStmt = $pdo->prepare("
    SELECT
        t.id,
        t.room_id,
        t.full_name,
        t.email,
        t.phone,
        t.address,
        t.room_number,
        t.emergency_contact,
        t.emergency_phone,
        t.id_type,
        t.id_number,
        t.move_in_date,
        t.move_out_date,
        t.status,
        t.approval_status,
        t.notes,
        t.created_at,
        r.room_number AS assigned_room_number,
        r.room_type   AS assigned_room_type
    FROM tenants t
    LEFT JOIN rooms r ON r.id = t.room_id
    {$whereSQL}
    ORDER BY t.id DESC
    LIMIT {$perPage} OFFSET {$offset}
");
$listStmt->execute($params);
$tenants = $listStmt->fetchAll(PDO::FETCH_ASSOC);

// ── SUMMARY (by t.status not approval_status) ─────────────────
$sumRows      = $pdo->query("SELECT COALESCE(status,'active') AS status, COUNT(*) AS cnt FROM tenants GROUP BY COALESCE(status,'active')")->fetchAll(PDO::FETCH_ASSOC);
$totalTenants = (int)$pdo->query("SELECT COUNT(*) FROM tenants")->fetchColumn();
// BUG FIX: array_column MUST be assigned first — assigning _total before it was
// getting wiped out on the very next line, making the Total card always show 0.
$summary           = array_column($sumRows, 'cnt', 'status');
$summary['_total'] = $totalTenants;

// ── ROOMS for dropdowns ────────────────────────────────────────
$rooms = $pdo->query("SELECT id,room_number,room_type,monthly_rate,status FROM rooms ORDER BY room_number")->fetchAll(PDO::FETCH_ASSOC);

$navStats  = db_nav_stats($pdo);
$activeNav = 'tenants';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Tenants — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
<style>
body { overflow: auto !important; }
.main { overflow: visible !important; }
.modal-overlay { z-index: 9999 !important; }
</style>
</head>
<body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">

<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <button class="icon-btn hamburger" onclick="openSidebar()">☰</button>
    <div class="topbar-left"><h2>Tenants</h2><p>Manage all tenant records</p></div>
  </div>
  <div class="topbar-actions">
    <button class="btn-primary" onclick="openModal('addModal')">+ Register Tenant</button>
    <form method="POST" action="process.php" style="margin:0;">
      <input type="hidden" name="action" value="logout">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
      <button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button>
    </form>
  </div>
</header>

<div class="content">
<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div>
<?php endif; ?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);">
  <div class="stat-card"><div class="stat-icon blue">👥</div><div class="stat-body"><div class="stat-label">Total</div><div class="stat-value"><?= $summary['_total'] ?? array_sum($summary) ?></div></div></div>
  <div class="stat-card"><div class="stat-icon green">✅</div><div class="stat-body"><div class="stat-label">Active</div><div class="stat-value"><?= $summary['active'] ?? 0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon warn">⏳</div><div class="stat-body"><div class="stat-label">Pending</div><div class="stat-value"><?= $summary['pending'] ?? 0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon red">📤</div><div class="stat-body"><div class="stat-label">Moved Out</div><div class="stat-value"><?= $summary['moved_out'] ?? 0 ?></div></div></div>
</div>

<!-- Filters -->
<div class="panel" style="margin-bottom:20px;">
  <form method="GET" class="filter-row">
    <input type="text" name="q" class="form-input" placeholder="Search name, email, contact…"
           value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:260px;">
    <select name="status" class="form-input" style="max-width:160px;">
      <option value="">All Statuses</option>
      <?php foreach (['active','inactive','pending','moved_out'] as $s): ?>
      <option value="<?= $s ?>" <?= $filterStatus===$s?'selected':'' ?>><?= ucfirst(str_replace('_',' ',$s)) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn-secondary">Filter</button>
    <a href="tenants.php" class="btn-ghost">Clear</a>
  </form>
</div>

<!-- Table -->
<div class="panel">
  <div class="section-header">
    <span class="section-title">Tenant List <small style="color:var(--muted);font-size:13px;">(<?= $total ?>)</small></span>
  </div>
  <div class="table-wrap">
  <table>
    <thead>
      <tr><th>Name</th><th>Contact</th><th>Room</th><th>Move-In</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody>
    <?php if (empty($tenants)): ?>
      <tr class="empty-row"><td colspan="6">No tenants found.</td></tr>
    <?php else: foreach ($tenants as $t):
      $bMap = ['active'=>'badge-green','inactive'=>'badge-muted','pending'=>'badge-warn','moved_out'=>'badge-red'];
      $statusVal = $t['status'] ?? 'active';
      $bc   = $bMap[$statusVal] ?? 'badge-green';
      $roomDisplay = !empty($t['assigned_room_number'])
          ? '<strong>'.htmlspecialchars($t['assigned_room_number'],ENT_QUOTES,'UTF-8').'</strong> <small style="color:var(--muted)">'.htmlspecialchars($t['assigned_room_type'],ENT_QUOTES,'UTF-8').'</small>'
          : '<span style="color:var(--muted)">Unassigned</span>';
      $tid = (int)$t['id'];
    ?>
    <tr>
      <td>
        <strong><?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?></strong><br>
        <small style="color:var(--muted)"><?= htmlspecialchars($t['email']??'—',ENT_QUOTES,'UTF-8') ?></small>
      </td>
      <td><?= htmlspecialchars($t['phone']??'—',ENT_QUOTES,'UTF-8') ?></td>
      <td><?= $roomDisplay ?></td>
      <td><?= $t['move_in_date'] ? date('M j, Y', strtotime($t['move_in_date'])) : '—' ?></td>
      <td><span class="badge <?= $bc ?>"><?= str_replace('_',' ',$statusVal) ?></span></td>
      <td>
        <?php
        // Use JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP only — NOT JSON_HEX_QUOT.
        // JSON_HEX_QUOT encodes the structural " delimiters as \u0022 which makes
        // JSON.parse() fail silently (browsers reject \u0022 as key delimiters).
        // We wrap the attribute in single quotes instead so double-quotes are safe.
        $tenantJson = json_encode([
            'id'                => (int)$t['id'],
            'room_id'           => $t['room_id'],
            'full_name'         => $t['full_name'],
            'email'             => $t['email'] ?? '',
            'phone'             => $t['phone'] ?? '',
            'address'           => $t['address'] ?? '',
            'emergency_contact' => $t['emergency_contact'] ?? '',
            'emergency_phone'   => $t['emergency_phone'] ?? '',
            'id_type'           => $t['id_type'] ?? '',
            'id_number'         => $t['id_number'] ?? '',
            'move_in_date'      => $t['move_in_date'] ?? '',
            'move_out_date'     => $t['move_out_date'] ?? '',
            'status'            => $t['status'] ?? 'active',
            'notes'             => $t['notes'] ?? '',
        ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP);
        ?>
        <button class="tbl-btn" onclick="openEdit(this)" data-tenant='<?= $tenantJson ?>'>Edit</button>
        <button class="tbl-btn danger" onclick="confirmDelete(<?= $tid ?>,'<?= htmlspecialchars($t['full_name'], ENT_QUOTES, 'UTF-8') ?>')">Delete</button>
      </td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
  </div>
  <?php if ($pages > 1): ?>
  <div class="pagination">
    <?php for ($i=1;$i<=$pages;$i++): ?>
    <a href="?page=<?=$i?>&q=<?=urlencode($search)?>&status=<?=urlencode($filterStatus)?>"
       class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
</div></div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="addModal">
<div class="modal">
  <div class="modal-header"><span class="modal-title">Register Tenant</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
    <input type="hidden" name="act" value="add">
    <div class="form-grid">
      <div class="field field-full"><label>Full Name *</label><input type="text" name="full_name" class="form-input" required></div>
      <div class="field"><label>Email</label><input type="email" name="email" class="form-input"></div>
      <div class="field"><label>Contact Number</label><input type="text" name="contact_number" class="form-input"></div>
      <div class="field"><label>Assign Room</label>
        <select name="room_id" class="form-input">
          <option value="">— Unassigned —</option>
          <?php foreach ($rooms as $rm): if (in_array($rm['status'],['vacant','reserved'])): ?>
          <option value="<?= $rm['id'] ?>"><?= htmlspecialchars($rm['room_number']) ?> (<?= htmlspecialchars($rm['room_type']) ?>) — ₱<?= number_format($rm['monthly_rate'],2) ?></option>
          <?php endif; endforeach; ?>
        </select>
      </div>
      <div class="field"><label>Move-In Date</label><input type="date" name="move_in_date" class="form-input"></div>
      <div class="field"><label>Move-Out Date</label><input type="date" name="move_out_date" class="form-input"></div>
      <div class="field"><label>Emergency Contact</label><input type="text" name="emergency_contact_name" class="form-input"></div>
      <div class="field"><label>Emergency Phone</label><input type="text" name="emergency_contact_number" class="form-input"></div>
      <div class="field"><label>ID Type</label><input type="text" name="id_type" class="form-input" placeholder="e.g. PhilSys"></div>
      <div class="field"><label>ID Number</label><input type="text" name="id_number" class="form-input"></div>
      <div class="field field-full"><label>Address</label><textarea name="address" class="form-input" rows="2"></textarea></div>
      <div class="field field-full"><label>Notes</label><textarea name="notes" class="form-input" rows="2"></textarea></div>
    </div>
    <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('addModal')">Cancel</button><button type="submit" class="btn-primary">Register</button></div>
  </form>
</div></div>

<!-- EDIT MODAL -->
<div class="modal-overlay" id="editModal">
<div class="modal">
  <div class="modal-header"><span class="modal-title">Edit Tenant</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
    <input type="hidden" name="act" value="edit">
    <input type="hidden" name="id" id="e_id">
    <div class="form-grid">
      <div class="field field-full"><label>Full Name *</label><input type="text" name="full_name" id="e_name" class="form-input" required></div>
      <div class="field"><label>Email</label><input type="email" name="email" id="e_email" class="form-input"></div>
      <div class="field"><label>Contact Number</label><input type="text" name="contact_number" id="e_contact" class="form-input"></div>
      <div class="field"><label>Assign Room</label>
        <select name="room_id" id="e_room" class="form-input">
          <option value="">— Unassigned —</option>
          <?php foreach ($rooms as $rm): ?>
          <option value="<?= $rm['id'] ?>"><?= htmlspecialchars($rm['room_number']) ?> (<?= htmlspecialchars($rm['room_type']) ?>)</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field"><label>Status</label>
        <select name="status" id="e_status" class="form-input">
          <?php foreach(['active','pending','inactive','moved_out'] as $s): ?>
          <option value="<?= $s ?>"><?= ucfirst(str_replace('_',' ',$s)) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field"><label>Move-In Date</label><input type="date" name="move_in_date" id="e_movein" class="form-input"></div>
      <div class="field"><label>Move-Out Date</label><input type="date" name="move_out_date" id="e_moveout" class="form-input"></div>
      <div class="field"><label>Emergency Contact</label><input type="text" name="emergency_contact_name" id="e_ec_name" class="form-input"></div>
      <div class="field"><label>Emergency Phone</label><input type="text" name="emergency_contact_number" id="e_ec_phone" class="form-input"></div>
      <div class="field"><label>ID Type</label><input type="text" name="id_type" id="e_idtype" class="form-input"></div>
      <div class="field"><label>ID Number</label><input type="text" name="id_number" id="e_idnum" class="form-input"></div>
      <div class="field field-full"><label>Address</label><textarea name="address" id="e_addr" class="form-input" rows="2"></textarea></div>
      <div class="field field-full"><label>Notes</label><textarea name="notes" id="e_notes" class="form-input" rows="2"></textarea></div>
    </div>
    <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('editModal')">Cancel</button><button type="submit" class="btn-primary">Save Changes</button></div>
  </form>
</div></div>

<!-- DELETE MODAL -->
<div class="modal-overlay" id="deleteModal">
<div class="modal" style="max-width:400px;">
  <div class="modal-header"><span class="modal-title">Confirm Delete</span><button class="modal-close" onclick="closeModal('deleteModal')">✕</button></div>
  <p style="padding:20px 24px;color:var(--text-mid);">Delete tenant <strong id="delName"></strong>? This cannot be undone.</p>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
    <input type="hidden" name="act" value="delete">
    <input type="hidden" name="id" id="del_id">
    <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('deleteModal')">Cancel</button><button type="submit" class="btn-danger">Delete</button></div>
  </form>
</div></div>

<script>
function openModal(id) {
    const el = document.getElementById(id);
    el.style.display = 'flex';
    el.classList.add('active');
}
function closeModal(id) {
    const el = document.getElementById(id);
    el.style.display = '';
    el.classList.remove('active');
}

// BUG FIX: was using a TENANTS{} JS object that only contained the current page's
// tenants — any tenant on a different page would show "Tenant not found".
// Now we read the data directly from the button's data-tenant attribute,
// which is always present regardless of pagination.
function openEdit(btn) {
    const t = JSON.parse(btn.dataset.tenant);
    document.getElementById('e_id').value       = t.id                  || '';
    document.getElementById('e_name').value     = t.full_name           || '';
    document.getElementById('e_email').value    = t.email               || '';
    document.getElementById('e_contact').value  = t.phone               || '';
    document.getElementById('e_room').value     = t.room_id             || '';
    document.getElementById('e_status').value   = t.status              || 'active';
    document.getElementById('e_movein').value   = t.move_in_date        || '';
    document.getElementById('e_moveout').value  = t.move_out_date       || '';
    document.getElementById('e_ec_name').value  = t.emergency_contact   || '';
    document.getElementById('e_ec_phone').value = t.emergency_phone     || '';
    document.getElementById('e_idtype').value   = t.id_type             || '';
    document.getElementById('e_idnum').value    = t.id_number           || '';
    document.getElementById('e_addr').value     = t.address             || '';
    document.getElementById('e_notes').value    = t.notes               || '';
    openModal('editModal');
}

function confirmDelete(id, name) {
    document.getElementById('del_id').value        = id;
    document.getElementById('delName').textContent = name;
    openModal('deleteModal');
}

document.querySelectorAll('.modal-overlay').forEach(o => {
    o.addEventListener('click', e => { if (e.target === o) closeModal(o.id); });
});

function openSidebar()  { document.getElementById('sidebar').classList.add('open');    document.getElementById('overlay').classList.add('visible'); }
function closeSidebar() { document.getElementById('sidebar').classList.remove('open'); document.getElementById('overlay').classList.remove('visible'); }
</script>
</body>
</html>