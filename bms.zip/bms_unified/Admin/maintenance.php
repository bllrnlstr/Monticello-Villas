<?php
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDBConnection();

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';
    if ($act === 'add' || $act === 'edit') {
        $title  = trim($_POST['title'] ?? '');
        $desc   = trim($_POST['description'] ?? '') ?: null;
        $roomId = ($_POST['room_id'] ?? '') ?: null;
        $tenId  = ($_POST['tenant_id'] ?? '') ?: null;
        $pri    = $_POST['priority'] ?? 'medium';
        $stat   = $_POST['status']   ?? 'open';
        $notes  = trim($_POST['notes'] ?? '') ?: null;
        if ($act === 'add') {
            db_execute($pdo, SQL_MAINT_INSERT, [$roomId,$tenId,$title,$desc,$pri,$stat,$notes]);
            if ($roomId && $stat === 'open') db_execute($pdo, "UPDATE rooms SET status='maintenance' WHERE id=? AND status='vacant'", [$roomId]);
            db_audit($pdo, $adminId, 'CREATE_MAINTENANCE', "Created request: {$title}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Request created.'];
        } else {
            $id = (int)$_POST['id'];
            db_execute($pdo, SQL_MAINT_UPDATE, [$roomId,$tenId,$title,$desc,$pri,$stat,$notes,$id]);
            db_audit($pdo, $adminId, 'UPDATE_MAINTENANCE', "Updated request id={$id}: {$title}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Request updated.'];
        }
    } elseif ($act === 'delete') {
        $id = (int)$_POST['id'];
        db_execute($pdo, SQL_MAINT_DELETE, [$id]);
        db_audit($pdo, $adminId, 'DELETE_MAINTENANCE', "Deleted request id={$id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Request deleted.'];
    } elseif ($act === 'resolve') {
        $id = (int)$_POST['id'];
        db_execute($pdo, SQL_MAINT_RESOLVE, [$id]);
        db_audit($pdo, $adminId, 'RESOLVE_MAINTENANCE', "Resolved request id={$id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Marked as resolved.'];
    }
    header('Location: maintenance.php'); exit;
}

$filterStatus = $_GET['status']   ?? '';
$filterPri    = $_GET['priority'] ?? '';
$search  = trim($_GET['q'] ?? '');
$page    = max(1, (int)($_GET['page'] ?? 1)); $perPage = 20;

$sql    = SQL_MAINT_LIST;
$params = [];
if ($filterStatus !== '') { $sql .= SQL_MAINT_LIST_STATUS_APPEND;   $params[] = $filterStatus; }
if ($filterPri    !== '') { $sql .= SQL_MAINT_LIST_PRIORITY_APPEND; $params[] = $filterPri; }
if ($search !== '') {
    $sql .= SQL_MAINT_LIST_SEARCH_APPEND;
    $params[] = "%{$search}%"; $params[] = "%{$search}%"; $params[] = "%{$search}%";
}
$sql .= SQL_MAINT_LIST_ORDER;

$paginated = db_paginate($pdo, $sql, $params, $page, $perPage);
$requests  = $paginated['rows'];
$total     = $paginated['total'];
$pages     = $paginated['pages'];

$summaryRow = db_fetch_all($pdo, SQL_MAINT_SUMMARY)[0] ?? [];
$summary    = [
    'open'        => $summaryRow['open_count']        ?? 0,
    'in_progress' => $summaryRow['in_progress_count'] ?? 0,
    'resolved'    => $summaryRow['resolved_count']    ?? 0,
    'total'       => $summaryRow['total']             ?? 0,
];
$rooms   = db_fetch_all($pdo, SQL_ROOMS_ALL);
$tenants = db_fetch_all($pdo, SQL_TENANTS_ACTIVE_WITH_ROOM);
$navStats   = db_nav_stats($pdo);
$activeNav  = 'maintenance';

// Safe JSON for use inside HTML onclick attributes
function safe_json(mixed $val): string {
    return json_encode($val, JSON_HEX_QUOT | JSON_HEX_APOS | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
}
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Maintenance — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
</head><body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;"><button class="icon-btn hamburger" onclick="openSidebar()">☰</button><div class="topbar-left"><h2>Maintenance</h2><p>Track and manage repair requests</p></div></div>
  <div class="topbar-actions"><button class="btn-primary" onclick="openModal('addModal')">+ New Request</button><form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form></div>
</header>
<div class="content">
<?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div><?php endif; ?>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);">
  <div class="stat-card"><div class="stat-icon red">🔥</div><div class="stat-body"><div class="stat-label">Open</div><div class="stat-value"><?= $summary['open'] ?? 0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon blue">⚙️</div><div class="stat-body"><div class="stat-label">In Progress</div><div class="stat-value"><?= $summary['in_progress'] ?? 0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon green">✅</div><div class="stat-body"><div class="stat-label">Resolved</div><div class="stat-value"><?= $summary['resolved'] ?? 0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon warn">📋</div><div class="stat-body"><div class="stat-label">Total</div><div class="stat-value"><?= array_sum($summary) ?></div></div></div>
</div>

<div class="panel" style="margin-bottom:20px;"><form method="GET" class="filter-row">
  <input type="text" name="q" class="form-input" placeholder="Search title, room, tenant…" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:240px;">
  <select name="status" class="form-input" style="max-width:150px;"><option value="">All Statuses</option><?php foreach(['open','in_progress','resolved','closed'] as $s): ?><option value="<?=$s?>" <?=$filterStatus===$s?'selected':''?>><?= ucfirst(str_replace('_',' ',$s)) ?></option><?php endforeach; ?></select>
  <select name="priority" class="form-input" style="max-width:140px;"><option value="">All Priorities</option><?php foreach(['urgent','high','medium','low'] as $p): ?><option value="<?=$p?>" <?=$filterPri===$p?'selected':''?>><?= ucfirst($p) ?></option><?php endforeach; ?></select>
  <button type="submit" class="btn-secondary">Filter</button><a href="maintenance.php" class="btn-ghost">Clear</a>
</form></div>

<div class="panel">
  <div class="section-header"><span class="section-title">Requests <small style="color:var(--muted);font-size:13px;">(<?= $total ?>)</small></span></div>
  <div class="table-wrap"><table>
    <thead><tr><th>#</th><th>Title</th><th>Room</th><th>Reported By</th><th>Priority</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead>
    <tbody>
    <?php if (empty($requests)): ?><tr class="empty-row"><td colspan="8">No requests found.</td></tr>
    <?php else: foreach($requests as $m):
      $priMap=['urgent'=>'badge-red','high'=>'badge-warn','medium'=>'badge-blue','low'=>'badge-muted'];
      $staMap=['open'=>'badge-red','in_progress'=>'badge-blue','resolved'=>'badge-green','closed'=>'badge-muted'];
      $pc=$priMap[$m['priority']]??'badge-muted'; $sc=$staMap[$m['status']]??'badge-muted'; ?>
    <tr>
      <td style="color:var(--muted)">#<?= $m['id'] ?></td>
      <td><strong><?= htmlspecialchars($m['title'],ENT_QUOTES,'UTF-8') ?></strong><?= $m['description'] ? '<br><small style="color:var(--muted)">'.htmlspecialchars(substr($m['description'],0,60),ENT_QUOTES,'UTF-8').'…</small>' : '' ?></td>
      <td><?= htmlspecialchars($m['room_number'] ?? '—',ENT_QUOTES,'UTF-8') ?></td>
      <td><?= htmlspecialchars($m['tenant_name'] ?? 'Admin',ENT_QUOTES,'UTF-8') ?></td>
      <td><span class="badge <?= $pc ?>"><?= $m['priority'] ?></span></td>
      <td><span class="badge <?= $sc ?>"><?= str_replace('_',' ',$m['status']) ?></span></td>
      <td><?= date('M j, Y',strtotime($m['created_at'])) ?></td>
      <td style="white-space:nowrap;">
        <?php if ($m['status'] === 'open' || $m['status'] === 'in_progress'): ?>
        <form method="POST" style="display:inline;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
          <input type="hidden" name="act" value="resolve">
          <input type="hidden" name="id" value="<?= $m['id'] ?>">
          <button type="submit" class="tbl-btn success">✓ Resolve</button>
        </form>
        <?php endif; ?>
        <button class="tbl-btn" onclick="openEdit(this)" data-row="<?= htmlspecialchars(safe_json($m), ENT_QUOTES, 'UTF-8') ?>">Edit</button>
        <button class="tbl-btn danger" onclick="confirmDelete(<?= $m['id'] ?>)">Del</button>
      </td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table></div>
  <?php if ($pages>1): ?><div class="pagination"><?php for($i=1;$i<=$pages;$i++): ?><a href="?page=<?=$i?>&q=<?=urlencode($search)?>&status=<?=urlencode($filterStatus)?>&priority=<?=urlencode($filterPri)?>" class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?>
</div>
</div></div>

<!-- ADD -->
<div class="modal-overlay" id="addModal"><div class="modal">
<div class="modal-header"><span class="modal-title">New Maintenance Request</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="add">
<div class="form-grid">
  <div class="field field-full"><label>Title *</label><input type="text" name="title" class="form-input" required placeholder="e.g. Leaking faucet in bathroom"></div>
  <div class="field"><label>Room</label><select name="room_id" class="form-input"><option value="">— None —</option><?php foreach($rooms as $r): ?><option value="<?=$r['id']?>"><?= htmlspecialchars($r['room_number'],ENT_QUOTES,'UTF-8') ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>Reported By</label><select name="tenant_id" class="form-input"><option value="">— Admin —</option><?php foreach($tenants as $t): ?><option value="<?=$t['id']?>"><?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>Priority</label><select name="priority" class="form-input"><?php foreach(['medium','high','urgent','low'] as $p): ?><option value="<?=$p?>"><?= ucfirst($p) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>Status</label><select name="status" class="form-input"><?php foreach(['open','in_progress','resolved','closed'] as $s): ?><option value="<?=$s?>"><?= ucfirst(str_replace('_',' ',$s)) ?></option><?php endforeach; ?></select></div>
  <div class="field field-full"><label>Description</label><textarea name="description" class="form-input" rows="3"></textarea></div>
  <div class="field field-full"><label>Admin Notes</label><textarea name="notes" class="form-input" rows="2"></textarea></div>
</div>
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('addModal')">Cancel</button><button type="submit" class="btn-primary">Create Request</button></div>
</form></div></div>

<!-- EDIT -->
<div class="modal-overlay" id="editModal"><div class="modal">
<div class="modal-header"><span class="modal-title">Edit Request</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="edit"><input type="hidden" name="id" id="e_id">
<div class="form-grid">
  <div class="field field-full"><label>Title *</label><input type="text" name="title" id="e_title" class="form-input" required></div>
  <div class="field"><label>Room</label><select name="room_id" id="e_room" class="form-input"><option value="">— None —</option><?php foreach($rooms as $r): ?><option value="<?=$r['id']?>"><?= htmlspecialchars($r['room_number'],ENT_QUOTES,'UTF-8') ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>Reported By</label><select name="tenant_id" id="e_tenant" class="form-input"><option value="">— Admin —</option><?php foreach($tenants as $t): ?><option value="<?=$t['id']?>"><?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>Priority</label><select name="priority" id="e_priority" class="form-input"><?php foreach(['medium','high','urgent','low'] as $p): ?><option value="<?=$p?>"><?= ucfirst($p) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>Status</label><select name="status" id="e_status" class="form-input"><?php foreach(['open','in_progress','resolved','closed'] as $s): ?><option value="<?=$s?>"><?= ucfirst(str_replace('_',' ',$s)) ?></option><?php endforeach; ?></select></div>
  <div class="field field-full"><label>Description</label><textarea name="description" id="e_desc" class="form-input" rows="3"></textarea></div>
  <div class="field field-full"><label>Admin Notes</label><textarea name="notes" id="e_notes" class="form-input" rows="2"></textarea></div>
</div>
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('editModal')">Cancel</button><button type="submit" class="btn-primary">Save</button></div>
</form></div></div>

<!-- DELETE -->
<div class="modal-overlay" id="deleteModal"><div class="modal" style="max-width:380px;">
<div class="modal-header"><span class="modal-title">Delete Request</span><button class="modal-close" onclick="closeModal('deleteModal')">✕</button></div>
<p style="padding:20px 24px;color:var(--text-mid);">Delete request #<strong id="delId"></strong>?</p>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" id="del_id">
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('deleteModal')">Cancel</button><button type="submit" class="btn-danger">Delete</button></div>
</form></div></div>

<script>
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
function openEdit(btn){
  const m = JSON.parse(btn.dataset.row);
  document.getElementById('e_id').value       = m.id        || '';
  document.getElementById('e_title').value    = m.title     || '';
  document.getElementById('e_room').value     = m.room_id   || '';
  document.getElementById('e_tenant').value   = m.tenant_id || '';
  document.getElementById('e_priority').value = m.priority  || 'medium';
  document.getElementById('e_status').value   = m.status    || 'open';
  document.getElementById('e_desc').value     = m.description || '';
  document.getElementById('e_notes').value    = m.notes     || '';
  openModal('editModal');
}
function confirmDelete(id){document.getElementById('del_id').value=id;document.getElementById('delId').textContent=id;openModal('deleteModal');}
document.querySelectorAll('.modal-overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('active');}));
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
</script>
</body></html>