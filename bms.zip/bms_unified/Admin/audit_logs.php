<?php
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf = $_SESSION['csrf_token'];
$pdo  = getDBConnection();

$search  = trim($_GET['q'] ?? '');
$page    = max(1, (int)($_GET['page'] ?? 1)); $perPage = 30;

$sql    = SQL_AUDIT_LIST;
$params = [];
if ($search !== '') {
    $sql .= SQL_AUDIT_LIST_SEARCH_APPEND;
    $params[] = "%{$search}%"; $params[] = "%{$search}%";
    $params[] = "%{$search}%"; $params[] = "%{$search}%";
}
$sql .= SQL_AUDIT_LIST_ORDER;

$paginated = db_paginate($pdo, $sql, $params, $page, $perPage);
$logs      = $paginated['rows'];
$total     = $paginated['total'];
$pages     = $paginated['pages'];

$navStats  = db_nav_stats($pdo);
$activeNav = 'audit_logs';
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Audit Logs — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?></head><body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;"><button class="icon-btn hamburger" onclick="openSidebar()">☰</button><div class="topbar-left"><h2>Audit Logs</h2><p>System activity history</p></div></div>
  <div class="topbar-actions"><form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form></div>
</header>
<div class="content">
<div class="panel" style="margin-bottom:20px;"><form method="GET" class="filter-row">
  <input type="text" name="q" class="form-input" placeholder="Search action, user, IP…" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:300px;">
  <button type="submit" class="btn-secondary">Search</button><a href="audit_logs.php" class="btn-ghost">Clear</a>
</form></div>
<div class="panel">
  <div class="section-header"><span class="section-title">Audit Log <small style="color:var(--muted);font-size:13px;">(<?= $total ?> entries)</small></span></div>
  <div class="table-wrap"><table>
    <thead><tr><th>#</th><th>Admin</th><th>Action</th><th>Details</th><th>IP Address</th><th>Timestamp</th></tr></thead>
    <tbody>
    <?php if(empty($logs)): ?><tr class="empty-row"><td colspan="6">No logs found.</td></tr>
    <?php else: foreach($logs as $l): ?>
    <tr>
      <td style="color:var(--muted)"><?=$l['id']?></td>
      <td><strong><?= htmlspecialchars($l['username']??'—',ENT_QUOTES,'UTF-8') ?></strong><br><small style="color:var(--muted)"><?= htmlspecialchars($l['full_name']??'',ENT_QUOTES,'UTF-8') ?></small></td>
      <td><span class="badge badge-blue"><?= htmlspecialchars($l['action'],ENT_QUOTES,'UTF-8') ?></span></td>
      <td><small style="color:var(--text-mid)"><?= htmlspecialchars($l['details']??'—',ENT_QUOTES,'UTF-8') ?></small></td>
      <td><code style="font-size:12px;color:var(--muted)"><?= htmlspecialchars($l['ip_address']??'—',ENT_QUOTES,'UTF-8') ?></code></td>
      <td style="white-space:nowrap;"><?= date('M j, Y H:i',strtotime($l['created_at'])) ?></td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table></div>
  <?php if($pages>1): ?><div class="pagination"><?php for($i=1;$i<=$pages;$i++): ?><a href="?page=<?=$i?>&q=<?=urlencode($search)?>" class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?>
</div>
</div></div>
<script>
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
</script>
</body></html>