<?php
session_start();
require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDB();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');

    // Save a single tenant's rent settings
    if ($_POST['act'] === 'set_rent') {
        $id          = (int)$_POST['tenant_id'];
        $dueDay      = (int)$_POST['monthly_due_day'];
        $monthlyRent = (float)$_POST['monthly_rent'];
        if ($id && $monthlyRent > 0 && $dueDay >= 1 && $dueDay <= 31) {
            $pdo->prepare("UPDATE tenants SET monthly_due_day=?, monthly_rent=? WHERE id=?")->execute([$dueDay, $monthlyRent, $id]);
            db_audit_admin($pdo, $adminId, 'SET_RENT', "Set rent=₱{$monthlyRent} due_day={$dueDay} for tenant ID: $id");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'✅ Rent updated successfully.'];
        } else {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'❌ Invalid values. Rent must be > 0 and due day between 1–31.'];
        }
    }

    // Bulk save all tenants at once
    if ($_POST['act'] === 'bulk_save') {
        $rents    = $_POST['rent']    ?? [];
        $dueDays  = $_POST['due_day'] ?? [];
        $count    = 0;
        foreach ($rents as $tid => $rent) {
            $tid     = (int)$tid;
            $rent    = (float)$rent;
            $dueDay  = (int)($dueDays[$tid] ?? 0);
            if ($tid && $rent > 0 && $dueDay >= 1 && $dueDay <= 31) {
                $pdo->prepare("UPDATE tenants SET monthly_due_day=?, monthly_rent=? WHERE id=?")->execute([$dueDay, $rent, $tid]);
                $count++;
            }
        }
        db_audit_admin($pdo, $adminId, 'BULK_SET_RENT', "Bulk updated rent for {$count} tenants");
        $_SESSION['flash'] = ['type'=>'success','msg'=>"✅ Rent updated for {$count} tenant(s)."];
    }

    header('Location: rents.php'); exit;
}

// Fetch all tenants with room info
$tenants = $pdo->query("
    SELECT t.id, t.full_name, t.email, t.room_number, t.monthly_due_day, t.monthly_rent,
           t.approval_status, t.status,
           r.room_type, r.monthly_rate AS room_rate
    FROM tenants t
    LEFT JOIN rooms r ON r.id = t.room_id
    WHERE t.approval_status = 'approved'
    ORDER BY t.room_number ASC, t.full_name ASC
")->fetchAll(PDO::FETCH_ASSOC);

// Summary stats
$notSet  = array_filter($tenants, fn($t) => empty($t['monthly_rent']) || $t['monthly_rent'] <= 0);
$set     = array_filter($tenants, fn($t) => !empty($t['monthly_rent']) && $t['monthly_rent'] > 0);

$navStats  = db_nav_stats($pdo);
$activeNav = 'rents';
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Rent Settings — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
<style>
.modal-overlay{z-index:9999!important;}
body{overflow:auto!important;}
.main{overflow:visible!important;}
.rent-table{width:100%;border-collapse:collapse;}
.rent-table th{text-align:left;font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;padding:10px 14px;border-bottom:2px solid var(--border);}
.rent-table td{padding:12px 14px;border-bottom:1px solid var(--border);vertical-align:middle;}
.rent-table tr:last-child td{border-bottom:none;}
.rent-table tr:hover td{background:rgba(255,255,255,.02);}
.rent-input{width:130px;background:#0d1018;border:1.5px solid var(--border);border-radius:6px;padding:7px 10px;font-size:14px;color:var(--text);font-family:inherit;outline:none;transition:border-color .2s;}
.rent-input:focus{border-color:var(--accent);}
.due-input{width:70px;background:#0d1018;border:1.5px solid var(--border);border-radius:6px;padding:7px 10px;font-size:14px;color:var(--text);font-family:inherit;outline:none;transition:border-color .2s;text-align:center;}
.due-input:focus{border-color:var(--accent);}
.save-row-btn{padding:6px 14px;background:var(--accent-dim);border:1px solid var(--accent);border-radius:6px;color:var(--accent);font-size:12px;font-weight:600;cursor:pointer;font-family:var(--font-sans);transition:background .2s;white-space:nowrap;}
.save-row-btn:hover{background:rgba(232,184,109,.2);}
.not-set-badge{background:var(--danger-dim);border:1px solid rgba(224,92,92,.3);color:var(--danger);font-size:10px;font-weight:700;padding:2px 8px;border-radius:99px;}
.set-badge{background:var(--success-dim);border:1px solid rgba(76,175,130,.3);color:var(--success);font-size:10px;font-weight:700;padding:2px 8px;border-radius:99px;}
.room-tag{background:var(--accent-dim);color:var(--accent);font-size:11px;font-weight:700;padding:2px 8px;border-radius:99px;}
.info-box{display:flex;gap:0.6rem;padding:12px 16px;background:rgba(232,184,109,.07);border:1px solid rgba(232,184,109,.2);border-radius:8px;font-size:13px;color:var(--text-mid);margin-bottom:20px;line-height:1.6;}
</style>
</head>
<body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <button class="icon-btn hamburger" onclick="openSidebar()">☰</button>
    <div class="topbar-left"><h2>Rent Settings</h2><p>Set monthly rent and due date per tenant</p></div>
  </div>
  <div class="topbar-actions">
    <a href="payments.php" class="btn-secondary" style="text-decoration:none;">← Back to Payments</a>
    <form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form>
  </div>
</header>
<div class="content">

<?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>" style="margin-bottom:20px;"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div><?php endif; ?>

<!-- Summary cards -->
<div class="stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:20px;">
  <div class="stat-card"><div class="stat-icon green">✅</div><div class="stat-body"><div class="stat-label">Rent Set</div><div class="stat-value"><?= count($set) ?></div><div class="stat-sub">tenants configured</div></div></div>
  <div class="stat-card"><div class="stat-icon red">⚠️</div><div class="stat-body"><div class="stat-label">Not Set</div><div class="stat-value"><?= count($notSet) ?></div><div class="stat-sub">need configuration</div></div></div>
  <div class="stat-card"><div class="stat-icon gold">👥</div><div class="stat-body"><div class="stat-label">Total Tenants</div><div class="stat-value"><?= count($tenants) ?></div><div class="stat-sub">approved tenants</div></div></div>
</div>

<div class="info-box">
  💡 Set the <strong>Monthly Rent</strong> and <strong>Due Day</strong> for each tenant. Tenants cannot change their rent amount — they will only be able to submit exactly this amount. The due day is the day of the month rent is due (e.g. 5 = every 5th of the month).
</div>

<!-- Bulk Save Form -->
<form method="POST" id="bulkForm">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
  <input type="hidden" name="act" value="bulk_save">

<div class="panel">
  <div class="section-header">
    <span class="section-title">All Tenants</span>
    <button type="submit" class="btn-primary" style="font-size:13px;padding:8px 20px;">💾 Save All Changes</button>
  </div>

  <?php if (empty($tenants)): ?>
  <div style="text-align:center;padding:40px;color:var(--muted);">No approved tenants found.</div>
  <?php else: ?>
  <div class="table-wrap">
  <table class="rent-table">
    <thead>
      <tr>
        <th>Tenant</th>
        <th>Room</th>
        <th>Room Rate</th>
        <th>Monthly Rent (₱) *</th>
        <th>Due Day *</th>
        <th>Status</th>
        <th>Quick Save</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach ($tenants as $t):
      $isSet = !empty($t['monthly_rent']) && $t['monthly_rent'] > 0;
    ?>
    <tr id="row-<?= $t['id'] ?>">
      <td>
        <strong style="color:var(--text)"><?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?></strong>
        <br><small style="color:var(--muted)"><?= htmlspecialchars($t['email']??'',ENT_QUOTES,'UTF-8') ?></small>
      </td>
      <td>
        <?php if ($t['room_number']): ?>
        <span class="room-tag">Room <?= htmlspecialchars($t['room_number'],ENT_QUOTES,'UTF-8') ?></span>
        <?php if ($t['room_type']): ?><br><small style="color:var(--muted);font-size:11px;"><?= htmlspecialchars($t['room_type'],ENT_QUOTES,'UTF-8') ?></small><?php endif; ?>
        <?php else: ?>
        <span style="color:var(--muted);font-size:12px;">Unassigned</span>
        <?php endif; ?>
      </td>
      <td>
        <?php if ($t['room_rate']): ?>
        <span style="color:var(--text-mid);font-size:13px;">₱<?= number_format($t['room_rate'],2) ?></span>
        <br><small style="color:var(--muted);font-size:11px;">Room rate</small>
        <?php else: ?><span style="color:var(--muted)">—</span><?php endif; ?>
      </td>
      <td>
        <div style="display:flex;align-items:center;gap:6px;">
          <span style="color:var(--muted);font-size:14px;">₱</span>
          <input type="number"
                 name="rent[<?= $t['id'] ?>]"
                 class="rent-input"
                 step="0.01" min="0"
                 value="<?= $isSet ? number_format($t['monthly_rent'],2,'.','') : '' ?>"
                 placeholder="<?= $t['room_rate'] ? number_format($t['room_rate'],2,'.','') : '0.00' ?>"
                 data-id="<?= $t['id'] ?>"
                 oninput="markChanged(<?= $t['id'] ?>)">
          <?php if ($t['room_rate'] && !$isSet): ?>
          <button type="button" onclick="useRoomRate(<?= $t['id'] ?>, <?= $t['room_rate'] ?>)"
                  style="padding:4px 8px;background:var(--border);border:1px solid var(--border);border-radius:4px;color:var(--muted);font-size:10px;cursor:pointer;font-family:var(--font-sans);white-space:nowrap;">
            Use Room Rate
          </button>
          <?php endif; ?>
        </div>
      </td>
      <td>
        <input type="number"
               name="due_day[<?= $t['id'] ?>]"
               class="due-input"
               min="1" max="31"
               value="<?= $t['monthly_due_day'] ?: '' ?>"
               placeholder="1–31"
               oninput="markChanged(<?= $t['id'] ?>)">
      </td>
      <td>
        <?php if ($isSet): ?>
        <span class="set-badge">✅ Set</span>
        <br><small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">₱<?= number_format($t['monthly_rent'],2) ?> / day <?= $t['monthly_due_day'] ?></small>
        <?php else: ?>
        <span class="not-set-badge">⚠ Not Set</span>
        <?php endif; ?>
      </td>
      <td>
        <button type="button" class="save-row-btn" id="savebtn-<?= $t['id'] ?>" onclick="saveRow(<?= $t['id'] ?>)">
          Save
        </button>
      </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  </div>

  <div style="padding:16px 0 4px;display:flex;justify-content:flex-end;">
    <button type="submit" class="btn-primary" style="font-size:13px;padding:9px 24px;">💾 Save All Changes</button>
  </div>
  <?php endif; ?>
</div>
</form>

<!-- Hidden quick-save forms (one per tenant) -->
<?php foreach ($tenants as $t): ?>
<form method="POST" id="rowform-<?= $t['id'] ?>" style="display:none;">
  <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
  <input type="hidden" name="act" value="set_rent">
  <input type="hidden" name="tenant_id" value="<?= $t['id'] ?>">
  <input type="hidden" name="monthly_rent"    id="hrent-<?= $t['id'] ?>">
  <input type="hidden" name="monthly_due_day" id="hday-<?= $t['id'] ?>">
</form>
<?php endforeach; ?>

</div></div>

<script>
function markChanged(id) {
    var btn = document.getElementById('savebtn-' + id);
    if (btn) { btn.textContent = 'Save *'; btn.style.background = 'var(--warn-dim)'; btn.style.borderColor = 'var(--warn)'; btn.style.color = 'var(--warn)'; }
}
function useRoomRate(id, rate) {
    var input = document.querySelector('input[name="rent[' + id + ']"]');
    if (input) { input.value = parseFloat(rate).toFixed(2); markChanged(id); }
}
function saveRow(id) {
    var rent   = document.querySelector('input[name="rent['    + id + ']"]')?.value;
    var dueDay = document.querySelector('input[name="due_day[' + id + ']"]')?.value;
    if (!rent || !dueDay) { alert('Please enter both Monthly Rent and Due Day before saving.'); return; }
    document.getElementById('hrent-' + id).value  = rent;
    document.getElementById('hday-'  + id).value  = dueDay;
    document.getElementById('rowform-' + id).submit();
}
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
</script>
</body></html>