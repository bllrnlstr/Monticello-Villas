<?php
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDBConnection();

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

// Auto-expire past contracts on every page load
db_auto_expire_contracts($pdo);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';
    if ($act === 'add' || $act === 'edit') {
        $tenantId = ($_POST['tenant_id'] ?? '') ?: null;
        $roomId   = ($_POST['room_id']   ?? '') ?: null;
        $start    = $_POST['start_date'] ?? null ?: null;
        $end      = $_POST['end_date']   ?? null ?: null;
        $rate     = (float)str_replace(',', '', $_POST['monthly_rate'] ?? 0);
        $deposit  = (float)str_replace(',', '', $_POST['deposit']      ?? 0);
        $status   = $_POST['status'] ?? 'active';
        $terms    = trim($_POST['terms'] ?? '') ?: null;
        if ($act === 'add') {
            db_execute($pdo, SQL_CONTRACT_INSERT, [$tenantId,$roomId,$start,$end,$rate,$deposit,$status,$terms]);
            db_audit($pdo, $adminId, 'CREATE_CONTRACT', "Contract for tenant_id={$tenantId} room_id={$roomId}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Contract created.'];
        } else {
            $id = (int)$_POST['id'];
            db_execute($pdo, SQL_CONTRACT_UPDATE, [$tenantId,$roomId,$start,$end,$rate,$deposit,$status,$terms,$id]);
            db_audit($pdo, $adminId, 'UPDATE_CONTRACT', "Updated contract id={$id}");
            $_SESSION['flash'] = ['type'=>'success','msg'=>'Contract updated.'];
        }
    } elseif ($act === 'delete') {
        $id = (int)$_POST['id'];
        db_execute($pdo, SQL_CONTRACT_DELETE, [$id]);
        db_audit($pdo, $adminId, 'DELETE_CONTRACT', "Deleted contract id={$id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Contract deleted.'];
    }
    header('Location: contracts.php'); exit;
}

$filterStatus = $_GET['status'] ?? ''; $search = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1)); $perPage = 20;

$sql    = SQL_CONTRACTS_LIST;
$params = [];
if ($filterStatus !== '') { $sql .= SQL_CONTRACTS_LIST_STATUS_APPEND; $params[] = $filterStatus; }
if ($search !== '') {
    $sql .= SQL_CONTRACTS_LIST_SEARCH_APPEND;
    $params[] = "%{$search}%"; $params[] = "%{$search}%";
}
$sql .= SQL_CONTRACTS_LIST_ORDER;

$paginated = db_paginate($pdo, $sql, $params, $page, $perPage);
$contracts = $paginated['rows'];
$total     = $paginated['total'];
$pages     = $paginated['pages'];

$summaryRows  = db_fetch_all($pdo, SQL_CONTRACTS_SUMMARY);
$summaryRow   = $summaryRows[0] ?? [];
$summary      = [
    'active'     => $summaryRow['active_count']     ?? 0,
    'expired'    => $summaryRow['expired_count']    ?? 0,
    'terminated' => $summaryRow['terminated_count'] ?? 0,
];
$expiringSoon = (int)db_scalar($pdo, SQL_CONTRACTS_EXPIRING_SOON);
$tenants      = db_fetch_all($pdo, SQL_TENANTS_ACTIVE_WITH_ROOM);
$rooms        = db_fetch_all($pdo, SQL_ROOMS_ALL);
$navStats     = db_nav_stats($pdo);
$activeNav    = 'contracts';
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Contracts — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?></head><body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;"><button class="icon-btn hamburger" onclick="openSidebar()">☰</button><div class="topbar-left"><h2>Contracts</h2><p>Manage lease agreements</p></div></div>
  <div class="topbar-actions"><button class="btn-primary" onclick="openModal('addModal')">+ New Contract</button><form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form></div>
</header>
<div class="content">
<?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div><?php endif; ?>
<div class="stats-grid" style="grid-template-columns:repeat(3,1fr);">
  <div class="stat-card"><div class="stat-icon green">📝</div><div class="stat-body"><div class="stat-label">Active</div><div class="stat-value"><?= $summary['active']??0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon red">⌛</div><div class="stat-body"><div class="stat-label">Expired</div><div class="stat-value"><?= $summary['expired']??0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon warn">🚫</div><div class="stat-body"><div class="stat-label">Terminated</div><div class="stat-value"><?= $summary['terminated']??0 ?></div></div></div>
</div>
<div class="panel" style="margin-bottom:20px;"><form method="GET" class="filter-row">
  <input type="text" name="q" class="form-input" placeholder="Search tenant or room…" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:240px;">
  <select name="status" class="form-input" style="max-width:150px;"><option value="">All</option><?php foreach(['active','expired','terminated'] as $s): ?><option value="<?=$s?>" <?=$filterStatus===$s?'selected':''?>><?= ucfirst($s) ?></option><?php endforeach; ?></select>
  <button type="submit" class="btn-secondary">Filter</button><a href="contracts.php" class="btn-ghost">Clear</a>
</form></div>
<div class="panel">
  <div class="section-header"><span class="section-title">Contracts <small style="color:var(--muted);font-size:13px;">(<?= $total ?>)</small></span></div>
  <div class="table-wrap"><table>
    <thead><tr><th>#</th><th>Tenant</th><th>Room</th><th>Start</th><th>End</th><th>Rate</th><th>Deposit</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php if(empty($contracts)): ?><tr class="empty-row"><td colspan="9">No contracts found.</td></tr>
    <?php else: foreach($contracts as $c):
      $cMap=['active'=>'badge-green','expired'=>'badge-red','terminated'=>'badge-muted'];
      $cc=$cMap[$c['status']]??'badge-muted';
      $expiring = $c['end_date'] && $c['status']==='active' && strtotime($c['end_date'])<strtotime('+30 days'); ?>
    <tr>
      <td style="color:var(--muted)">#<?=$c['id']?></td>
      <td><strong><?= htmlspecialchars($c['tenant_name']??'—',ENT_QUOTES,'UTF-8') ?></strong></td>
      <td><?= htmlspecialchars($c['room_number']??'—',ENT_QUOTES,'UTF-8') ?> <small style="color:var(--muted)"><?= $c['room_type']??'' ?></small></td>
      <td><?= $c['start_date']?date('M j, Y',strtotime($c['start_date'])):'—'?></td>
      <td><?= $c['end_date']?'<span '.($expiring?'style="color:var(--warn)"':'').'>'.date('M j, Y',strtotime($c['end_date'])).'</span>':'—'?></td>
      <td><strong>₱<?= number_format($c['monthly_rate'],2) ?></strong></td>
      <td>₱<?= number_format($c['deposit'],2) ?></td>
      <td><span class="badge <?=$cc?>"><?=$c['status']?></span><?= $expiring?'<br><span class="badge badge-warn" style="font-size:10px;">Expiring soon</span>':''?></td>
      <td><button class="tbl-btn" onclick='openEdit(<?= json_encode($c) ?>)'>Edit</button> <button class="tbl-btn danger" onclick="confirmDelete(<?=$c['id']?>)">Del</button></td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table></div>
  <?php if($pages>1): ?><div class="pagination"><?php for($i=1;$i<=$pages;$i++): ?><a href="?page=<?=$i?>&q=<?=urlencode($search)?>&status=<?=urlencode($filterStatus)?>" class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?>
</div>
</div></div>

<!-- ADD -->
<div class="modal-overlay" id="addModal"><div class="modal">
<div class="modal-header"><span class="modal-title">New Contract</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="add">
<div class="form-grid">
  <div class="field"><label>Tenant *</label><select name="tenant_id" class="form-input" required><option value="">— Select —</option><?php foreach($tenants as $t): ?><option value="<?=$t['id']?>"><?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>Room *</label><select name="room_id" class="form-input" required><option value="">— Select —</option><?php foreach($rooms as $r): ?><option value="<?=$r['id']?>" data-rate="<?=$r['monthly_rate']?>"><?= $r['room_number']?> (<?= $r['room_type']?>)</option><?php endforeach; ?></select></div>
  <div class="field"><label>Start Date</label><input type="date" name="start_date" class="form-input"></div>
  <div class="field"><label>End Date</label><input type="date" name="end_date" class="form-input"></div>
  <div class="field"><label>Monthly Rate (₱)</label><input type="number" name="monthly_rate" class="form-input" step="0.01" min="0" id="add_rate"></div>
  <div class="field"><label>Security Deposit (₱)</label><input type="number" name="deposit" class="form-input" step="0.01" min="0"></div>
  <div class="field"><label>Status</label><select name="status" class="form-input"><?php foreach(['active','expired','terminated'] as $s): ?><option value="<?=$s?>"><?= ucfirst($s) ?></option><?php endforeach; ?></select></div>
  <div class="field field-full"><label>Terms & Conditions</label><textarea name="terms" class="form-input" rows="3" placeholder="House rules, payment terms, etc."></textarea></div>
</div>
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('addModal')">Cancel</button><button type="submit" class="btn-primary">Create Contract</button></div>
</form></div></div>

<!-- EDIT -->
<div class="modal-overlay" id="editModal"><div class="modal">
<div class="modal-header"><span class="modal-title">Edit Contract</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="edit"><input type="hidden" name="id" id="e_id">
<div class="form-grid">
  <div class="field"><label>Tenant</label><select name="tenant_id" id="e_tenant" class="form-input"><option value="">— None —</option><?php foreach($tenants as $t): ?><option value="<?=$t['id']?>"><?= htmlspecialchars($t['full_name'],ENT_QUOTES,'UTF-8') ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>Room</label><select name="room_id" id="e_room" class="form-input"><option value="">— None —</option><?php foreach($rooms as $r): ?><option value="<?=$r['id']?>"><?= $r['room_number']?> (<?= $r['room_type']?>)</option><?php endforeach; ?></select></div>
  <div class="field"><label>Start Date</label><input type="date" name="start_date" id="e_start" class="form-input"></div>
  <div class="field"><label>End Date</label><input type="date" name="end_date" id="e_end" class="form-input"></div>
  <div class="field"><label>Monthly Rate (₱)</label><input type="number" name="monthly_rate" id="e_rate" class="form-input" step="0.01"></div>
  <div class="field"><label>Security Deposit (₱)</label><input type="number" name="deposit" id="e_deposit" class="form-input" step="0.01"></div>
  <div class="field"><label>Status</label><select name="status" id="e_status" class="form-input"><?php foreach(['active','expired','terminated'] as $s): ?><option value="<?=$s?>"><?= ucfirst($s) ?></option><?php endforeach; ?></select></div>
  <div class="field field-full"><label>Terms</label><textarea name="terms" id="e_terms" class="form-input" rows="3"></textarea></div>
</div>
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('editModal')">Cancel</button><button type="submit" class="btn-primary">Save</button></div>
</form></div></div>

<!-- DELETE -->
<div class="modal-overlay" id="deleteModal"><div class="modal" style="max-width:380px;"><div class="modal-header"><span class="modal-title">Delete Contract</span><button class="modal-close" onclick="closeModal('deleteModal')">✕</button></div>
<p style="padding:20px 24px;color:var(--text-mid);">Delete contract #<strong id="delId"></strong>?</p>
<form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" id="del_id">
<div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('deleteModal')">Cancel</button><button type="submit" class="btn-danger">Delete</button></div>
</form></div></div>

<script>
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
function openEdit(c){
  document.getElementById('e_id').value=c.id;
  document.getElementById('e_tenant').value=c.tenant_id||'';
  document.getElementById('e_room').value=c.room_id||'';
  document.getElementById('e_start').value=c.start_date||'';
  document.getElementById('e_end').value=c.end_date||'';
  document.getElementById('e_rate').value=c.monthly_rate||'';
  document.getElementById('e_deposit').value=c.deposit||'';
  document.getElementById('e_status').value=c.status||'active';
  document.getElementById('e_terms').value=c.terms||'';
  openModal('editModal');
}
function confirmDelete(id){document.getElementById('del_id').value=id;document.getElementById('delId').textContent=id;openModal('deleteModal');}
document.querySelectorAll('.modal-overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('active');}));
// Auto-fill rate when room is selected
document.querySelector('[name="room_id"]')?.addEventListener('change',function(){
  const opt=this.options[this.selectedIndex]; const rate=opt.getAttribute('data-rate');
  if(rate) document.getElementById('add_rate').value=rate;
});
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
</script>
</body></html>