<style>
/* ══════════════════════════════════ RESET & VARS ══════════════════════════════════ */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
:root{
  --bg:#0b0e14;--sidebar-bg:#0e1119;--panel:#131720;--panel-raised:#181e2c;
  --border:#1f2633;--border-light:#29324a;
  --accent:#e8b86d;--accent2:#c47f2e;--accent-dim:rgba(232,184,109,.12);
  --success:#4caf82;--success-dim:rgba(76,175,130,.12);
  --danger:#e05c5c;--danger-dim:rgba(224,92,92,.12);
  --warn:#e8a84d;--warn-dim:rgba(232,168,77,.12);
  --blue:#5c8fe8;--blue-dim:rgba(92,143,232,.12);
  --text:#e8eaf0;--text-mid:#9aa3ba;--muted:#5a6380;
  --sidebar-w:260px;--topbar-h:64px;--radius:12px;--radius-sm:8px;
  --font-serif:'DM Serif Display',serif;--font-sans:'DM Sans',sans-serif;--trans:.2s ease;
}
html,body{height:100%;}
body{font-family:var(--font-sans);background:var(--bg);color:var(--text);font-size:14px;line-height:1.55;display:flex;overflow:auto;}

/* ══════════════════════════════════ SIDEBAR ══════════════════════════════════ */
.sidebar{width:var(--sidebar-w);min-height:100vh;background:var(--sidebar-bg);border-right:1px solid var(--border);display:flex;flex-direction:column;flex-shrink:0;position:fixed;left:0;top:0;bottom:0;z-index:100;transition:transform var(--trans);}
.sidebar-brand{display:flex;align-items:center;gap:11px;padding:20px 20px 18px;border-bottom:1px solid var(--border);}
.brand-icon{width:38px;height:38px;background:linear-gradient(135deg,var(--accent),var(--accent2));border-radius:9px;display:grid;place-items:center;font-size:18px;flex-shrink:0;box-shadow:0 4px 12px rgba(232,184,109,.25);}
.brand-info{line-height:1.25;overflow:hidden;}
.brand-info strong{font-family:var(--font-serif);font-size:15px;color:var(--text);white-space:nowrap;display:block;}
.brand-info span{font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;}
.sidebar-nav{flex:1;overflow-y:auto;padding:16px 12px;scrollbar-width:thin;scrollbar-color:var(--border) transparent;}
.nav-section{margin-bottom:24px;}
.nav-section-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.14em;color:var(--muted);padding:0 10px;margin-bottom:8px;}
.nav-item{display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:var(--radius-sm);color:var(--text-mid);text-decoration:none;font-size:13.5px;font-weight:500;cursor:pointer;transition:background var(--trans),color var(--trans);user-select:none;position:relative;}
.nav-item:hover{background:rgba(255,255,255,.045);color:var(--text);}
.nav-item.active{background:var(--accent-dim);color:var(--accent);}
.nav-item.active::before{content:'';position:absolute;left:0;top:20%;bottom:20%;width:3px;background:var(--accent);border-radius:0 3px 3px 0;}
.nav-icon{font-size:17px;flex-shrink:0;width:20px;text-align:center;}
.nav-badge{margin-left:auto;background:var(--danger);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:99px;min-width:18px;text-align:center;}
.nav-badge.warn{background:var(--warn);}
.sidebar-footer{border-top:1px solid var(--border);padding:14px 12px;}
.admin-card{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:var(--radius-sm);background:rgba(255,255,255,.03);}
.admin-avatar{width:34px;height:34px;background:linear-gradient(135deg,#5c8fe8,#3b6bc4);border-radius:50%;display:grid;place-items:center;font-size:14px;font-weight:700;color:#fff;flex-shrink:0;}
.admin-info{flex:1;overflow:hidden;}
.admin-info strong{font-size:13px;color:var(--text);display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.admin-info span{font-size:11px;color:var(--muted);text-transform:capitalize;}

/* ══════════════════════════════════ MAIN ══════════════════════════════════ */
.main{margin-left:var(--sidebar-w);flex:1;display:flex;flex-direction:column;min-height:100vh;min-width:0;}
.topbar{height:var(--topbar-h);background:var(--sidebar-bg);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 28px;position:sticky;top:0;z-index:90;flex-shrink:0;}
.topbar-left h2{font-family:var(--font-serif);font-size:20px;font-weight:400;color:var(--text);}
.topbar-left p{font-size:12px;color:var(--muted);margin-top:1px;}
.topbar-actions{display:flex;align-items:center;gap:10px;}
.icon-btn{width:36px;height:36px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:var(--radius-sm);display:grid;place-items:center;cursor:pointer;font-size:16px;color:var(--text-mid);transition:background var(--trans),color var(--trans);position:relative;text-decoration:none;}
.icon-btn:hover{background:rgba(255,255,255,.08);color:var(--text);}
.notif-dot{width:7px;height:7px;background:var(--danger);border-radius:50%;position:absolute;top:6px;right:7px;border:1.5px solid var(--sidebar-bg);}
.btn-logout{display:flex;align-items:center;gap:7px;padding:8px 16px;background:rgba(224,92,92,.1);border:1px solid rgba(224,92,92,.25);border-radius:var(--radius-sm);color:var(--danger);font-family:var(--font-sans);font-size:13px;font-weight:600;cursor:pointer;transition:background var(--trans);white-space:nowrap;}
.btn-logout:hover{background:rgba(224,92,92,.18);}
.hamburger{display:none;}
.content{flex:1;overflow-y:auto;padding:28px 28px 40px;scrollbar-width:thin;scrollbar-color:var(--border) transparent;}

/* ══════════════════════════════════ PANELS ══════════════════════════════════ */
.panel{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);padding:22px 24px;margin-bottom:0;}
.section-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;}
.section-title{font-family:var(--font-serif);font-size:17px;font-weight:400;color:var(--text);}
.section-link{font-size:12.5px;color:var(--accent);text-decoration:none;font-weight:500;}
.section-link:hover{text-decoration:underline;}

/* ══════════════════════════════════ STAT CARDS ══════════════════════════════════ */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:28px;}
.stat-card{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);padding:20px 22px;display:flex;align-items:flex-start;gap:14px;transition:border-color var(--trans),transform .15s;}
.stat-card:hover{border-color:var(--border-light);transform:translateY(-1px);}
.stat-icon{width:44px;height:44px;border-radius:10px;display:grid;place-items:center;font-size:20px;flex-shrink:0;}
.stat-icon.gold{background:var(--accent-dim);}
.stat-icon.green{background:var(--success-dim);}
.stat-icon.blue{background:var(--blue-dim);}
.stat-icon.warn{background:var(--warn-dim);}
.stat-icon.red{background:var(--danger-dim);}
.stat-body{flex:1;min-width:0;}
.stat-label{font-size:11px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:4px;}
.stat-value{font-family:var(--font-serif);font-size:28px;line-height:1;color:var(--text);margin-bottom:6px;}
.stat-sub{font-size:11.5px;color:var(--text-mid);}
.occ-bar{height:4px;background:var(--border);border-radius:99px;margin-bottom:5px;overflow:hidden;}
.occ-fill{height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2));border-radius:99px;}

/* ══════════════════════════════════ TABLES ══════════════════════════════════ */
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;}
thead tr{border-bottom:1px solid var(--border);}
th{padding:10px 12px;text-align:left;font-size:11px;font-weight:700;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;white-space:nowrap;}
tbody tr{border-bottom:1px solid rgba(31,38,51,.7);transition:background .15s;}
tbody tr:hover{background:rgba(255,255,255,.025);}
tbody tr:last-child{border-bottom:none;}
td{padding:11px 12px;color:var(--text-mid);vertical-align:middle;}
td strong{color:var(--text);font-weight:500;}
.empty-row td{text-align:center;padding:36px;color:var(--muted);font-style:italic;}

/* ══════════════════════════════════ BADGES ══════════════════════════════════ */
.badge{display:inline-block;padding:2px 9px;border-radius:99px;font-size:11px;font-weight:600;text-transform:capitalize;}
.badge-green{background:var(--success-dim);color:var(--success);}
.badge-red{background:var(--danger-dim);color:var(--danger);}
.badge-gold{background:var(--accent-dim);color:var(--accent);}
.badge-blue{background:var(--blue-dim);color:var(--blue);}
.badge-warn{background:var(--warn-dim);color:var(--warn);}
.badge-muted{background:rgba(90,99,128,.2);color:var(--muted);}

/* ══════════════════════════════════ BUTTONS ══════════════════════════════════ */
.btn-primary{padding:9px 18px;background:linear-gradient(135deg,var(--accent),var(--accent2));border:none;border-radius:var(--radius-sm);font-size:13px;font-weight:600;color:#1a1200;cursor:pointer;font-family:var(--font-sans);transition:opacity .2s;}
.btn-primary:hover{opacity:.88;}
.btn-secondary{padding:9px 16px;background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:var(--radius-sm);font-size:13px;color:var(--text-mid);cursor:pointer;font-family:var(--font-sans);transition:background .2s;}
.btn-secondary:hover{background:rgba(255,255,255,.09);}
.btn-ghost{padding:9px 16px;background:transparent;border:1px solid var(--border);border-radius:var(--radius-sm);font-size:13px;color:var(--muted);cursor:pointer;font-family:var(--font-sans);text-decoration:none;transition:background .2s;}
.btn-ghost:hover{background:rgba(255,255,255,.05);}
.btn-danger{padding:9px 18px;background:var(--danger-dim);border:1px solid rgba(224,92,92,.3);border-radius:var(--radius-sm);font-size:13px;font-weight:600;color:var(--danger);cursor:pointer;font-family:var(--font-sans);transition:background .2s;}
.btn-danger:hover{background:rgba(224,92,92,.22);}
.tbl-btn{padding:5px 12px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:6px;font-size:12px;color:var(--text-mid);cursor:pointer;font-family:var(--font-sans);transition:background .15s;}
.tbl-btn:hover{background:rgba(255,255,255,.08);color:var(--text);}
.tbl-btn.danger{color:var(--danger);border-color:rgba(224,92,92,.2);}
.tbl-btn.danger:hover{background:var(--danger-dim);}
.tbl-btn.success{color:var(--success);border-color:rgba(76,175,130,.2);}
.tbl-btn.success:hover{background:var(--success-dim);}

/* ══════════════════════════════════ FORMS ══════════════════════════════════ */
.form-input{width:100%;background:#0d1018;border:1.5px solid var(--border);border-radius:var(--radius-sm);padding:10px 13px;font-size:13.5px;color:var(--text);font-family:var(--font-sans);outline:none;transition:border-color .2s;}
.form-input:focus{border-color:var(--accent);}
.form-input::placeholder{color:#3e4559;}
select.form-input option{background:#131720;}
.field{display:flex;flex-direction:column;gap:6px;}
.field label{font-size:11.5px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.07em;}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;padding:0 24px 20px;}
.field-full{grid-column:1/-1;}
.filter-row{display:flex;align-items:center;gap:12px;flex-wrap:wrap;}

/* ══════════════════════════════════ ALERTS ══════════════════════════════════ */
.alert{padding:12px 16px;border-radius:var(--radius-sm);margin-bottom:20px;font-size:13.5px;}
.alert-success{background:var(--success-dim);border:1px solid rgba(76,175,130,.3);color:var(--success);}
.alert-error{background:var(--danger-dim);border:1px solid rgba(224,92,92,.3);color:var(--danger);}

/* ══════════════════════════════════ MODALS ══════════════════════════════════ */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:9999;display:none;align-items:center;justify-content:center;padding:20px;}
.modal-overlay.active{display:flex;}
.modal{background:var(--panel);border:1px solid var(--border-light);border-radius:14px;width:100%;max-width:560px;max-height:90vh;overflow-y:auto;box-shadow:0 32px 64px rgba(0,0,0,.6);animation:modalIn .2s ease;}
@keyframes modalIn{from{opacity:0;transform:scale(.96) translateY(-8px);}to{opacity:1;transform:scale(1) translateY(0);}}
.modal-header{display:flex;align-items:center;justify-content:space-between;padding:20px 24px 0;}
.modal-title{font-family:var(--font-serif);font-size:18px;color:var(--text);}
.modal-close{background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;padding:4px;}
.modal-close:hover{color:var(--text);}
.modal .form-grid{margin-top:16px;}
.modal-footer{display:flex;justify-content:flex-end;gap:10px;padding:16px 24px 20px;border-top:1px solid var(--border);}

/* ══════════════════════════════════ PAGINATION ══════════════════════════════════ */
.pagination{display:flex;gap:6px;padding-top:16px;justify-content:center;}
.page-btn{padding:6px 12px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:6px;font-size:12px;color:var(--text-mid);text-decoration:none;transition:background .15s;}
.page-btn:hover{background:rgba(255,255,255,.08);}
.page-btn.active{background:var(--accent-dim);border-color:var(--accent);color:var(--accent);}

/* ══════════════════════════════════ CHART ══════════════════════════════════ */
.chart-wrapper{height:220px;position:relative;}
.mid-grid{display:grid;grid-template-columns:1fr 340px;gap:20px;margin-bottom:24px;}
.bottom-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;}
.quick-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.qa-btn{display:flex;align-items:center;gap:10px;padding:13px 15px;background:rgba(255,255,255,.03);border:1px solid var(--border);border-radius:var(--radius-sm);color:var(--text-mid);text-decoration:none;font-size:13px;font-weight:500;transition:background var(--trans),border-color var(--trans),color var(--trans);}
.qa-btn:hover{background:var(--accent-dim);border-color:rgba(232,184,109,.3);color:var(--accent);}

/* ══════════════════════════════════ OVERLAY ══════════════════════════════════ */
.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99;}
.overlay.visible{display:block;}

/* ══════════════════════════════════ RESPONSIVE ══════════════════════════════════ */
@media(max-width:1100px){.stats-grid{grid-template-columns:repeat(2,1fr)!important;}.mid-grid,.bottom-grid{grid-template-columns:1fr;}}
@media(max-width:768px){:root{--sidebar-w:0px;}.sidebar{transform:translateX(-260px);--sidebar-w:260px;}.sidebar.open{transform:translateX(0);}.main{margin-left:0;}.hamburger{display:grid;}.content{padding:18px 16px 32px;}.topbar{padding:0 16px;}.stats-grid{grid-template-columns:1fr 1fr!important;gap:10px;}}
@media(max-width:480px){.stats-grid{grid-template-columns:1fr!important;}.btn-logout span{display:none;}}
</style>