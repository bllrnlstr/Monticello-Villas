<?php
session_start();
require_once __DIR__ . '/db_connection.php';
// db_connection.php loads shared/db.php and shared/queries.php

$method = $_SERVER['REQUEST_METHOD'];
// Action is always in the URL querystring (?action=...)
// For login/logout it falls back to $_POST['action']
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// ── Parse JSON body once (rooms mutations send JSON) ─────────
$input = [];
if ($method === 'POST') {
    $raw   = file_get_contents('php://input');
    $input = json_decode($raw, true) ?? [];
}

// ── Rooms API ─────────────────────────────────────────────────
$roomsActions = ['list', 'get', 'add', 'edit', 'delete', 'toggle'];
if (in_array($action, $roomsActions)) {
    // Auth guard
    if (!isset($_SESSION['admin_id'])) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Unauthorized']);
        exit;
    }
    // Session timeout
    if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > 7200) {
        session_destroy();
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Session expired']);
        exit;
    }
    $_SESSION['login_time'] = time();

    // Origin check — ensure request comes from same origin (replaces CSRF for JSON API)
    if ($method === 'POST') {
        $origin  = $_SERVER['HTTP_ORIGIN']  ?? '';
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        $host    = $_SERVER['HTTP_HOST']    ?? '';
        // Allow if origin matches host OR if no origin header (same-origin fetch)
        if ($origin !== '' && parse_url($origin, PHP_URL_HOST) !== $host) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['success' => false, 'error' => 'Forbidden']);
            exit;
        }
    }

    switch ($action) {
        case 'list':   getRooms();           break;
        case 'get':    getRoom();            break;
        case 'add':    addRoom($input);      break;
        case 'edit':   editRoom($input);     break;
        case 'delete': deleteRoom($input);   break;
        case 'toggle': toggleStatus($input); break;
    }
    exit;
}

// ── Login / Logout (POST only) ────────────────────────────────
if ($method !== 'POST') {
    header('Location: login.php'); exit;
}

if ($action === 'logout') {
    session_destroy();
    header('Location: login.php'); exit;
}

if ($action !== 'login') {
    header('Location: login.php'); exit;
}

// ── CSRF check ────────────────────────────────────────────────
if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== ($_SESSION['csrf_token'] ?? '')) {
    $_SESSION['login_error'] = 'Invalid request. Please try again.';
    header('Location: login.php'); exit;
}

// ── Rate limit (5 attempts per 15 min) ───────────────────────
$attempts  = (int)($_SESSION['login_attempts'] ?? 0);
$firstTime = (int)($_SESSION['first_attempt_ts'] ?? 0);

if ($firstTime > 0 && (time() - $firstTime) > 900) {
    $attempts = 0;
    unset($_SESSION['login_attempts'], $_SESSION['first_attempt_ts']);
}

if ($attempts >= 5) {
    $_SESSION['login_error'] = 'Too many failed attempts. Please wait 15 minutes.';
    header('Location: login.php'); exit;
}

// ── Get input ─────────────────────────────────────────────────
$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    $_SESSION['login_error'] = 'Please enter your username and password.';
    header('Location: login.php'); exit;
}

// ── Fetch user ────────────────────────────────────────────────
$pdo  = getDBConnection();
$stmt = $pdo->prepare(
    'SELECT id, username, password, full_name, role, is_active
     FROM admin_users
     WHERE username = :u1 OR email = :u2
     LIMIT 1'
);
$stmt->execute([':u1' => $username, ':u2' => $username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// ── Verify password ───────────────────────────────────────────
if (!$user || !password_verify($password, $user['password'])) {
    if (empty($_SESSION['first_attempt_ts'])) {
        $_SESSION['first_attempt_ts'] = time();
    }
    $_SESSION['login_attempts'] = $attempts + 1;
    $_SESSION['login_error'] = 'Invalid username or password.';
    header('Location: login.php'); exit;
}

// ── Check active ──────────────────────────────────────────────
if ((int)$user['is_active'] !== 1) {
    $_SESSION['login_error'] = 'This account has been disabled.';
    header('Location: login.php'); exit;
}

// ── Success — set session ─────────────────────────────────────
session_regenerate_id(true);
unset($_SESSION['login_attempts'], $_SESSION['first_attempt_ts']);

$_SESSION['admin_id']   = (int)$user['id'];
$_SESSION['admin_name'] = $user['full_name'];
$_SESSION['admin_role'] = $user['role'];
$_SESSION['login_time'] = time();

// Update last login
$pdo->prepare('UPDATE admin_users SET last_login = NOW() WHERE id = :id')
    ->execute([':id' => $user['id']]);

header('Location: dashboard.php'); exit;



// ══════════════════════════════════════════════════════════════
// READ
// ══════════════════════════════════════════════════════════════

function getRooms(): void {
    $pdo = getDBConnection();

    // Filters from query string
    $status = $_GET['status'] ?? '';
    $type   = $_GET['type']   ?? '';
    $search = trim($_GET['search'] ?? '');

    $where  = [];
    $params = [];

    if ($status !== '' && in_array($status, ['vacant', 'occupied', 'maintenance', 'reserved'])) {
        $where[]           = 'r.status = :status';
        $params[':status'] = $status;
    }
    if ($type !== '') {
        $where[]         = 'r.room_type = :type';
        $params[':type'] = $type;
    }
    if ($search !== '') {
        $where[]           = '(r.room_number LIKE :search OR r.description LIKE :search OR r.amenities LIKE :search)';
        $params[':search'] = '%' . $search . '%';
    }

    $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    // Fetch ALL rooms — no pagination limit
    $stmt = $pdo->prepare(
        "SELECT r.*,
                COALESCE(t.full_name, NULL) AS tenant_name,
                t.id AS tenant_id
         FROM rooms r
         LEFT JOIN tenants t ON t.room_id = r.id AND t.status = 'active'
         $whereClause
         ORDER BY CAST(r.floor AS UNSIGNED) ASC, r.room_number ASC"
    );
    $stmt->execute($params);
    $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Summary counts — all from unified database
    $summary = [];
    $rows = $pdo->query(
        "SELECT status, COUNT(*) AS cnt FROM rooms GROUP BY status"
    )->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) $summary[$row['status']] = (int)$row['cnt'];

    jsonSuccess([
        'rooms'   => $rooms,
        'total'   => count($rooms),
        'summary' => $summary,
    ]);
}

function getRoom(): void {
    $id = (int)($_GET['id'] ?? 0);
    if (!$id) jsonError('Missing room ID');

    $pdo  = getDBConnection();
    $stmt = $pdo->prepare(
        "SELECT r.*,
                COALESCE(t.full_name, NULL) AS tenant_name,
                t.id AS tenant_id
         FROM rooms r
         LEFT JOIN tenants t ON t.room_id = r.id AND t.status = 'active'
         WHERE r.id = :id"
    );
    $stmt->execute([':id' => $id]);
    $room = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$room) jsonError('Room not found', 404);

    // tenant_name is already joined from bms_unified.tenants

    jsonSuccess(['room' => $room]);
}

// ══════════════════════════════════════════════════════════════
// CREATE
// ══════════════════════════════════════════════════════════════

function addRoom(array $input): void {
    $pdo = getDBConnection();

    $data = validateRoomInput($input);

    // Check duplicate room number
    $check = $pdo->prepare('SELECT id FROM rooms WHERE room_number = :rn');
    $check->execute([':rn' => $data['room_number']]);
    if ($check->fetch()) jsonError('Room number already exists');

    $stmt = $pdo->prepare(
        'INSERT INTO rooms (room_number, room_type, floor, capacity, monthly_rate, status, description, amenities)
         VALUES (:room_number, :room_type, :floor, :capacity, :monthly_rate, :status, :description, :amenities)'
    );
    $stmt->execute([
        ':room_number'  => $data['room_number'],
        ':room_type'    => $data['room_type'],
        ':floor'        => $data['floor'],
        ':capacity'     => $data['capacity'],
        ':monthly_rate' => $data['monthly_rate'],
        ':status'       => $data['status'],
        ':description'  => $data['description'],
        ':amenities'    => $data['amenities'],
    ]);

    $newId = (int)$pdo->lastInsertId();
    logAudit("Added room {$data['room_number']} (ID: $newId)");

    jsonSuccess(['id' => $newId, 'message' => 'Room added successfully']);
}

// ══════════════════════════════════════════════════════════════
// UPDATE
// ══════════════════════════════════════════════════════════════

function editRoom(array $input): void {
    $id = (int)($input['id'] ?? 0);
    if (!$id) jsonError('Missing room ID');

    $pdo  = getDBConnection();
    $data = validateRoomInput($input);

    // Check duplicate room number (excluding self)
    $check = $pdo->prepare('SELECT id FROM rooms WHERE room_number = :rn AND id != :id');
    $check->execute([':rn' => $data['room_number'], ':id' => $id]);
    if ($check->fetch()) jsonError('Room number already exists');

    // If status changing away from occupied, make sure no active tenant
    $current = $pdo->prepare('SELECT status FROM rooms WHERE id = :id');
    $current->execute([':id' => $id]);
    $old = $current->fetch(PDO::FETCH_ASSOC);
    if (!$old) jsonError('Room not found', 404);

    if ($old['status'] === 'occupied' && $data['status'] !== 'occupied') {
        $tenant = $pdo->prepare("SELECT id FROM tenants WHERE room_id = :id AND status = 'active' LIMIT 1");
        $tenant->execute([':id' => $id]);
        if ($tenant->fetch()) jsonError('Cannot change status — room has an active tenant');
    }

    $stmt = $pdo->prepare(
        'UPDATE rooms SET
            room_number  = :room_number,
            room_type    = :room_type,
            floor        = :floor,
            capacity     = :capacity,
            monthly_rate = :monthly_rate,
            status       = :status,
            description  = :description,
            amenities    = :amenities
         WHERE id = :id'
    );
    $stmt->execute([
        ':room_number'  => $data['room_number'],
        ':room_type'    => $data['room_type'],
        ':floor'        => $data['floor'],
        ':capacity'     => $data['capacity'],
        ':monthly_rate' => $data['monthly_rate'],
        ':status'       => $data['status'],
        ':description'  => $data['description'],
        ':amenities'    => $data['amenities'],
        ':id'           => $id,
    ]);

    logAudit("Updated room {$data['room_number']} (ID: $id)");
    jsonSuccess(['message' => 'Room updated successfully']);
}

// ══════════════════════════════════════════════════════════════
// DELETE
// ══════════════════════════════════════════════════════════════

function deleteRoom(array $input): void {
    $id = (int)($input['id'] ?? 0);
    if (!$id) jsonError('Missing room ID');

    $pdo = getDBConnection();

    // Block if occupied
    $check = $pdo->prepare("SELECT room_number, status FROM rooms WHERE id = :id");
    $check->execute([':id' => $id]);
    $room = $check->fetch(PDO::FETCH_ASSOC);
    if (!$room) jsonError('Room not found', 404);
    if ($room['status'] === 'occupied') jsonError('Cannot delete an occupied room');
    if ($room['status'] === 'reserved') jsonError('Cannot delete a reserved room');

    // Block if tenant history exists
    $hist = $pdo->prepare('SELECT id FROM tenants WHERE room_id = :id LIMIT 1');
    $hist->execute([':id' => $id]);
    if ($hist->fetch()) jsonError('Cannot delete — room has tenant records. Set to maintenance instead.');

    $pdo->prepare('DELETE FROM rooms WHERE id = :id')->execute([':id' => $id]);
    logAudit("Deleted room {$room['room_number']} (ID: $id)");

    jsonSuccess(['message' => 'Room deleted successfully']);
}

// ══════════════════════════════════════════════════════════════
// TOGGLE STATUS (quick action)
// ══════════════════════════════════════════════════════════════

function toggleStatus(array $input): void {
    $id      = (int)($input['id']    ?? 0);
    $status  = trim($input['status'] ?? '');
    $allowed = ['vacant', 'occupied', 'maintenance', 'reserved'];

    if (!$id) jsonError('Missing room ID');
    if (!in_array($status, $allowed)) jsonError('Invalid status');

    $pdo = getDBConnection();

    // Block marking occupied if no active tenant
    if ($status === 'occupied') {
        $t = $pdo->prepare("SELECT id FROM tenants WHERE room_id = :id AND status='active' LIMIT 1");
        $t->execute([':id' => $id]);
        if (!$t->fetch()) jsonError('Cannot mark occupied — assign a tenant first');
    }

    // Block removing occupied if active tenant exists
    if ($status !== 'occupied') {
        $room = $pdo->prepare("SELECT status FROM rooms WHERE id = :id");
        $room->execute([':id' => $id]);
        $r = $room->fetch(PDO::FETCH_ASSOC);
        if ($r && $r['status'] === 'occupied') {
            $t = $pdo->prepare("SELECT id FROM tenants WHERE room_id = :id AND status='active' LIMIT 1");
            $t->execute([':id' => $id]);
            if ($t->fetch()) jsonError('Cannot change status — room has an active tenant');
        }
    }

    $pdo->prepare('UPDATE rooms SET status = :s WHERE id = :id')
        ->execute([':s' => $status, ':id' => $id]);

    logAudit("Changed room ID $id status to $status");
    jsonSuccess(['message' => 'Status updated']);
}

// ══════════════════════════════════════════════════════════════
// VALIDATION
// ══════════════════════════════════════════════════════════════

function validateRoomInput(array $input): array {
    $roomNumber  = trim($input['room_number']     ?? '');
    $roomType    = trim($input['room_type']       ?? '');
    $floor       = (int)($input['floor']          ?? 1);
    $capacity    = (int)($input['capacity']       ?? 1);
    $monthlyRate = (float)($input['monthly_rate'] ?? 0);
    $status      = trim($input['status']          ?? 'vacant');
    $description = trim($input['description']     ?? '');
    $amenities   = trim($input['amenities']       ?? '');

    $allowedTypes    = ['single', 'double', 'studio', 'dormitory', 'suite'];
    $allowedStatuses = ['vacant', 'occupied', 'maintenance', 'reserved'];

    if ($roomNumber === '')                   jsonError('Room number is required');
    if (strlen($roomNumber) > 20)             jsonError('Room number too long (max 20 chars)');
    if (!in_array($roomType, $allowedTypes))  jsonError('Invalid room type');
    if ($floor < 1 || $floor > 50)           jsonError('Floor must be between 1 and 50');
    if ($capacity < 1 || $capacity > 20)     jsonError('Capacity must be between 1 and 20');
    if ($monthlyRate <= 0)                    jsonError('Monthly rate must be greater than 0');
    if (!in_array($status, $allowedStatuses)) jsonError('Invalid status');

    return [
        'room_number'  => $roomNumber,
        'room_type'    => $roomType,
        'floor'        => $floor,
        'capacity'     => $capacity,
        'monthly_rate' => $monthlyRate,
        'status'       => $status,
        'description'  => $description,
        'amenities'    => $amenities,
    ];
}

// ══════════════════════════════════════════════════════════════
// HELPERS
// ══════════════════════════════════════════════════════════════

function logAudit(string $details): void {
    try {
        $pdo  = getDBConnection();
        $stmt = $pdo->prepare(
            'INSERT INTO audit_logs (admin_id, action, details, ip_address)
             VALUES (:admin_id, :action, :details, :ip)'
        );
        $stmt->execute([
            ':admin_id' => $_SESSION['admin_id'],
            ':action'   => 'ROOMS',
            ':details'  => $details,
            ':ip'       => getClientIp(),
        ]);
    } catch (PDOException $e) {
        error_log('[AUDIT] ' . $e->getMessage());
    }
}

function getClientIp(): string {
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = trim(explode(',', $_SERVER[$k])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '0.0.0.0';
}

function jsonSuccess(array $data): never {
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'data' => $data]);
    exit;
}

function jsonError(string $message, int $code = 400): never {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => $message]);
    exit;
}