<?php

$x=10; 

print (client($x+=1))
;
function client ($x){

return $x;
}


?>