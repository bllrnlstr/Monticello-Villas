<?php
/**
 * admin/inquiries.php — UPDATED
 *
 * KEY CHANGE: The "Accept" action now opens a full setup modal where admin fills:
 *   - Room assignment
 *   - Monthly rent & due day
 *   - Move-in date
 *   - Initial email & password for the tenant
 *
 * On submit, it:
 *   1. Creates/updates the tenant record with approval_status='approved'
 *   2. Sends ONE welcome email with credentials, room, rent, and login link
 *   3. Marks the inquiry as 'converted'
 *
 * All other inquiry actions (add, edit, contact, reject, delete) are unchanged.
 */
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDBConnection();

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

require_once __DIR__ . '/../shared/notifications.php';

$tenantBase = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://'
            . $_SERVER['HTTP_HOST']
            . rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/') . '/tenant';
$inquiryUrl = $tenantBase . '/inquiry.php';
$loginUrl   = $tenantBase . '/index.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';

    // ── ADD ────────────────────────────────────────────────────────
    if ($act === 'add') {
        $name    = trim($_POST['name']      ?? '');
        $email   = trim($_POST['email']     ?? '') ?: null;
        $contact = trim($_POST['contact']   ?? '') ?: null;
        $rt      = trim($_POST['room_type'] ?? '') ?: null;
        $msg     = trim($_POST['message']   ?? '') ?: null;
        $notes   = trim($_POST['notes']     ?? '') ?: null;
        db_execute($pdo, SQL_INQUIRY_INSERT, [$name,$email,$contact,$rt,$msg,'new',$notes]);
        db_audit($pdo, $adminId, 'CREATE_INQUIRY', "Added inquiry from: {$name}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Inquiry added.'];

    // ── EDIT ───────────────────────────────────────────────────────
    } elseif ($act === 'edit') {
        $id      = (int)$_POST['id'];
        $current = db_fetch_one($pdo, "SELECT status FROM inquiries WHERE id=?", [$id]);
        if ($current && $current['status'] !== 'new') {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'This inquiry can no longer be edited.'];
            header('Location: inquiries.php'); exit;
        }
        $name    = trim($_POST['name']      ?? '');
        $email   = trim($_POST['email']     ?? '') ?: null;
        $contact = trim($_POST['contact']   ?? '') ?: null;
        $rt      = trim($_POST['room_type'] ?? '') ?: null;
        $msg     = trim($_POST['message']   ?? '') ?: null;
        $notes   = trim($_POST['notes']     ?? '') ?: null;
        db_execute($pdo, SQL_INQUIRY_UPDATE, [$name,$email,$contact,$rt,$msg,'new',$notes,$id]);
        db_audit($pdo, $adminId, 'UPDATE_INQUIRY', "Updated inquiry id={$id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Inquiry updated.'];

    // ── DELETE ─────────────────────────────────────────────────────
    } elseif ($act === 'delete') {
        $id = (int)$_POST['id'];
        db_execute($pdo, SQL_INQUIRY_DELETE, [$id]);
        db_audit($pdo, $adminId, 'DELETE_INQUIRY', "Deleted inquiry id={$id}");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Inquiry deleted.'];

    // ── CONTACT ────────────────────────────────────────────────────
    } elseif ($act === 'contact') {
        $id = (int)$_POST['id'];
        db_execute($pdo, SQL_INQUIRY_SET_STATUS, ['contacted', $id]);
        db_audit($pdo, $adminId, 'CONTACT_INQUIRY', "Marked inquiry id={$id} as contacted");
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Marked as contacted. You can now Accept or Reject.'];

    // ── ACCEPT + SETUP (NEW UNIFIED FLOW) ──────────────────────────
    } elseif ($act === 'accept_setup') {
        $id       = (int)$_POST['id'];
        $inquiry  = db_fetch_one($pdo, "SELECT * FROM inquiries WHERE id=?", [$id]);

        if (!$inquiry) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Inquiry not found.'];
            header('Location: inquiries.php'); exit;
        }

        // Collect form fields
        $tenantEmail = strtolower(trim($_POST['tenant_email'] ?? $inquiry['email'] ?? ''));
        $password    = trim($_POST['password'] ?? '');
        $roomId      = ($_POST['room_id'] ?? '') ?: null;
        $monthlyRent = (float)str_replace(',', '', $_POST['monthly_rent'] ?? 0);
        $dueDay      = (int)($_POST['monthly_due_day'] ?? 1);
        $moveIn      = ($_POST['move_in_date'] ?? '') ?: null;
        $notes       = trim($_POST['notes'] ?? '') ?: null;

        // Validation
        if (!$tenantEmail || !filter_var($tenantEmail, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'A valid email address is required.'];
            header('Location: inquiries.php'); exit;
        }
        if (strlen($password) < 6) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Password must be at least 6 characters.'];
            header('Location: inquiries.php'); exit;
        }
        if ($monthlyRent <= 0) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Monthly rent must be greater than 0.'];
            header('Location: inquiries.php'); exit;
        }
        if ($dueDay < 1 || $dueDay > 31) {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Due day must be between 1 and 31.'];
            header('Location: inquiries.php'); exit;
        }

        // Get room number from room_id
        $roomNumber = '';
        if ($roomId) {
            $rn = $pdo->prepare("SELECT room_number FROM rooms WHERE id=? LIMIT 1");
            $rn->execute([$roomId]);
            $roomNumber = $rn->fetchColumn() ?: '';
        }

        $passwordHash = password_hash($password, PASSWORD_BCRYPT);

        // Check if tenant already exists with this email
        $existing = db_fetch_one($pdo, "SELECT id FROM tenants WHERE email=? LIMIT 1", [$tenantEmail]);

        if ($existing) {
            // Update existing tenant record
            $pdo->prepare("
                UPDATE tenants SET
                    full_name          = ?,
                    phone              = ?,
                    room_id            = ?,
                    room_number        = ?,
                    monthly_rent       = ?,
                    monthly_due_day    = ?,
                    move_in_date       = ?,
                    approval_status    = 'approved',
                    status             = 'active',
                    password_hash      = ?,
                    notes              = ?,
                    updated_at         = NOW()
                WHERE id = ?
            ")->execute([
                $inquiry['name'], $inquiry['contact'] ?? '',
                $roomId, $roomNumber,
                $monthlyRent, $dueDay, $moveIn,
                $passwordHash, $notes,
                $existing['id']
            ]);
            $tenantId = $existing['id'];
        } else {
            // Insert new tenant
            $pdo->prepare("
                INSERT INTO tenants
                    (full_name, email, phone, room_id, room_number,
                     monthly_rent, monthly_due_day, move_in_date,
                     approval_status, status, password_hash, notes, created_at)
                VALUES (?,?,?,?,?,?,?,?,'approved','active',?,?,NOW())
            ")->execute([
                $inquiry['name'],
                $tenantEmail,
                $inquiry['contact'] ?? '',
                $roomId,
                $roomNumber,
                $monthlyRent,
                $dueDay,
                $moveIn,
                $passwordHash,
                $notes,
            ]);
            $tenantId = (int)$pdo->lastInsertId();
        }

        // Mark room as occupied
        if ($roomId) {
            $pdo->prepare("UPDATE rooms SET status='occupied' WHERE id=?")
                ->execute([$roomId]);
        }

        // Mark inquiry as converted
        db_execute($pdo, SQL_INQUIRY_SET_STATUS, ['converted', $id]);

        // Audit
        db_audit($pdo, $adminId, 'ACCEPT_INQUIRY',
            "Accepted inquiry id={$id} — tenant account created/updated for {$tenantEmail} in room {$roomNumber}");

        // Only send the welcome email if JS confirmed all fields were filled
        $confirmSend = trim($_POST['confirm_send'] ?? '0');
        $emailMsg = '';

        if ($confirmSend === '1') {
            [$ok, $err] = notify_registration_approved(
                $tenantEmail,
                $inquiry['name'],
                $tenantEmail,
                $password,
                $roomNumber ?: 'TBA',
                $monthlyRent,
                $dueDay,
                $moveIn ?? '',
                $loginUrl
            );
            $emailMsg = $ok
                ? " Welcome email with credentials sent to {$tenantEmail}."
                : " (Email failed: {$err} — please share credentials manually.)";
        } else {
            // Setup was saved but email was NOT sent (form was incomplete on client)
            $emailMsg = ' (Email not sent — the setup form was incomplete. Go to Tenants to resend credentials manually.)';
        }

        $_SESSION['flash'] = [
            'type' => 'success',
            'msg'  => "✅ {$inquiry['name']} has been approved and their account is set up.{$emailMsg}",
        ];

    // ── REJECT ─────────────────────────────────────────────────────
    } elseif ($act === 'reject') {
        $id      = (int)$_POST['id'];
        $reason  = trim($_POST['rejection_reason'] ?? '');
        $inquiry = db_fetch_one($pdo, "SELECT * FROM inquiries WHERE id=?", [$id]);

        if ($inquiry) {
            db_execute($pdo, SQL_INQUIRY_SET_STATUS, ['closed', $id]);
            if ($reason) {
                $pdo->prepare("UPDATE inquiries SET notes=? WHERE id=?")->execute([$reason, $id]);
            }
            db_audit($pdo, $adminId, 'REJECT_INQUIRY', "Rejected inquiry id={$id}");

            $notifMsg = '';
            if (!empty($inquiry['email'])) {
                [$ok, $err] = notify_inquiry_closed($inquiry['email'], $inquiry['name'], $inquiryUrl);
                $notifMsg = $ok
                    ? ' Rejection email sent to ' . $inquiry['email'] . '.'
                    : ' (Email failed: ' . $err . ')';
            }
            $_SESSION['flash'] = ['type'=>'success','msg'=>"❌ Inquiry rejected for {$inquiry['name']}.{$notifMsg}"];
        } else {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Inquiry not found.'];
        }
    }

    header('Location: inquiries.php'); exit;
}

// ── Fetch ──────────────────────────────────────────────────────────
$filterStatus = $_GET['status'] ?? '';
$search  = trim($_GET['q'] ?? '');
$page    = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;

$sql    = SQL_INQUIRIES_LIST;
$params = [];
if ($filterStatus !== '') { $sql .= SQL_INQUIRIES_LIST_STATUS_APPEND; $params[] = $filterStatus; }
if ($search !== '') {
    $sql .= SQL_INQUIRIES_LIST_SEARCH_APPEND;
    $params[] = "%{$search}%"; $params[] = "%{$search}%";
    $params[] = "%{$search}%"; $params[] = "%{$search}%";
}
$sql .= SQL_INQUIRIES_LIST_ORDER;

$paginated = db_paginate($pdo, $sql, $params, $page, $perPage);
$inquiries = $paginated['rows'];
$total     = $paginated['total'];
$pages     = $paginated['pages'];

$summaryRows = db_fetch_all($pdo, SQL_INQUIRIES_SUMMARY);
$summaryRow  = $summaryRows[0] ?? [];
$summary = [
    'new'       => (int)($summaryRow['new_count']       ?? 0),
    'contacted' => (int)($summaryRow['contacted_count'] ?? 0),
    'converted' => (int)($summaryRow['converted_count'] ?? 0),
    'total'     => (int)($summaryRow['total']           ?? 0),
];

// For the accept modal room dropdown
$rooms    = db_fetch_all($pdo, "SELECT id, room_number, room_type, monthly_rate FROM rooms WHERE status='vacant' ORDER BY room_number ASC");
$navStats = db_nav_stats($pdo);
$activeNav = 'inquiries';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Inquiries — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
<style>
.inq-modal{background:var(--panel);border:1px solid var(--border);border-radius:var(--radius);width:100%;max-width:560px;box-shadow:0 24px 48px rgba(0,0,0,.5);max-height:90vh;overflow-y:auto;}
.inq-modal-header{padding:20px 24px 0;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;background:var(--panel);z-index:2;padding-bottom:12px;border-bottom:1px solid var(--border);}
.inq-modal-title{font-family:var(--font-serif);font-size:19px;color:var(--text);}
.inq-modal-close{background:none;border:none;color:var(--muted);font-size:18px;cursor:pointer;padding:4px;}
.inq-modal-body{padding:20px 24px;}
.inq-modal-footer{padding:14px 24px;border-top:1px solid var(--border);display:flex;gap:10px;justify-content:flex-end;position:sticky;bottom:0;background:var(--panel);}
.setup-section{margin-bottom:18px;}
.setup-section-label{font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.12em;color:var(--muted);margin-bottom:10px;display:flex;align-items:center;gap:6px;}
.setup-section-label::after{content:'';flex:1;height:1px;background:var(--border);}
.inquiry-summary{display:flex;align-items:center;gap:10px;padding:10px 14px;background:var(--panel-raised);border:1px solid var(--border);border-radius:6px;margin-bottom:16px;font-size:13px;color:var(--text-mid);}
.inquiry-summary strong{color:var(--text);}
.pw-toggle{position:absolute;right:.75rem;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--muted);cursor:pointer;font-size:.75rem;padding:4px 6px;}
.action-badge{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:99px;font-size:11px;font-weight:700;}
.action-badge.accepted{background:rgba(76,175,130,.12);color:var(--success);border:1px solid rgba(76,175,130,.25);}
.action-badge.rejected{background:rgba(224,92,92,.1);color:var(--danger);border:1px solid rgba(224,92,92,.2);}
.msg-preview{background:var(--panel-raised);border:1px solid var(--border);border-radius:6px;padding:14px 16px;font-size:13px;color:var(--text-mid);line-height:1.7;white-space:pre-wrap;margin-bottom:14px;max-height:180px;overflow-y:auto;}
.recipient-info{display:flex;align-items:center;gap:8px;padding:10px 14px;background:var(--panel-raised);border:1px solid var(--border);border-radius:6px;margin-bottom:14px;font-size:13px;color:var(--text-mid);}
.recipient-info strong{color:var(--text);}
</style>
</head>
<body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <button class="icon-btn hamburger" onclick="openSidebar()">☰</button>
    <div class="topbar-left"><h2>Inquiries</h2><p>Manage room booking inquiries</p></div>
  </div>
  <div class="topbar-actions">
    <button class="btn-primary" onclick="openModal('addModal')">+ Add Inquiry</button>
    <form method="POST" action="process.php" style="margin:0;">
      <input type="hidden" name="action" value="logout">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
      <button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button>
    </form>
  </div>
</header>

<div class="content">

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?>">
  <?= htmlspecialchars($flash['msg'], ENT_QUOTES, 'UTF-8') ?>
</div>
<?php endif; ?>

<!-- Stats -->
<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);">
  <div class="stat-card"><div class="stat-icon red">📬</div><div class="stat-body"><div class="stat-label">New</div><div class="stat-value"><?= $summary['new'] ?></div></div></div>
  <div class="stat-card"><div class="stat-icon warn">📞</div><div class="stat-body"><div class="stat-label">Contacted</div><div class="stat-value"><?= $summary['contacted'] ?></div></div></div>
  <div class="stat-card"><div class="stat-icon green">✅</div><div class="stat-body"><div class="stat-label">Converted</div><div class="stat-value"><?= $summary['converted'] ?></div></div></div>
  <div class="stat-card"><div class="stat-icon blue">📋</div><div class="stat-body"><div class="stat-label">Total</div><div class="stat-value"><?= $summary['total'] ?></div></div></div>
</div>

<!-- Filters -->
<div class="panel" style="margin-bottom:20px;">
  <form method="GET" class="filter-row">
    <input type="text" name="q" class="form-input" placeholder="Search name, email, message…"
           value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:260px;">
    <select name="status" class="form-input" style="max-width:150px;">
      <option value="">All Statuses</option>
      <?php foreach(['new','contacted','converted','closed'] as $s): ?>
      <option value="<?=$s?>" <?=$filterStatus===$s?'selected':''?>><?= ucfirst($s) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn-secondary">Filter</button>
    <a href="inquiries.php" class="btn-ghost">Clear</a>
  </form>
</div>

<!-- Table -->
<div class="panel">
  <div class="section-header">
    <span class="section-title">Inquiries <small style="color:var(--muted);font-size:13px;">(<?= $total ?>)</small></span>
  </div>
  <div class="table-wrap"><table>
    <thead>
      <tr><th>#</th><th>Name</th><th>Contact</th><th>Room Type</th><th>Message</th><th>Facebook</th><th>Status</th><th>Date</th><th>Actions</th></tr>
    </thead>
    <tbody>
    <?php if (empty($inquiries)): ?>
      <tr class="empty-row"><td colspan="9">No inquiries found.</td></tr>
    <?php else: foreach($inquiries as $i):
      $iMap = ['new'=>'badge-red','contacted'=>'badge-warn','converted'=>'badge-green','closed'=>'badge-muted'];
      $ic   = $iMap[$i['status']] ?? 'badge-muted';
    ?>
    <tr>
      <td style="color:var(--muted)">#<?= $i['id'] ?></td>
      <td>
        <strong><?= htmlspecialchars($i['name'],ENT_QUOTES,'UTF-8') ?></strong><br>
        <small style="color:var(--muted)"><?= htmlspecialchars($i['email']??'—',ENT_QUOTES,'UTF-8') ?></small>
      </td>
      <td><?= htmlspecialchars($i['contact']??'—',ENT_QUOTES,'UTF-8') ?></td>
      <td><?= htmlspecialchars($i['room_type']??'—',ENT_QUOTES,'UTF-8') ?></td>
      <td><small style="color:var(--text-mid)"><?= htmlspecialchars(substr($i['message']??'',0,80),ENT_QUOTES,'UTF-8') ?><?= strlen($i['message']??'')>80?'…':'' ?></small></td>
      <td>
        <?php if (!empty($i['fb_link'])): ?>
        <a href="<?= htmlspecialchars($i['fb_link'],ENT_QUOTES,'UTF-8') ?>" target="_blank" rel="noopener"
           style="display:inline-flex;align-items:center;gap:4px;padding:4px 9px;background:rgba(24,119,242,0.1);border:1px solid rgba(24,119,242,0.25);border-radius:4px;font-size:11px;color:#60a5fa;text-decoration:none;">
          👤 Facebook
        </a>
        <?php else: ?><span style="font-size:11px;color:var(--muted);">—</span><?php endif; ?>
      </td>
      <td><span class="badge <?= $ic ?>"><?= ucfirst($i['status']) ?></span></td>
      <td><?= date('M j, Y', strtotime($i['created_at'])) ?></td>
      <td style="white-space:nowrap;">

        <?php if ($i['status'] === 'new'): ?>
          <form method="POST" style="display:inline;">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
            <input type="hidden" name="act" value="contact">
            <input type="hidden" name="id" value="<?= $i['id'] ?>">
            <button type="submit" class="tbl-btn success">📞 Contact</button>
          </form>
          <button class="tbl-btn" onclick='openEdit(<?= htmlspecialchars(json_encode($i, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT), ENT_QUOTES, 'UTF-8') ?>)'>Edit</button>

        <?php elseif ($i['status'] === 'contacted'): ?>
          <!-- NEW: Opens setup modal instead of just sending invite -->
          <button class="tbl-btn success"
            onclick="openSetupModal(<?= htmlspecialchars(json_encode($i, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT), ENT_QUOTES, 'UTF-8') ?>)">
            ✅ Accept &amp; Setup
          </button>
          <button class="tbl-btn danger"
            onclick="openRejectModal(<?= $i['id'] ?>,'<?= htmlspecialchars(addslashes($i['name']),ENT_QUOTES,'UTF-8') ?>','<?= htmlspecialchars(addslashes($i['email']??''),ENT_QUOTES,'UTF-8') ?>')">
            ✕ Reject
          </button>

        <?php elseif ($i['status'] === 'converted'): ?>
          <span class="action-badge accepted">✅ Accepted</span>

        <?php elseif ($i['status'] === 'closed'): ?>
          <span class="action-badge rejected">✕ Rejected</span>
        <?php endif; ?>

        <form method="POST" style="display:inline;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
          <input type="hidden" name="act" value="delete">
          <input type="hidden" name="id" value="<?= $i['id'] ?>">
          <button type="submit" class="tbl-btn danger"
                  onclick="return confirm('Delete inquiry #<?= $i['id'] ?>?')">Del</button>
        </form>
      </td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table></div>
  <?php if ($pages>1): ?>
  <div class="pagination">
    <?php for($p=1;$p<=$pages;$p++): ?>
    <a href="?page=<?=$p?>&q=<?=urlencode($search)?>&status=<?=urlencode($filterStatus)?>"
       class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>
</div></div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="addModal"><div class="modal">
  <div class="modal-header"><span class="modal-title">Add Inquiry</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
    <input type="hidden" name="act" value="add">
    <div class="form-grid">
      <div class="field"><label>Name *</label><input type="text" name="name" class="form-input" required></div>
      <div class="field"><label>Email</label><input type="email" name="email" class="form-input"></div>
      <div class="field"><label>Contact</label><input type="text" name="contact" class="form-input"></div>
      <div class="field"><label>Room Type Interest</label>
        <select name="room_type" class="form-input"><option value="">— Any —</option>
          <?php foreach(['Single','Double','Triple','Studio','Family','Dormitory'] as $t): ?><option><?=$t?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field field-full"><label>Message</label><textarea name="message" class="form-input" rows="3"></textarea></div>
      <div class="field field-full"><label>Admin Notes</label><textarea name="notes" class="form-input" rows="2"></textarea></div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn-ghost" onclick="closeModal('addModal')">Cancel</button>
      <button type="submit" class="btn-primary">Add</button>
    </div>
  </form>
</div></div>

<!-- EDIT MODAL -->
<div class="modal-overlay" id="editModal"><div class="modal">
  <div class="modal-header"><span class="modal-title">Edit Inquiry</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
  <form method="POST">
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
    <input type="hidden" name="act" value="edit">
    <input type="hidden" name="id" id="e_id">
    <div class="form-grid">
      <div class="field"><label>Name *</label><input type="text" name="name" id="e_name" class="form-input" required></div>
      <div class="field"><label>Email</label><input type="email" name="email" id="e_email" class="form-input"></div>
      <div class="field"><label>Contact</label><input type="text" name="contact" id="e_contact" class="form-input"></div>
      <div class="field"><label>Room Type</label>
        <select name="room_type" id="e_rt" class="form-input"><option value="">— Any —</option>
          <?php foreach(['Single','Double','Triple','Studio','Family','Dormitory'] as $t): ?><option><?=$t?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field field-full"><label>Message</label><textarea name="message" id="e_msg" class="form-input" rows="3"></textarea></div>
      <div class="field field-full"><label>Admin Notes</label><textarea name="notes" id="e_notes" class="form-input" rows="2"></textarea></div>
    </div>
    <div class="modal-footer">
      <button type="button" class="btn-ghost" onclick="closeModal('editModal')">Cancel</button>
      <button type="submit" class="btn-primary">Save</button>
    </div>
  </form>
</div></div>

<!-- ══════════════════════════════════════════════════════════
     ACCEPT & SETUP MODAL — The main new feature
════════════════════════════════════════════════════════════ -->
<div class="modal-overlay" id="setupModal">
  <div class="inq-modal">
    <div class="inq-modal-header">
      <span class="inq-modal-title">✅ Accept &amp; Setup Tenant Account</span>
      <button class="inq-modal-close" onclick="closeModal('setupModal')">✕</button>
    </div>

    <form method="POST" id="setupForm">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
      <input type="hidden" name="act" value="accept_setup">
      <input type="hidden" name="id" id="setup_id">

      <div class="inq-modal-body">

        <!-- Inquiry summary -->
        <div class="inquiry-summary">
          👤 <div>
            <strong id="setup_name_display">—</strong><br>
            <span id="setup_contact_display" style="font-size:12px;"></span>
          </div>
        </div>

        <!-- SECTION: Account Credentials -->
        <div class="setup-section">
          <div class="setup-section-label">🔐 Login Credentials</div>
          <div class="form-grid">
            <div class="field field-full">
              <label>Tenant Email (Login) *</label>
              <input type="email" name="tenant_email" id="setup_email" class="form-input"
                     placeholder="Tenant's email address" required>
              <small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">This will be their username to log in.</small>
            </div>
            <div class="field field-full">
              <label>Initial Password *</label>
              <div style="position:relative;">
                <input type="text" name="password" id="setup_password" class="form-input"
                       placeholder="Set a password (min. 6 characters)" required minlength="6"
                       style="padding-right:80px;">
                <button type="button" onclick="generatePassword()"
                        style="position:absolute;right:8px;top:50%;transform:translateY(-50%);padding:4px 10px;background:var(--accent-dim);border:1px solid var(--accent);border-radius:4px;color:var(--accent);font-size:11px;font-weight:700;cursor:pointer;font-family:var(--font-sans);">
                  Generate
                </button>
              </div>
              <small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">This will be included in the welcome email sent to the tenant.</small>
            </div>
          </div>
        </div>

        <!-- SECTION: Room & Rent -->
        <div class="setup-section">
          <div class="setup-section-label">🏠 Room &amp; Rent Assignment</div>
          <div class="form-grid">
            <div class="field">
              <label>Assign Room</label>
              <select name="room_id" id="setup_room" class="form-input" onchange="fillRoomRate(this)">
                <option value="">— No room yet —</option>
                <?php foreach($rooms as $r): ?>
                <option value="<?=$r['id']?>" data-rate="<?=$r['monthly_rate']?>">
                  Room <?= htmlspecialchars($r['room_number'],ENT_QUOTES,'UTF-8') ?>
                  (<?= ucfirst($r['room_type']) ?>) — ₱<?= number_format($r['monthly_rate'],0) ?>
                </option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="field">
              <label>Move-In Date</label>
              <input type="date" name="move_in_date" id="setup_movein" class="form-input"
                     min="<?= date('Y-m-d') ?>">
            </div>
            <div class="field">
              <label>Monthly Rent (₱) *</label>
              <input type="number" name="monthly_rent" id="setup_rent" class="form-input"
                     step="0.01" min="1" placeholder="0.00" required>
            </div>
            <div class="field">
              <label>Rent Due Day *</label>
              <input type="number" name="monthly_due_day" id="setup_dueday" class="form-input"
                     min="1" max="31" placeholder="e.g. 5" required value="5">
              <small style="color:var(--muted);font-size:11px;margin-top:3px;display:block;">Day of the month rent is due.</small>
            </div>
          </div>
        </div>

        <!-- SECTION: Notes -->
        <div class="setup-section">
          <div class="setup-section-label">📝 Notes (optional)</div>
          <textarea name="notes" class="form-input" rows="2"
                    placeholder="Any notes for this tenant's record…"></textarea>
        </div>

        <!-- What will be emailed -->
        <div style="padding:12px 14px;background:rgba(76,175,130,.07);border:1px solid rgba(76,175,130,.2);border-radius:6px;font-size:12px;color:var(--text-mid);line-height:1.65;">
          📧 <strong style="color:var(--success);">What the tenant will receive:</strong>
          Their login email, password, assigned room, monthly rent, due date, move-in date, and a direct link to the tenant portal — all in one welcome email.
        </div>

      </div>

      <div id="setup_errors" style="display:none;margin:0 0 12px;padding:10px 14px;background:rgba(224,92,92,.08);border:1px solid rgba(224,92,92,.25);border-radius:6px;font-size:12.5px;color:#fca5a5;line-height:1.7;"></div>

      <div class="inq-modal-footer">
        <button type="button" class="btn-ghost" onclick="closeModal('setupModal')">Cancel</button>
        <button type="button" class="btn-primary" onclick="submitSetup()">✅ Approve &amp; Send Credentials</button>
      </div>
      <!-- confirm_send is only set to 1 by JS after all fields are validated -->
      <input type="hidden" name="confirm_send" id="confirm_send" value="0">
    </form>
  </div>
</div>

<!-- REJECT MODAL -->
<div class="modal-overlay" id="rejectModal">
  <div class="inq-modal">
    <div class="inq-modal-header">
      <span class="inq-modal-title">✕ Reject Inquiry</span>
      <button class="inq-modal-close" onclick="closeModal('rejectModal')">✕</button>
    </div>
    <div class="inq-modal-body">
      <div class="recipient-info">📧 Sending rejection email to: <strong id="reject_recipient"></strong></div>
      <div class="msg-preview" id="reject_preview"></div>
      <div class="field" style="margin-top:14px;">
        <label style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);display:block;margin-bottom:6px;">
          Reason <span style="font-weight:400;text-transform:none;letter-spacing:0;color:var(--muted)">(optional)</span>
        </label>
        <textarea id="reject_reason_input" class="form-input" rows="3"
                  placeholder="e.g. No available rooms at the moment…"
                  oninput="updateRejectPreview()"></textarea>
      </div>
    </div>
    <form method="POST" id="rejectForm">
      <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>">
      <input type="hidden" name="act" value="reject">
      <input type="hidden" name="id" id="reject_id">
      <input type="hidden" name="rejection_reason" id="reject_reason_hidden">
      <div class="inq-modal-footer">
        <button type="button" class="btn-ghost" onclick="closeModal('rejectModal')">Cancel</button>
        <button type="submit" class="btn-danger" onclick="syncRejectReason()">✕ Confirm Rejection</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(id)  { document.getElementById(id).classList.add('active'); }
function closeModal(id) { document.getElementById(id).classList.remove('active'); }
document.querySelectorAll('.modal-overlay').forEach(o =>
  o.addEventListener('click', e => { if (e.target === o) o.classList.remove('active'); })
);

function openEdit(i) {
  document.getElementById('e_id').value      = i.id;
  document.getElementById('e_name').value    = i.name    || '';
  document.getElementById('e_email').value   = i.email   || '';
  document.getElementById('e_contact').value = i.contact || '';
  document.getElementById('e_rt').value      = i.room_type || '';
  document.getElementById('e_msg').value     = i.message || '';
  document.getElementById('e_notes').value   = i.notes   || '';
  openModal('editModal');
}

// Open the new Accept & Setup modal
function openSetupModal(i) {
  document.getElementById('setup_id').value = i.id;
  document.getElementById('setup_name_display').textContent = i.name || '—';
  document.getElementById('setup_contact_display').textContent =
    [i.email, i.contact].filter(Boolean).join('  ·  ');
  document.getElementById('setup_email').value    = i.email || '';
  document.getElementById('setup_password').value = '';
  document.getElementById('setup_rent').value     = '';
  document.getElementById('setup_room').value     = '';
  document.getElementById('setup_movein').value   = '';
  document.getElementById('setup_dueday').value   = '5';
  document.getElementById('confirm_send').value   = '0';
  document.getElementById('setup_errors').style.display = 'none';
  document.getElementById('setup_errors').innerHTML = '';
  openModal('setupModal');
}

// Validate all fields before allowing form submission
function submitSetup() {
  const errors = [];

  const email    = document.getElementById('setup_email').value.trim();
  const password = document.getElementById('setup_password').value.trim();
  const rent     = parseFloat(document.getElementById('setup_rent').value);
  const dueDay   = parseInt(document.getElementById('setup_dueday').value);
  const moveIn   = document.getElementById('setup_movein').value.trim();
  const room     = document.getElementById('setup_room').value;

  // Email
  if (!email) {
    errors.push('Email address is required.');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    errors.push('Please enter a valid email address.');
  }

  // Password
  if (!password) {
    errors.push('Password is required.');
  } else if (password.length < 6) {
    errors.push('Password must be at least 6 characters.');
  }

  // Room
  if (!room) {
    errors.push('Please assign a room before approving.');
  }

  // Monthly rent
  if (!rent || rent <= 0) {
    errors.push('Monthly rent must be greater than 0.');
  }

  // Due day
  if (!dueDay || dueDay < 1 || dueDay > 31) {
    errors.push('Rent due day must be between 1 and 31.');
  }

  // Move-in date
  if (!moveIn) {
    errors.push('Move-in date is required.');
  }

  const errBox = document.getElementById('setup_errors');
  if (errors.length > 0) {
    errBox.innerHTML = '<strong>Please fix the following before sending:</strong><br>' + errors.map(e => '• ' + e).join('<br>');
    errBox.style.display = 'block';
    errBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    return;
  }

  // All valid — set confirm flag and submit
  errBox.style.display = 'none';
  document.getElementById('confirm_send').value = '1';
  document.getElementById('setupForm').submit();
}

// Auto-fill rent from selected room
function fillRoomRate(sel) {
  const rate = sel.options[sel.selectedIndex].getAttribute('data-rate');
  if (rate) document.getElementById('setup_rent').value = parseFloat(rate).toFixed(2);
}

// Generate a random readable password
function generatePassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let pw = '';
  for (let i = 0; i < 8; i++) pw += chars[Math.floor(Math.random() * chars.length)];
  document.getElementById('setup_password').value = pw;
}

// Reject modal
let _rejectName = '';
function openRejectModal(id, name, email) {
  _rejectName = name;
  document.getElementById('reject_id').value              = id;
  document.getElementById('reject_recipient').textContent = name + ' <' + email + '>';
  document.getElementById('reject_reason_input').value    = '';
  updateRejectPreview();
  openModal('rejectModal');
}
function updateRejectPreview() {
  const reason = document.getElementById('reject_reason_input').value.trim();
  const reasonLine = reason ? `\nReason: ${reason}\n` : '';
  document.getElementById('reject_preview').textContent =
    `Dear ${_rejectName},\n\nThank you for your interest in renting with us.\n\n` +
    `We regret to inform you that your room inquiry has not been approved at this time.` +
    reasonLine + `\n` +
    `If you would like to try again, please feel free to submit a new inquiry.\n\n` +
    `— The Management Team`;
}
function syncRejectReason() {
  document.getElementById('reject_reason_hidden').value =
    document.getElementById('reject_reason_input').value.trim();
}

function openSidebar()  { document.getElementById('sidebar').classList.add('open');    document.getElementById('overlay').classList.add('visible'); }
function closeSidebar() { document.getElementById('sidebar').classList.remove('open'); document.getElementById('overlay').classList.remove('visible'); }
</script>
</body>
</html>