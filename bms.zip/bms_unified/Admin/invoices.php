<?php
session_start();
require_once __DIR__ . '/db_connection.php';
if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time()-$_SESSION['login_time'])>7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();
if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo     = getDBConnection();

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) die('Invalid CSRF');
    $act = $_POST['act'] ?? '';
    if ($act === 'generate_monthly') {
        $created = db_generate_monthly_invoices($pdo, (int)date('n'), (int)date('Y'));
        db_audit($pdo, $adminId, 'GENERATE_INVOICES', "Generated {$created} invoice(s) for " . date('F Y'));
        $_SESSION['flash'] = ['type'=>'success','msg'=>"Generated {$created} invoice(s) for " . date('F Y') . "."];
    }
    header('Location: invoices.php'); exit;
}

// List payments as invoices
$filterStatus = $_GET['status'] ?? ''; $search = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1)); $perPage = 25;

$sql    = SQL_PAYMENTS_LIST;
$params = [];
if ($filterStatus !== '') { $sql .= SQL_PAYMENTS_LIST_STATUS_APPEND; $params[] = $filterStatus; }
if ($search !== '') {
    $sql .= " AND (t.full_name LIKE ? OR r.room_number LIKE ?)";
    $params[] = "%{$search}%"; $params[] = "%{$search}%";
}
$sql .= " ORDER BY p.due_date DESC, p.created_at DESC";

$paginated = db_paginate($pdo, $sql, $params, $page, $perPage);
$invoices  = $paginated['rows'];
$total     = $paginated['total'];
$pages     = $paginated['pages'];

$navStats  = db_nav_stats($pdo);
$activeNav = 'invoices';
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Invoices — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?></head><body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;"><button class="icon-btn hamburger" onclick="openSidebar()">☰</button><div class="topbar-left"><h2>Invoices</h2><p>Monthly rent invoices &amp; billing</p></div></div>
  <div class="topbar-actions">
    <form method="POST" style="margin:0;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="generate_monthly"><button type="submit" class="btn-primary" onclick="return confirm('Generate invoices for all active tenants for <?= date('F Y') ?>?')">⚡ Generate Monthly Invoices</button></form>
    <form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form>
  </div>
</header>
<div class="content">
<?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div><?php endif; ?>
<div class="panel" style="margin-bottom:20px;background:var(--panel-raised);border-color:rgba(232,184,109,.2);">
  <p style="color:var(--text-mid);font-size:13.5px;">💡 Click <strong style="color:var(--accent)">Generate Monthly Invoices</strong> to automatically create pending rent bills for all active tenants for <strong><?= date('F Y') ?></strong>. Existing invoices for this month will be skipped.</p>
</div>
<div class="panel" style="margin-bottom:20px;"><form method="GET" class="filter-row">
  <input type="text" name="q" class="form-input" placeholder="Search tenant or room…" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:240px;">
  <select name="status" class="form-input" style="max-width:150px;"><option value="">All Statuses</option><?php foreach(['paid','pending','overdue','partial'] as $s): ?><option value="<?=$s?>" <?=$filterStatus===$s?'selected':''?>><?= ucfirst($s) ?></option><?php endforeach; ?></select>
  <button type="submit" class="btn-secondary">Filter</button><a href="invoices.php" class="btn-ghost">Clear</a>
</form></div>
<div class="panel">
  <div class="section-header"><span class="section-title">Invoice List <small style="color:var(--muted);font-size:13px;">(<?= $total ?>)</small></span></div>
  <div class="table-wrap"><table>
    <thead><tr><th>INV #</th><th>Tenant</th><th>Room</th><th>Type</th><th>Amount</th><th>Due Date</th><th>Paid At</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
    <?php if(empty($invoices)): ?><tr class="empty-row"><td colspan="9">No invoices found.</td></tr>
    <?php else: foreach($invoices as $inv):
      $pMap=['paid'=>'badge-green','pending'=>'badge-warn','overdue'=>'badge-red','partial'=>'badge-blue','waived'=>'badge-muted']; $pc=$pMap[$inv['status']]??'badge-muted';
      $overdue=$inv['status']==='pending' && $inv['due_date'] && strtotime($inv['due_date'])<time(); ?>
    <tr>
      <td style="color:var(--muted)">INV-<?= str_pad($inv['id'],5,'0',STR_PAD_LEFT) ?></td>
      <td><strong><?= htmlspecialchars($inv['tenant_name']??'Unknown',ENT_QUOTES,'UTF-8') ?></strong><br><small style="color:var(--muted)"><?= htmlspecialchars($inv['tenant_email']??'',ENT_QUOTES,'UTF-8') ?></small></td>
      <td><?= htmlspecialchars($inv['room_number']??'—',ENT_QUOTES,'UTF-8') ?></td>
      <td><?= ucfirst($inv['type']) ?></td>
      <td><strong>₱<?= number_format($inv['amount'],2) ?></strong></td>
      <td><?= $inv['due_date']?'<span '.($overdue?'style="color:var(--danger)"':'').'>'.date('M j, Y',strtotime($inv['due_date'])).'</span>':'—'?></td>
      <td><?= $inv['paid_at']?date('M j, Y',strtotime($inv['paid_at'])):'—' ?></td>
      <td><span class="badge <?=$pc?>"><?=$inv['status']?></span></td>
      <td>
        <button class="tbl-btn" onclick="printInvoice(<?= json_encode($inv) ?>)">🖨 Print</button>
        <?php if($inv['status']!=='paid'): ?><form method="POST" action="payments.php" style="display:inline;"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="mark_paid"><input type="hidden" name="id" value="<?=$inv['id']?>"><button type="submit" class="tbl-btn success">✓ Paid</button></form><?php endif; ?>
      </td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table></div>
  <?php if($pages>1): ?><div class="pagination"><?php for($i=1;$i<=$pages;$i++): ?><a href="?page=<?=$i?>&q=<?=urlencode($search)?>&status=<?=urlencode($filterStatus)?>" class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?>
</div>
</div></div>

<!-- PRINT MODAL -->
<div class="modal-overlay" id="printModal">
<div class="modal" style="max-width:480px;" id="invoicePrintArea">
  <div class="modal-header" style="border-bottom:1px solid var(--border);padding-bottom:16px;">
    <span class="modal-title">🏠 BH Management System</span>
    <button class="modal-close" onclick="closeModal('printModal')">✕</button>
  </div>
  <div style="padding:20px 24px;">
    <div style="display:flex;justify-content:space-between;margin-bottom:20px;">
      <div><div style="font-size:20px;font-weight:700;color:var(--accent)" id="p_inv_no">INV-00001</div><div style="font-size:12px;color:var(--muted)">Payment Invoice</div></div>
      <div style="text-align:right;font-size:13px;color:var(--text-mid)"><div>Due: <strong id="p_due"></strong></div><div>Status: <span id="p_status"></span></div></div>
    </div>
    <table style="width:100%;border-collapse:collapse;margin-bottom:16px;">
      <tr><td style="padding:6px 0;color:var(--muted);font-size:12px;width:120px;">Tenant</td><td style="font-weight:500" id="p_tenant"></td></tr>
      <tr><td style="padding:6px 0;color:var(--muted);font-size:12px;">Room</td><td id="p_room"></td></tr>
      <tr><td style="padding:6px 0;color:var(--muted);font-size:12px;">Type</td><td id="p_type"></td></tr>
      <tr><td style="padding:6px 0;color:var(--muted);font-size:12px;">Amount</td><td style="font-size:18px;font-weight:700;color:var(--accent)" id="p_amount"></td></tr>
      <tr><td style="padding:6px 0;color:var(--muted);font-size:12px;">Method</td><td id="p_method"></td></tr>
    </table>
    <div style="border-top:1px solid var(--border);padding-top:12px;font-size:11px;color:var(--muted);text-align:center;">Thank you for your payment. Please keep this receipt for your records.</div>
  </div>
  <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('printModal')">Close</button><button class="btn-primary" onclick="window.print()">🖨 Print</button></div>
</div></div>

<script>
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
function printInvoice(inv){
  document.getElementById('p_inv_no').textContent='INV-'+String(inv.id).padStart(5,'0');
  document.getElementById('p_tenant').textContent=inv.tenant_name||'—';
  document.getElementById('p_room').textContent=(inv.room_number||'—')+' '+(inv.room_type||'');
  document.getElementById('p_type').textContent=inv.type?.charAt(0).toUpperCase()+inv.type?.slice(1)||'—';
  document.getElementById('p_amount').textContent='₱'+parseFloat(inv.amount||0).toLocaleString('en-PH',{minimumFractionDigits:2});
  document.getElementById('p_due').textContent=inv.due_date?new Date(inv.due_date).toLocaleDateString('en-PH',{month:'short',day:'numeric',year:'numeric'}):'—';
  document.getElementById('p_status').textContent=inv.status||'—';
  document.getElementById('p_method').textContent=inv.method||'—';
  openModal('printModal');
}
document.querySelectorAll('.modal-overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('active');}));
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
</script>
</body></html>