<?php
/**
 * rooms.php — Room Management
 */
session_start();
require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';

if (!isset($_SESSION['admin_id'])) { header('Location: login.php'); exit; }
if (isset($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > 7200) { session_destroy(); header('Location: login.php'); exit; }
$_SESSION['login_time'] = time();

if (empty($_SESSION['csrf_token'])) { $_SESSION['csrf_token'] = bin2hex(random_bytes(32)); }
$csrf    = $_SESSION['csrf_token'];
$adminId = (int)$_SESSION['admin_id'];
$pdo = getDB();

$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $csrf) { die('Invalid CSRF'); }
    $act = $_POST['act'] ?? '';

    if ($act === 'add' || $act === 'edit') {
        $rn   = trim($_POST['room_number'] ?? '');
        $rt   = trim($_POST['room_type']   ?? '');
        $fl   = (int)($_POST['floor']      ?? 1);
        $cap  = (int)($_POST['capacity']   ?? 1);
        $rate = (float)str_replace(',', '', $_POST['monthly_rate'] ?? 0);
        $stat = $_POST['status']           ?? 'vacant';
        $desc = trim($_POST['description'] ?? '');
        $amen = trim($_POST['amenities']   ?? '');

        if ($rn === '' || $rt === '') {
            $_SESSION['flash'] = ['type'=>'error','msg'=>'Room number and type are required.'];
        } else {
            if ($act === 'add') {
                db_execute($pdo, SQL_ROOM_INSERT, [$rn, $rt, $fl, $cap, $rate, $stat, $desc, $amen]);
                db_audit_admin($pdo, $adminId, 'CREATE_ROOM', "Added room {$rn}");
                $_SESSION['flash'] = ['type'=>'success','msg'=>"Room {$rn} added successfully."];
            } else {
                $id = (int)($_POST['id'] ?? 0);
                db_execute($pdo, SQL_ROOM_UPDATE, [$rn, $rt, $fl, $cap, $rate, $stat, $desc, $amen, $id]);
                db_audit_admin($pdo, $adminId, 'UPDATE_ROOM', "Updated room {$rn} (id={$id})");
                $_SESSION['flash'] = ['type'=>'success','msg'=>"Room {$rn} updated."];
            }
        }
    } elseif ($act === 'delete') {
        $id   = (int)($_POST['id'] ?? 0);
        $room = db_fetch_one($pdo, SQL_ROOM_GET_BY_ID, [$id]);
        db_execute($pdo, SQL_ROOM_DELETE, [$id]);
        db_audit_admin($pdo, $adminId, 'DELETE_ROOM', "Deleted room " . ($room['room_number'] ?? $id));
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Room deleted.'];
    }
    header('Location: rooms.php'); exit;
}

$filterStatus = $_GET['status'] ?? '';
$search   = trim($_GET['q'] ?? '');
$page     = max(1, (int)($_GET['page'] ?? 1));
$perPage  = 15;

$sql    = SQL_ROOMS_LIST;
$params = [];
if ($filterStatus !== '') { $sql .= SQL_ROOMS_LIST_STATUS_APPEND; $params[] = $filterStatus; }
if ($search !== '') { $sql .= SQL_ROOMS_LIST_SEARCH_APPEND; $params[] = "%{$search}%"; $params[] = "%{$search}%"; $params[] = "%{$search}%"; }
$sql .= SQL_ROOMS_LIST_ORDER;

$paginated  = db_paginate($pdo, $sql, $params, $page, $perPage);
$rooms      = $paginated['rows'];
$total      = $paginated['total'];
$pages      = $paginated['pages'];

$summaryRows = db_fetch_all($pdo, SQL_ROOMS_SUMMARY);
$summary     = array_column($summaryRows, 'cnt', 'status');
$totalRooms  = array_sum($summary);
$navStats    = db_nav_stats($pdo);
$activeNav   = 'rooms';

$statusColors = ['vacant'=>'badge-green','occupied'=>'badge-blue','maintenance'=>'badge-warn','reserved'=>'badge-gold'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Rooms — BH Management System</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600;9..40,700&display=swap" rel="stylesheet">
<?php include __DIR__ . '/shared_styles.php'; ?>
</head>
<body>
<?php include __DIR__ . '/shared_sidebar.php'; ?>
<div class="main">
<header class="topbar">
  <div style="display:flex;align-items:center;gap:14px;">
    <button class="icon-btn hamburger" onclick="openSidebar()">☰</button>
    <div class="topbar-left"><h2>Rooms</h2><p>Manage all boarding house rooms</p></div>
  </div>
  <div class="topbar-actions">
    <button class="btn-primary" onclick="openModal('addModal')">+ Add Room</button>
    <form method="POST" action="process.php" style="margin:0;"><input type="hidden" name="action" value="logout"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><button type="submit" class="btn-logout">🚪 <span>Sign Out</span></button></form>
  </div>
</header>
<div class="content">

<?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= htmlspecialchars($flash['msg'],ENT_QUOTES,'UTF-8') ?></div><?php endif; ?>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px;">
  <div class="stat-card"><div class="stat-icon gold">🛏</div><div class="stat-body"><div class="stat-label">Total Rooms</div><div class="stat-value"><?= $totalRooms ?></div></div></div>
  <div class="stat-card"><div class="stat-icon green">✅</div><div class="stat-body"><div class="stat-label">Occupied</div><div class="stat-value"><?= $summary['occupied'] ?? 0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon blue">🔓</div><div class="stat-body"><div class="stat-label">Vacant</div><div class="stat-value"><?= $summary['vacant'] ?? 0 ?></div></div></div>
  <div class="stat-card"><div class="stat-icon warn">🔧</div><div class="stat-body"><div class="stat-label">Maintenance</div><div class="stat-value"><?= $summary['maintenance'] ?? 0 ?></div></div></div>
</div>

<div class="panel" style="margin-bottom:20px;">
  <form method="GET" class="filter-row">
    <input type="text" name="q" class="form-input" placeholder="Search room…" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" style="max-width:240px;">
    <select name="status" class="form-input" style="max-width:160px;">
      <option value="">All Statuses</option>
      <?php foreach (['vacant','occupied','maintenance','reserved'] as $s): ?>
        <option value="<?= $s ?>" <?= $filterStatus===$s?'selected':'' ?>><?= ucfirst($s) ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn-secondary">Filter</button>
    <a href="rooms.php" class="btn-ghost">Clear</a>
  </form>
</div>

<div class="panel">
  <div class="section-header"><span class="section-title">Room List <small style="color:var(--muted);font-size:13px;">(<?= $total ?> rooms)</small></span></div>
  <div class="table-wrap">
  <table>
    <thead><tr><th>Room #</th><th>Type</th><th>Floor</th><th>Monthly Rate</th><th>Status</th><th>Current Tenant</th><th>Amenities</th><th>Actions</th></tr></thead>
    <tbody>
    <?php if (empty($rooms)): ?><tr class="empty-row"><td colspan="8">No rooms found.</td></tr>
    <?php else: foreach ($rooms as $r): $cls = $statusColors[$r['status']] ?? 'badge-muted'; ?>
    <tr>
      <td><strong><?= htmlspecialchars($r['room_number'],ENT_QUOTES,'UTF-8') ?></strong></td>
      <td><?= htmlspecialchars($r['room_type'],ENT_QUOTES,'UTF-8') ?></td>
      <td>Floor <?= $r['floor'] ?></td>
      <td><strong>₱<?= number_format($r['monthly_rate'],2) ?></strong></td>
      <td><span class="badge <?= $cls ?>"><?= $r['status'] ?></span></td>
      <td><?= $r['current_tenant'] ? htmlspecialchars($r['current_tenant'],ENT_QUOTES,'UTF-8') : '<span style="color:var(--muted)">—</span>' ?></td>
      <td><small style="color:var(--muted)"><?= htmlspecialchars(substr($r['amenities']??'',0,60),ENT_QUOTES,'UTF-8') ?><?= strlen($r['amenities']??'')>60?'…':'' ?></small></td>
      <td>
        <button class="tbl-btn" onclick='openEdit(<?= json_encode($r) ?>)'>Edit</button>
        <button class="tbl-btn danger" onclick="confirmDelete(<?= $r['id'] ?>,'<?= htmlspecialchars($r['room_number'],ENT_QUOTES,'UTF-8') ?>')">Delete</button>
      </td>
    </tr>
    <?php endforeach; endif; ?>
    </tbody>
  </table>
  </div>
  <?php if ($pages>1): ?><div class="pagination"><?php for($i=1;$i<=$pages;$i++): ?><a href="?page=<?=$i?>&q=<?=urlencode($search)?>&status=<?=urlencode($filterStatus)?>" class="page-btn <?=$i===$page?'active':''?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?>
</div>
</div></div>

<!-- ADD MODAL -->
<div class="modal-overlay" id="addModal"><div class="modal">
  <div class="modal-header"><span class="modal-title">Add New Room</span><button class="modal-close" onclick="closeModal('addModal')">✕</button></div>
  <form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="add">
    <div class="form-grid">
      <div class="field"><label>Room Number *</label><input type="text" name="room_number" class="form-input" required></div>
      <div class="field"><label>Room Type *</label><select name="room_type" class="form-input"><?php foreach(['single','double','studio','dormitory','suite'] as $t): ?><option value="<?=$t?>"><?= ucfirst($t) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>Floor</label><input type="number" name="floor" class="form-input" value="1" min="1" max="20"></div>
      <div class="field"><label>Capacity</label><input type="number" name="capacity" class="form-input" value="1" min="1"></div>
      <div class="field"><label>Monthly Rate (₱)</label><input type="number" name="monthly_rate" class="form-input" step="0.01" min="0" placeholder="0.00"></div>
      <div class="field"><label>Status</label><select name="status" class="form-input"><?php foreach(['vacant','occupied','maintenance','reserved'] as $s): ?><option value="<?=$s?>"><?= ucfirst($s) ?></option><?php endforeach; ?></select></div>
      <div class="field field-full"><label>Amenities</label><input type="text" name="amenities" class="form-input" placeholder="e.g. AC, WiFi, Cabinet"></div>
      <div class="field field-full"><label>Description</label><textarea name="description" class="form-input" rows="2"></textarea></div>
    </div>
    <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('addModal')">Cancel</button><button type="submit" class="btn-primary">Add Room</button></div>
  </form>
</div></div>

<!-- EDIT MODAL -->
<div class="modal-overlay" id="editModal"><div class="modal">
  <div class="modal-header"><span class="modal-title">Edit Room</span><button class="modal-close" onclick="closeModal('editModal')">✕</button></div>
  <form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="edit"><input type="hidden" name="id" id="edit_id">
    <div class="form-grid">
      <div class="field"><label>Room Number *</label><input type="text" name="room_number" id="edit_room_number" class="form-input" required></div>
      <div class="field"><label>Room Type *</label><select name="room_type" id="edit_room_type" class="form-input"><?php foreach(['single','double','studio','dormitory','suite'] as $t): ?><option value="<?=$t?>"><?= ucfirst($t) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>Floor</label><input type="number" name="floor" id="edit_floor" class="form-input" min="1" max="20"></div>
      <div class="field"><label>Capacity</label><input type="number" name="capacity" id="edit_cap" class="form-input" min="1"></div>
      <div class="field"><label>Monthly Rate (₱)</label><input type="number" name="monthly_rate" id="edit_rate" class="form-input" step="0.01" min="0"></div>
      <div class="field"><label>Status</label><select name="status" id="edit_status" class="form-input"><?php foreach(['vacant','occupied','maintenance','reserved'] as $s): ?><option value="<?=$s?>"><?= ucfirst($s) ?></option><?php endforeach; ?></select></div>
      <div class="field field-full"><label>Amenities</label><input type="text" name="amenities" id="edit_amenities" class="form-input"></div>
      <div class="field field-full"><label>Description</label><textarea name="description" id="edit_desc" class="form-input" rows="2"></textarea></div>
    </div>
    <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('editModal')">Cancel</button><button type="submit" class="btn-primary">Save Changes</button></div>
  </form>
</div></div>

<!-- DELETE MODAL -->
<div class="modal-overlay" id="deleteModal"><div class="modal" style="max-width:400px;">
  <div class="modal-header"><span class="modal-title">Confirm Delete</span><button class="modal-close" onclick="closeModal('deleteModal')">✕</button></div>
  <p style="padding:20px 24px;color:var(--text-mid);">Delete room <strong id="delRoomNum"></strong>? This cannot be undone.</p>
  <form method="POST"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="act" value="delete"><input type="hidden" name="id" id="del_id">
    <div class="modal-footer"><button type="button" class="btn-ghost" onclick="closeModal('deleteModal')">Cancel</button><button type="submit" class="btn-danger">Delete Room</button></div>
  </form>
</div></div>

<script>
function openModal(id){document.getElementById(id).classList.add('active');}
function closeModal(id){document.getElementById(id).classList.remove('active');}
function openEdit(r){
  document.getElementById('edit_id').value=r.id;
  document.getElementById('edit_room_number').value=r.room_number;
  document.getElementById('edit_room_type').value=r.room_type;
  document.getElementById('edit_floor').value=r.floor;
  document.getElementById('edit_cap').value=r.capacity||1;
  document.getElementById('edit_rate').value=r.monthly_rate;
  document.getElementById('edit_status').value=r.status;
  document.getElementById('edit_amenities').value=r.amenities||'';
  document.getElementById('edit_desc').value=r.description||'';
  openModal('editModal');
}
function confirmDelete(id,num){document.getElementById('del_id').value=id;document.getElementById('delRoomNum').textContent=num;openModal('deleteModal');}
document.querySelectorAll('.modal-overlay').forEach(o=>o.addEventListener('click',e=>{if(e.target===o)o.classList.remove('active');}));
function openSidebar(){document.getElementById('sidebar').classList.add('open');document.getElementById('overlay').classList.add('visible');}
function closeSidebar(){document.getElementById('sidebar').classList.remove('open');document.getElementById('overlay').classList.remove('visible');}
</script>
</body></html>