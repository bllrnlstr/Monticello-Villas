<?php
session_start();
if(isset($_SESSION["tenant_time"]) && (time()-$_SESSION["tenant_time"])>7200){session_destroy();header("Location: index.php");exit();}
$_SESSION["tenant_time"]=time();

if (!isset($_SESSION['tenant_id'])) {
    header("Location: index.php");
    exit();
}

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
$pdo = getDB();

$tenant_id   = $_SESSION['tenant_id'];
$tenant_name = $_SESSION['tenant_name'];
$tenant_room = $_SESSION['tenant_room'];

$initials = '';
foreach (explode(' ', $tenant_name) as $p) {
    if ($p !== '') $initials .= strtoupper($p[0]);
}

$success_message = '';
$error_message   = '';

// ── Handle: tenant submits a maintenance request ──────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'submit_request') {
    $category    = trim($_POST['category']    ?? '');
    $subject = trim($_POST['subject']     ?? '');
    $description = trim($_POST['description'] ?? '');
    $urgency     = trim($_POST['urgency']     ?? 'normal');

    if (!$category || !$subject || !$description) {
        $error_message = 'Category, subject, and description are required.';
    } else {
        $ins = $pdo->prepare("
            INSERT INTO maintenance_requests (tenant_id, category, title, description, urgency, status, submitted_by)
            VALUES (?, ?, ?, ?, ?, 'pending', 'tenant')
        ");
        if ($ins->execute([$tenant_id, $category, $subject, $description, $urgency])) {
            $success_message = 'Maintenance request submitted. Admin will respond shortly.';
        } else {
            $error_message = 'Could not submit request. Please try again.';
        }
    }
}

// ── Fetch: admin-posted maintenance schedules (all tenants see these) ─────
$sched_stmt = $pdo->query("
    SELECT * FROM maintenance_schedules
    ORDER BY scheduled_date ASC
");
$schedules = $sched_stmt->fetchAll();

// Separate into upcoming/ongoing and past
$upcoming = [];
$past     = [];
$today    = new DateTime();
foreach ($schedules as $s) {
    $sDate = new DateTime($s['scheduled_date']);
    if ($s['status'] === 'completed' || $sDate < $today) {
        $past[] = $s;
    } else {
        $upcoming[] = $s;
    }
}

// ── Fetch: this tenant's own maintenance requests ─────────────────────────
$req_stmt = $pdo->prepare("
    SELECT * FROM maintenance_requests
    WHERE tenant_id = ?
    ORDER BY created_at DESC
");
$req_stmt->execute([$tenant_id]);
$my_requests = $req_stmt->fetchAll();

// ── Category config ───────────────────────────────────────────────────────
$categories = [
    'water'       => ['label' => 'Water Supply',    'icon' => 'fa-tint',              'color' => 'blue'],
    'electricity' => ['label' => 'Electricity',     'icon' => 'fa-bolt',              'color' => 'yellow'],
    'plumbing'    => ['label' => 'Plumbing',        'icon' => 'fa-wrench',            'color' => 'blue'],
    'structural'  => ['label' => 'Structural',      'icon' => 'fa-building',          'color' => 'red'],
    'pest'        => ['label' => 'Pest Control',    'icon' => 'fa-bug',               'color' => 'green'],
    'appliance'   => ['label' => 'Appliance',       'icon' => 'fa-plug',              'color' => 'purple'],
    'internet'    => ['label' => 'Internet / Wi-Fi','icon' => 'fa-wifi',              'color' => 'blue'],
    'cleaning'    => ['label' => 'Cleaning',        'icon' => 'fa-broom',             'color' => 'green'],
    'security'    => ['label' => 'Security',        'icon' => 'fa-shield-alt',        'color' => 'red'],
    'other'       => ['label' => 'Other',           'icon' => 'fa-ellipsis-h',        'color' => 'silver'],
];

$schedule_types = [
    'water_interruption' => ['label' => 'Water Interruption', 'icon' => 'fa-tint-slash',       'color' => 'blue'],
    'power_outage'       => ['label' => 'Power Outage',       'icon' => 'fa-bolt',              'color' => 'yellow'],
    'general_repair'     => ['label' => 'General Repair',     'icon' => 'fa-tools',             'color' => 'silver'],
    'pest_control'       => ['label' => 'Pest Control',       'icon' => 'fa-bug',               'color' => 'green'],
    'elevator'           => ['label' => 'Elevator Service',   'icon' => 'fa-arrows-alt-v',      'color' => 'purple'],
    'cleaning'           => ['label' => 'General Cleaning',   'icon' => 'fa-broom',             'color' => 'green'],
    'inspection'         => ['label' => 'Inspection',         'icon' => 'fa-search',            'color' => 'blue'],
    'other'              => ['label' => 'Other',              'icon' => 'fa-wrench',            'color' => 'silver'],
];

$status_colors = [
    'pending'    => 'warn',
    'in_progress'=> 'blue',
    'resolved'   => 'ok',
    'cancelled'  => 'silver',
    'scheduled'  => 'blue',
    'ongoing'    => 'warn',
    'completed'  => 'ok',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Maintenance — Monticello TMS</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{
  --bg:#080d1a;--surface:#0d1424;--surface-2:#111827;
  --accent:#2563eb;--accent-lt:#3b82f6;--accent-gl:rgba(37,99,235,0.15);
  --ok:#10b981;--warn:#f59e0b;--err:#ef4444;--purple:#8b5cf6;
  --silver:#94a3b8;--light:#cbd5e1;--white:#f1f5f9;
  --border:rgba(255,255,255,0.07);--border-2:rgba(255,255,255,0.04);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--light);display:flex;min-height:100vh;}

/* ── SIDEBAR ─────────────────────────────────── */
.sidebar{width:240px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;height:100vh;z-index:100;}
.sb-logo{padding:1.6rem 1.4rem;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:0.7rem;}
.sb-mark{width:32px;height:32px;background:var(--accent);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:0.9rem;flex-shrink:0;}
.sb-name{font-family:'Syne',sans-serif;font-size:0.9rem;font-weight:700;color:var(--white);}
.sb-name small{display:block;font-size:0.58rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:0.1em;text-transform:uppercase;margin-top:1px;}
.sb-nav{flex:1;padding:1rem 0.75rem;overflow-y:auto;}
.nav-section-label{font-size:0.58rem;font-weight:700;text-transform:uppercase;letter-spacing:0.14em;color:rgba(148,163,184,0.45);padding:0.6rem 0.65rem 0.4rem;margin-top:0.5rem;}
.nav-link{display:flex;align-items:center;gap:0.7rem;padding:0.62rem 0.75rem;border-radius:5px;font-size:0.82rem;font-weight:500;color:var(--silver);text-decoration:none;transition:all 0.18s;margin-bottom:2px;}
.nav-link:hover{background:rgba(255,255,255,0.05);color:var(--white);}
.nav-link.active{background:var(--accent-gl);color:var(--accent-lt);border-left:2px solid var(--accent);padding-left:calc(0.75rem - 2px);}
.nav-link i{width:16px;font-size:0.8rem;opacity:0.8;}
.nav-link.active i{opacity:1;}
.sb-user{padding:1rem 1.1rem;border-top:1px solid var(--border);}
.sb-user-row{display:flex;align-items:center;gap:0.7rem;margin-bottom:0.75rem;}
.sb-avatar{width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,var(--accent),#1d4ed8);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:0.8rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user-name{font-size:0.82rem;font-weight:600;color:var(--white);}
.sb-user-room{font-size:0.68rem;color:var(--silver);margin-top:1px;}
.logout-btn{width:100%;padding:0.55rem;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.18);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:0.76rem;font-weight:600;color:#fca5a5;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;}
.logout-btn:hover{background:rgba(239,68,68,0.14);border-color:rgba(239,68,68,0.3);}

/* ── MAIN ────────────────────────────────────── */
.main{margin-left:240px;flex:1;min-height:100vh;}
.topbar{background:var(--surface);border-bottom:1px solid var(--border);padding:0 2rem;height:58px;display:flex;align-items:center;position:sticky;top:0;z-index:50;}
.topbar-left{display:flex;align-items:center;gap:1rem;}
.back-link{width:32px;height:32px;background:var(--border-2);border:1px solid var(--border);border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:0.75rem;color:var(--silver);text-decoration:none;transition:all 0.18s;}
.back-link:hover{background:var(--accent-gl);border-color:rgba(37,99,235,0.25);color:var(--accent-lt);}
.topbar-title h1{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);}
.topbar-title p{font-size:0.72rem;color:var(--silver);margin-top:1px;}
.content{padding:1.75rem 2rem;}

/* Page tabs */
.page-tabs{display:flex;border-bottom:1px solid var(--border);margin-bottom:1.5rem;}
.page-tab{padding:0.7rem 1.25rem;font-size:0.82rem;font-weight:600;color:var(--silver);cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-1px;transition:all 0.18s;display:flex;align-items:center;gap:0.5rem;background:none;border-top:none;border-left:none;border-right:none;font-family:'DM Sans',sans-serif;}
.page-tab:hover{color:var(--white);}
.page-tab.active{color:var(--accent-lt);border-bottom-color:var(--accent);}
.tab-count{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;border-radius:9px;padding:0 4px;background:var(--accent-gl);color:var(--accent-lt);font-size:0.6rem;font-weight:700;}
.tab-section{display:none;}
.tab-section.active{display:block;}

/* Alerts */
.alert{display:flex;align-items:center;gap:0.6rem;padding:0.75rem 1rem;border-radius:5px;font-size:0.8rem;margin-bottom:1.25rem;border-left:3px solid;}
.alert-ok {background:rgba(16,185,129,0.07);border-color:var(--ok); color:#6ee7b7;}
.alert-err{background:rgba(239,68,68,0.07); border-color:var(--err);color:#fca5a5;}

/* Panels */
.panel{background:var(--surface);border:1px solid var(--border);border-radius:8px;overflow:hidden;margin-bottom:1.25rem;}
.panel-head{padding:1rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.panel-title{font-family:'Syne',sans-serif;font-size:0.82rem;font-weight:700;color:var(--white);display:flex;align-items:center;gap:0.55rem;}
.panel-title i{font-size:0.75rem;color:var(--accent-lt);}
.panel-body{padding:1.25rem;}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;}

/* Schedule cards */
.sched-card{padding:1.1rem 1.2rem 1.1rem 1.5rem;border-radius:6px;border:1px solid;position:relative;overflow:hidden;margin-bottom:0.75rem;}
.sched-card:last-child{margin-bottom:0;}
.sched-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;}
.sc-blue  {background:rgba(37,99,235,0.06); border-color:rgba(37,99,235,0.18);}  .sc-blue::before  {background:var(--accent);}
.sc-yellow{background:rgba(245,158,11,0.06);border-color:rgba(245,158,11,0.18);} .sc-yellow::before{background:var(--warn);}
.sc-red   {background:rgba(239,68,68,0.06); border-color:rgba(239,68,68,0.18);}  .sc-red::before   {background:var(--err);}
.sc-green {background:rgba(16,185,129,0.06);border-color:rgba(16,185,129,0.18);} .sc-green::before {background:var(--ok);}
.sc-silver{background:rgba(148,163,184,0.04);border-color:rgba(148,163,184,0.12);}.sc-silver::before{background:var(--silver);}
.sc-purple{background:rgba(139,92,246,0.06);border-color:rgba(139,92,246,0.18);} .sc-purple::before{background:var(--purple);}

.sched-top{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;margin-bottom:0.6rem;}
.sched-left{}
.sched-badge{display:inline-flex;align-items:center;gap:0.3rem;padding:0.18rem 0.6rem;border-radius:2px;font-size:0.6rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;margin-bottom:0.4rem;}
.sb-blue  {background:rgba(37,99,235,0.15);color:var(--accent-lt);}
.sb-yellow{background:rgba(245,158,11,0.15);color:#fcd34d;}
.sb-red   {background:rgba(239,68,68,0.15); color:#fca5a5;}
.sb-green {background:rgba(16,185,129,0.15);color:#6ee7b7;}
.sb-silver{background:rgba(148,163,184,0.1);color:var(--silver);}
.sb-purple{background:rgba(139,92,246,0.15);color:#c4b5fd;}

.sched-title{font-family:'Syne',sans-serif;font-size:0.88rem;font-weight:700;color:var(--white);}
.sched-desc{font-size:0.78rem;color:var(--light);line-height:1.6;margin-top:0.35rem;}

.sched-right{text-align:right;flex-shrink:0;}
.sched-date-label{font-size:0.6rem;text-transform:uppercase;letter-spacing:0.1em;color:var(--silver);margin-bottom:2px;}
.sched-date-val{font-family:'Syne',sans-serif;font-size:0.85rem;font-weight:700;color:var(--white);white-space:nowrap;}
.sched-time{font-size:0.72rem;color:var(--silver);margin-top:2px;}

.sched-footer{display:flex;align-items:center;gap:0.65rem;margin-top:0.65rem;padding-top:0.65rem;border-top:1px solid rgba(255,255,255,0.05);}
.sched-meta{font-size:0.7rem;color:var(--silver);}

/* Countdown badge */
.countdown{display:inline-flex;align-items:center;gap:0.3rem;padding:0.22rem 0.65rem;border-radius:3px;font-size:0.68rem;font-weight:700;background:rgba(245,158,11,0.12);color:#fcd34d;border:1px solid rgba(245,158,11,0.22);}
.countdown i{font-size:0.6rem;}
.countdown-today{background:rgba(239,68,68,0.12);color:#fca5a5;border-color:rgba(239,68,68,0.22);}
.countdown-done {background:rgba(16,185,129,0.1);color:#6ee7b7; border-color:rgba(16,185,129,0.2);}

/* Status chips */
.chip{display:inline-flex;align-items:center;gap:0.3rem;padding:0.2rem 0.6rem;border-radius:3px;font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;}
.chip::before{content:'';width:4px;height:4px;border-radius:50%;background:currentColor;}
.chip-warn  {background:rgba(245,158,11,0.1); color:var(--warn);     border:1px solid rgba(245,158,11,0.2);}
.chip-blue  {background:rgba(37,99,235,0.1);  color:var(--accent-lt);border:1px solid rgba(37,99,235,0.2);}
.chip-ok    {background:rgba(16,185,129,0.1); color:var(--ok);       border:1px solid rgba(16,185,129,0.2);}
.chip-silver{background:rgba(148,163,184,0.08);color:var(--silver);  border:1px solid rgba(148,163,184,0.15);}
.chip-err   {background:rgba(239,68,68,0.1);  color:#fca5a5;         border:1px solid rgba(239,68,68,0.2);}

/* Form */
.field{display:flex;flex-direction:column;gap:0.3rem;margin-bottom:0.85rem;}
.field label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.09em;color:var(--silver);}
.field input,.field textarea,.field select{width:100%;padding:0.68rem 0.9rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.09);border-radius:4px;font-family:'DM Sans',sans-serif;font-size:0.875rem;color:var(--white);outline:none;transition:border-color 0.2s,box-shadow 0.2s;}
.field input::placeholder,.field textarea::placeholder{color:rgba(148,163,184,0.35);}
.field input:focus,.field textarea:focus,.field select:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-gl);}
.field select option{background:#111827;color:var(--white);}
.field textarea{resize:vertical;min-height:90px;}

/* Urgency selector */
.urgency-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:0.55rem;margin-bottom:0.85rem;}
.urgency-radio{display:none;}
.urgency-card{padding:0.7rem 0.5rem;background:var(--border-2);border:1px solid var(--border);border-radius:5px;cursor:pointer;text-align:center;transition:all 0.18s;}
.urgency-card:hover{background:rgba(255,255,255,0.05);border-color:rgba(255,255,255,0.12);}
.urgency-radio:checked + .urgency-card{border-color:var(--accent);background:var(--accent-gl);}
.urgency-ic{font-size:1.1rem;display:block;margin-bottom:0.3rem;}
.urgency-lbl{font-size:0.68rem;font-weight:600;color:var(--light);}
.urgency-sub{font-size:0.6rem;color:var(--silver);margin-top:1px;}

/* My requests list */
.req-item{display:flex;align-items:flex-start;gap:0.85rem;padding:0.85rem 0;border-bottom:1px solid var(--border-2);}
.req-item:last-child{border-bottom:none;padding-bottom:0;}
.req-item:first-child{padding-top:0;}
.req-icon{width:38px;height:38px;border-radius:8px;background:rgba(37,99,235,0.1);display:flex;align-items:center;justify-content:center;font-size:0.82rem;color:var(--accent-lt);flex-shrink:0;margin-top:2px;}
.req-subject{font-size:0.85rem;font-weight:600;color:var(--white);margin-bottom:3px;}
.req-meta{font-size:0.7rem;color:var(--silver);line-height:1.5;}
.req-right{margin-left:auto;text-align:right;flex-shrink:0;display:flex;flex-direction:column;align-items:flex-end;gap:4px;}

/* Admin response bubble */
.admin-reply{margin-top:0.5rem;padding:0.55rem 0.75rem;background:rgba(37,99,235,0.07);border:1px solid rgba(37,99,235,0.15);border-radius:4px;font-size:0.75rem;color:var(--light);line-height:1.55;}
.admin-reply-label{font-size:0.6rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--accent-lt);margin-bottom:3px;}

.btn-primary{width:100%;padding:0.78rem;background:var(--accent);color:#fff;border:none;border-radius:4px;font-family:'Syne',sans-serif;font-size:0.85rem;font-weight:600;letter-spacing:0.04em;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-top:0.5rem;}
.btn-primary:hover{background:#1d4ed8;box-shadow:0 5px 16px var(--accent-gl);}

.empty-state{text-align:center;padding:3rem 1rem;color:var(--silver);font-size:0.82rem;}
.empty-state i{font-size:2rem;opacity:0.15;display:block;margin-bottom:0.75rem;}

/* Active alert banner */
.active-banner{display:flex;align-items:flex-start;gap:0.8rem;padding:1rem 1.2rem;border-radius:6px;margin-bottom:1.25rem;border:1px solid;}
.banner-water{background:rgba(37,99,235,0.08);border-color:rgba(37,99,235,0.22);color:var(--light);}
.banner-power{background:rgba(245,158,11,0.08);border-color:rgba(245,158,11,0.22);color:var(--light);}
.banner-icon{width:40px;height:40px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1rem;flex-shrink:0;}
.banner-water .banner-icon{background:rgba(37,99,235,0.15);color:var(--accent-lt);}
.banner-power .banner-icon{background:rgba(245,158,11,0.15);color:#fcd34d;}
.banner-content{}
.banner-title{font-family:'Syne',sans-serif;font-size:0.88rem;font-weight:700;color:var(--white);margin-bottom:3px;}
.banner-body{font-size:0.78rem;line-height:1.6;}
.banner-time{font-size:0.7rem;color:var(--silver);margin-top:4px;}

@media(max-width:960px){.two-col{grid-template-columns:1fr;}.urgency-grid{grid-template-columns:repeat(3,1fr);}}
@media(max-width:720px){.sidebar{width:100%;height:auto;position:relative;}.main{margin-left:0;}.page-tab span{display:none;}}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <div class="sb-mark">⬡</div>
    <div class="sb-name">Monticello <small>Tenant Portal</small></div>
  </div>
  <nav class="sb-nav">
    <div class="nav-section-label">Main</div>
    <a href="dashboard.php"      class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
    <a href="payments.php"       class="nav-link"><i class="fas fa-credit-card"></i> Payments</a>
    <div class="nav-section-label">Account</div>
    <a href="invoices.php"         class="nav-link"><i class="fas fa-file-invoice"></i> Invoices</a>
    <a href="maintenance.php"    class="nav-link active"><i class="fas fa-tools"></i> Maintenance</a>
    <a href="communications.php" class="nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
    
    <a href="profile.php"        class="nav-link"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sb-user">
    <div class="sb-user-row">
      <div class="sb-avatar"><?php echo htmlspecialchars($initials); ?></div>
      <div>
        <div class="sb-user-name"><?php echo htmlspecialchars($tenant_name); ?></div>
        <div class="sb-user-room">Room <?php echo htmlspecialchars($tenant_room); ?></div>
      </div>
    </div>
    <form method="POST" action="logout.php" style="margin:0;">
      <button type="submit" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Sign Out</button>
    </form>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i></a>
      <div class="topbar-title">
        <h1>Maintenance</h1>
        <p>Schedules, service interruptions &amp; repair requests</p>
      </div>
    </div>
  </div>

  <div class="content">

    <?php if ($success_message): ?>
    <div class="alert alert-ok"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?></div>
    <?php endif; ?>
    <?php if ($error_message): ?>
    <div class="alert alert-err"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?></div>
    <?php endif; ?>

    <?php
    // Show active/ongoing banners prominently at top
    foreach ($upcoming as $s) {
        if ($s['status'] === 'ongoing') {
            $t = $schedule_types[$s['type']] ?? $schedule_types['other'];
            $bannerClass = in_array($s['type'], ['water_interruption','plumbing']) ? 'banner-water' : 'banner-power';
            echo '<div class="active-banner ' . $bannerClass . '">';
            echo '<div class="banner-icon"><i class="fas ' . $t['icon'] . '"></i></div>';
            echo '<div class="banner-content">';
            echo '<div class="banner-title">🔴 ONGOING: ' . htmlspecialchars($s['title']) . '</div>';
            echo '<div class="banner-body">' . nl2br(htmlspecialchars($s['description'])) . '</div>';
            echo '<div class="banner-time">Started: ' . date('M j, Y', strtotime($s['scheduled_date'])) . ($s['scheduled_time'] ? ' at ' . date('g:i A', strtotime($s['scheduled_time'])) : '') . ($s['estimated_duration'] ? ' · Est. duration: ' . htmlspecialchars($s['estimated_duration']) : '') . '</div>';
            echo '</div></div>';
        }
    }
    ?>

    <!-- Tabs -->
    <div class="page-tabs">
      <button class="page-tab active" onclick="switchTab('schedules',this)">
        <i class="fas fa-calendar-alt"></i> <span>Schedules</span>
        <span class="tab-count"><?php echo count($upcoming); ?></span>
      </button>
      <button class="page-tab" onclick="switchTab('request',this)">
        <i class="fas fa-tools"></i> <span>Submit Request</span>
      </button>
      <button class="page-tab" onclick="switchTab('my',this)">
        <i class="fas fa-clipboard-list"></i> <span>My Requests</span>
        <span class="tab-count"><?php echo count($my_requests); ?></span>
      </button>
      <button class="page-tab" onclick="switchTab('history',this)">
        <i class="fas fa-history"></i> <span>Past</span>
        <span class="tab-count"><?php echo count($past); ?></span>
      </button>
    </div>

    <!-- ── TAB 1: SCHEDULES ──────────────────────────────── -->
    <div class="tab-section active" id="tab-schedules">
      <?php if (count($upcoming) > 0): ?>
        <?php foreach ($upcoming as $s):
          $t   = $schedule_types[$s['type']] ?? $schedule_types['other'];
          $col = $t['color'];

          // Countdown
          $sDate    = new DateTime($s['scheduled_date']);
          $diff     = $today->diff($sDate);
          $diffDays = (int)$sDate->format('Ymd') - (int)$today->format('Ymd');
          if ($s['status'] === 'ongoing') {
              $cdClass = 'countdown'; $cdText = 'Ongoing Now';
          } elseif ($diffDays === 0) {
              $cdClass = 'countdown countdown-today'; $cdText = 'Today';
          } elseif ($diffDays === 1) {
              $cdClass = 'countdown'; $cdText = 'Tomorrow';
          } elseif ($diffDays > 0) {
              $cdClass = 'countdown'; $cdText = 'In ' . $diffDays . ' day' . ($diffDays > 1 ? 's' : '');
          } else {
              $cdClass = 'countdown countdown-done'; $cdText = 'Passed';
          }

          $statusKey = $status_colors[$s['status']] ?? 'silver';
        ?>
        <div class="sched-card sc-<?php echo $col; ?>">
          <div class="sched-top">
            <div class="sched-left">
              <div class="sched-badge sb-<?php echo $col; ?>">
                <i class="fas <?php echo $t['icon']; ?>"></i> <?php echo $t['label']; ?>
              </div>
              <div class="sched-title"><?php echo htmlspecialchars($s['title']); ?></div>
              <?php if ($s['description']): ?>
              <div class="sched-desc"><?php echo nl2br(htmlspecialchars($s['description'])); ?></div>
              <?php endif; ?>
            </div>
            <div class="sched-right">
              <div class="sched-date-label">Scheduled</div>
              <div class="sched-date-val"><?php echo date('M j, Y', strtotime($s['scheduled_date'])); ?></div>
              <?php if ($s['scheduled_time']): ?>
              <div class="sched-time"><?php echo date('g:i A', strtotime($s['scheduled_time'])); ?></div>
              <?php endif; ?>
            </div>
          </div>
          <div class="sched-footer">
            <span class="<?php echo $cdClass; ?>"><i class="fas fa-clock"></i> <?php echo $cdText; ?></span>
            <span class="chip chip-<?php echo $statusKey; ?>"><?php echo ucfirst(str_replace('_', ' ', $s['status'])); ?></span>
            <?php if ($s['estimated_duration']): ?>
            <span class="sched-meta"><i class="fas fa-hourglass-half"></i> Est. <?php echo htmlspecialchars($s['estimated_duration']); ?></span>
            <?php endif; ?>
            <?php if ($s['affected_area']): ?>
            <span class="sched-meta"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($s['affected_area']); ?></span>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="panel"><div class="panel-body">
          <div class="empty-state">
            <i class="fas fa-calendar-check"></i>
            No upcoming maintenance scheduled.<br>All services are running normally.
          </div>
        </div></div>
      <?php endif; ?>
    </div>

    <!-- ── TAB 2: SUBMIT REQUEST ─────────────────────────── -->
    <div class="tab-section" id="tab-request">
      <div class="two-col">

        <div class="panel">
          <div class="panel-head">
            <div class="panel-title"><i class="fas fa-plus-circle"></i> Submit Maintenance Request</div>
          </div>
          <div class="panel-body">
            <form method="POST" action="maintenance.php">
              <input type="hidden" name="action" value="submit_request">

              <div class="field">
                <label>Category</label>
                <select name="category" required>
                  <option value="" disabled selected>Select a category...</option>
                  <?php foreach ($categories as $key => $cat): ?>
                  <option value="<?php echo $key; ?>" <?php echo (($_POST['category'] ?? '') === $key) ? 'selected' : ''; ?>>
                    <?php echo $cat['label']; ?>
                  </option>
                  <?php endforeach; ?>
                </select>
              </div>

              <div class="field">
                <label>Subject</label>
                <input type="text" name="subject" placeholder="e.g. No water supply in bathroom"
                       value="<?php echo htmlspecialchars($_POST['subject'] ?? ''); ?>" required>
              </div>

              <div class="field">
                <label>Description</label>
                <textarea name="description" placeholder="Describe the issue in detail — when it started, how it affects you, and anything else the admin should know..." required><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
              </div>

              <div class="field">
                <label>Urgency Level</label>
              </div>
              <div class="urgency-grid">
                <div>
                  <input type="radio" name="urgency" value="low" id="u-low" class="urgency-radio"
                         <?php echo (($_POST['urgency'] ?? 'normal') === 'low') ? 'checked' : ''; ?>>
                  <label for="u-low" class="urgency-card">
                    <span class="urgency-ic">🟢</span>
                    <div class="urgency-lbl">Low</div>
                    <div class="urgency-sub">Not urgent</div>
                  </label>
                </div>
                <div>
                  <input type="radio" name="urgency" value="normal" id="u-normal" class="urgency-radio"
                         <?php echo (($_POST['urgency'] ?? 'normal') === 'normal') ? 'checked' : ''; ?>>
                  <label for="u-normal" class="urgency-card">
                    <span class="urgency-ic">🟡</span>
                    <div class="urgency-lbl">Normal</div>
                    <div class="urgency-sub">Needs attention</div>
                  </label>
                </div>
                <div>
                  <input type="radio" name="urgency" value="urgent" id="u-urgent" class="urgency-radio"
                         <?php echo (($_POST['urgency'] ?? '') === 'urgent') ? 'checked' : ''; ?>>
                  <label for="u-urgent" class="urgency-card">
                    <span class="urgency-ic">🔴</span>
                    <div class="urgency-lbl">Urgent</div>
                    <div class="urgency-sub">Immediate fix needed</div>
                  </label>
                </div>
              </div>

              <button type="submit" class="btn-primary">
                <i class="fas fa-paper-plane"></i> Submit Request
              </button>
            </form>
          </div>
        </div>

        <!-- Category guide -->
        <div class="panel">
          <div class="panel-head">
            <div class="panel-title"><i class="fas fa-info-circle"></i> Category Guide</div>
          </div>
          <div class="panel-body">
            <?php foreach ($categories as $key => $cat):
              $colMap = ['blue'=>'var(--accent-lt)','yellow'=>'#fcd34d','red'=>'#fca5a5','green'=>'#6ee7b7','purple'=>'#c4b5fd','silver'=>'var(--silver)'];
              $iconColor = $colMap[$cat['color']] ?? 'var(--silver)';
            ?>
            <div style="display:flex;align-items:center;gap:0.65rem;padding:0.5rem 0;border-bottom:1px solid var(--border-2);">
              <div style="width:30px;height:30px;border-radius:6px;background:rgba(255,255,255,0.04);display:flex;align-items:center;justify-content:center;font-size:0.75rem;color:<?php echo $iconColor; ?>;flex-shrink:0;">
                <i class="fas <?php echo $cat['icon']; ?>"></i>
              </div>
              <div>
                <div style="font-size:0.78rem;font-weight:600;color:var(--white);"><?php echo $cat['label']; ?></div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>

      </div>
    </div>

    <!-- ── TAB 3: MY REQUESTS ────────────────────────────── -->
    <div class="tab-section" id="tab-my">
      <div class="panel">
        <div class="panel-head">
          <div class="panel-title"><i class="fas fa-clipboard-list"></i> My Maintenance Requests</div>
          <span style="font-size:0.72rem;color:var(--silver);"><?php echo count($my_requests); ?> total</span>
        </div>
        <div class="panel-body">
          <?php if (count($my_requests) > 0): ?>
            <?php foreach ($my_requests as $r):
              $cat     = $categories[$r['category']] ?? $categories['other'];
              $statKey = $status_colors[$r['status']] ?? 'silver';
              $urgMap  = ['low'=>'🟢','normal'=>'🟡','urgent'=>'🔴'];
            ?>
            <div class="req-item">
              <div class="req-icon"><i class="fas <?php echo $cat['icon']; ?>"></i></div>
              <div style="flex:1;min-width:0;">
                <div class="req-subject"><?php echo htmlspecialchars($r['title'] ?? $r['subject'] ?? ''); ?></div>
                <div class="req-meta">
                  <?php echo $cat['label']; ?> ·
                  <?php echo ($urgMap[$r['urgency']] ?? '🟡') . ' ' . ucfirst($r['urgency']); ?> ·
                  <?php echo date('M j, Y', strtotime($r['created_at'])); ?>
                </div>
                <div class="req-meta" style="margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:280px;">
                  <?php echo htmlspecialchars($r['description']); ?>
                </div>
                <?php if (!empty($r['admin_reply'])): ?>
                <div class="admin-reply">
                  <div class="admin-reply-label"><i class="fas fa-user-shield"></i> Admin Response</div>
                  <?php echo nl2br(htmlspecialchars($r['admin_reply'])); ?>
                </div>
                <?php endif; ?>
              </div>
              <div class="req-right">
                <span class="chip chip-<?php echo $statKey; ?>"><?php echo ucfirst(str_replace('_', ' ', $r['status'])); ?></span>
              </div>
            </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div class="empty-state">
              <i class="fas fa-tools"></i>
              No requests submitted yet.<br>Use the Submit Request tab to report an issue.
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- ── TAB 4: PAST SCHEDULES ─────────────────────────── -->
    <div class="tab-section" id="tab-history">
      <?php if (count($past) > 0): ?>
        <?php foreach ($past as $s):
          $t   = $schedule_types[$s['type']] ?? $schedule_types['other'];
          $col = $t['color'];
        ?>
        <div class="sched-card sc-silver" style="opacity:0.7;">
          <div class="sched-top">
            <div class="sched-left">
              <div class="sched-badge sb-silver">
                <i class="fas <?php echo $t['icon']; ?>"></i> <?php echo $t['label']; ?>
              </div>
              <div class="sched-title"><?php echo htmlspecialchars($s['title']); ?></div>
              <?php if ($s['description']): ?>
              <div class="sched-desc"><?php echo nl2br(htmlspecialchars($s['description'])); ?></div>
              <?php endif; ?>
            </div>
            <div class="sched-right">
              <div class="sched-date-label">Was Scheduled</div>
              <div class="sched-date-val"><?php echo date('M j, Y', strtotime($s['scheduled_date'])); ?></div>
            </div>
          </div>
          <div class="sched-footer">
            <span class="countdown countdown-done"><i class="fas fa-check"></i> Completed</span>
            <?php if ($s['affected_area']): ?>
            <span class="sched-meta"><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($s['affected_area']); ?></span>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="panel"><div class="panel-body">
          <div class="empty-state">
            <i class="fas fa-history"></i>
            No past maintenance records yet.
          </div>
        </div></div>
      <?php endif; ?>
    </div>

  </div>
</div>

<script>
function switchTab(name, btn) {
  document.querySelectorAll('.tab-section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.page-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-' + name).classList.add('active');
  btn.classList.add('active');
}
</script>
</body>
</html>