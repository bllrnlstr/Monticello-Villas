<?php
session_start();
if (isset($_SESSION["tenant_time"]) && (time() - $_SESSION["tenant_time"]) > 7200) {
    session_destroy(); header("Location: index.php"); exit();
}
$_SESSION["tenant_time"] = time();
if (!isset($_SESSION['tenant_id'])) { header("Location: index.php"); exit(); }

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
$pdo = getDB();

$tenant_id   = (int)$_SESSION['tenant_id'];
$tenant_name = $_SESSION['tenant_name'];
$tenant_room = $_SESSION['tenant_room'];

$initials = '';
foreach (explode(' ', $tenant_name) as $p) {
    if ($p !== '') $initials .= strtoupper($p[0]);
}

// ── Flash message ─────────────────────────────────────────────
$success_message = '';
$error_message   = '';
if (isset($_SESSION['pay_flash'])) {
    $flash = $_SESSION['pay_flash'];
    unset($_SESSION['pay_flash']);
    if ($flash['type'] === 'success') $success_message = $flash['msg'];
    else                               $error_message   = $flash['msg'];
}

// ════════════════════════════════════════════════════════════
// PAYMONGO CONFIG
// ════════════════════════════════════════════════════════════
define('PAYMONGO_SECRET_KEY', 'sk_test_6TNbjk1msMMpnPaizPqG6g1D');
define('PAYMONGO_PUBLIC_KEY', 'pk_test_WMKskBpXPFU5xQqzQbDC6Pk5');
define('APP_BASE_URL', 'http://localhost/bms_unified/tenant');

// ════════════════════════════════════════════════════════════
// FEE CALCULATOR  (PayMongo official published rates)
// Returns ['fee'=>float, 'total'=>float, 'pct'=>float, 'fixed'=>float, 'label'=>string]
// ════════════════════════════════════════════════════════════
function calc_fee(float $base, string $method): array {
    switch ($method) {
        case 'gcash':
        case 'GCash':
            $pct   = 2.5;
            $fixed = 0;
            $label = '2.5% GCash fee';
            break;
        case 'paymaya':
        case 'Maya':
            $pct   = 2.5;
            $fixed = 0;
            $label = '2.5% Maya fee';
            break;
        case 'card':
        case 'Card':
            $pct   = 3.5;
            $fixed = 15.00;
            $label = '3.5% + ₱15 card fee';
            break;
        default: // Cash, Bank Transfer, manual methods
            $pct   = 0;
            $fixed = 0;
            $label = 'No convenience fee';
            break;
    }
    $fee   = round(($base * $pct / 100) + $fixed, 2);
    $total = round($base + $fee, 2);
    return ['fee' => $fee, 'total' => $total, 'pct' => $pct, 'fixed' => $fixed, 'label' => $label];
}

// ── Fetch tenant info ─────────────────────────────────────────
$tenant_info  = db_fetch_one($pdo, "SELECT monthly_due_day, monthly_rent, email, room_number FROM tenants WHERE id = ? LIMIT 1", [$tenant_id]);
$monthly_rent = $tenant_info['monthly_rent'] ?? null;
$tenant_email = $tenant_info['email'] ?? '';
$rent_not_set = empty($monthly_rent) || floatval($monthly_rent) <= 0;

// ── Compute due dates ─────────────────────────────────────────
$this_month_due = null;
if (!empty($tenant_info['monthly_due_day'])) {
    $day = (int)$tenant_info['monthly_due_day'];
    $this_month_due = new DateTime(date('Y-m-') . str_pad($day, 2, '0', STR_PAD_LEFT));
}
$next_due = null;
if ($this_month_due) {
    $today    = new DateTime();
    $next_due = ($this_month_due >= $today) ? clone $this_month_due : (clone $this_month_due)->modify('+1 month');
}

function due_date_for_offset(DateTime $base, int $offset): DateTime {
    return (clone $base)->modify("+{$offset} month");
}

// ════════════════════════════════════════════════════════════
// PAYMENT STATE HELPER
// ════════════════════════════════════════════════════════════
function get_month_payment_state(PDO $pdo, int $tenant_id, int $monthOffset = 0): array {
    $stmt = $pdo->prepare("
        SELECT * FROM payments
        WHERE tenant_id = ?
          AND MONTH(due_date) = MONTH(NOW() + INTERVAL {$monthOffset} MONTH)
          AND YEAR(due_date)  = YEAR(NOW()  + INTERVAL {$monthOffset} MONTH)
        ORDER BY
            CASE status
                WHEN 'paid'     THEN 0
                WHEN 'rejected' THEN 1
                WHEN 'pending'  THEN 2
                WHEN 'overdue'  THEN 3
                ELSE 4
            END ASC,
            created_at DESC
        LIMIT 1
    ");
    $stmt->execute([$tenant_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$row) return ['status' => null, 'row' => null];
    return ['status' => $row['status'], 'row' => $row];
}

function get_advance_states(PDO $pdo, int $tenant_id, int $maxMonths = 6): array {
    $states = [];
    for ($i = 0; $i <= $maxMonths; $i++) {
        $states[$i] = get_month_payment_state($pdo, $tenant_id, $i);
    }
    return $states;
}

define('MAX_ADVANCE_MONTHS', 6);

// ════════════════════════════════════════════════════════════
// HANDLE PAYMONGO RETURN (GCash / Maya source redirect)
// ════════════════════════════════════════════════════════════
if (isset($_GET['pm_status'])) {
    if ($_GET['pm_status'] === 'success') {
        $source_id  = $_SESSION['pm_source_id']   ?? '';
        $pm_amount  = $_SESSION['pm_amount']       ?? 0;   // total (rent + fee)
        $pm_rent    = $_SESSION['pm_rent']         ?? $pm_amount;
        $pm_fee     = $_SESSION['pm_fee']          ?? 0;
        $pm_method  = $_SESSION['pm_method_label'] ?? 'Online';
        $pm_due     = $_SESSION['pm_due_date']     ?? date('Y-m-d');
        $pm_note    = $_SESSION['pm_note']         ?? 'Paid online via PayMongo';

        $verified = false;
        if ($source_id) {
            $ch = curl_init("https://api.paymongo.com/v1/sources/{$source_id}");
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => false,
                CURLOPT_HTTPHEADER     => ['Authorization: Basic ' . base64_encode(PAYMONGO_SECRET_KEY . ':')]
            ]);
            $res  = curl_exec($ch); curl_close($ch);
            $data = json_decode($res, true);
            if (in_array($data['data']['attributes']['status'] ?? '', ['chargeable','paid'])) $verified = true;
        }

        if ($verified) {
            // Store total amount charged; note shows rent + fee breakdown
            $fee_note = $pm_fee > 0
                ? " (Rent: ₱".number_format($pm_rent,2)." + Fee: ₱".number_format($pm_fee,2).")"
                : '';
            db_execute($pdo,
                "INSERT INTO payments (tenant_id,amount,due_date,payment_date,payment_method,type,status,submitted_by,admin_notes)
                 VALUES (?,?,?,CURDATE(),?,'rent','paid','tenant',?)",
                [$tenant_id, $pm_amount, $pm_due, $pm_method, $pm_note.$fee_note]
            );
            $_SESSION['pay_flash'] = ['type'=>'success','msg'=>'Payment of ₱'.number_format($pm_amount,2).' via '.$pm_method.' confirmed! (includes ₱'.number_format($pm_fee,2).' convenience fee). Thank you.'];
        } else {
            $_SESSION['pay_flash'] = ['type'=>'error','msg'=>'Payment could not be verified. If you were charged, please contact admin with your reference number.'];
        }
    } elseif ($_GET['pm_status'] === 'failed') {
        $_SESSION['pay_flash'] = ['type'=>'error','msg'=>'Payment was cancelled or failed. Please try again.'];
    }
    unset($_SESSION['pm_source_id'], $_SESSION['pm_amount'], $_SESSION['pm_rent'], $_SESSION['pm_fee'],
          $_SESSION['pm_method_label'], $_SESSION['pm_due_date'], $_SESSION['pm_note']);
    header("Location: payments.php"); exit();
}

// ════════════════════════════════════════════════════════════
// HANDLE FORM SUBMISSIONS
// ════════════════════════════════════════════════════════════
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action     = $_POST['action']     ?? '';
    $is_advance = ($_POST['is_advance'] ?? '0') === '1';
    $adv_off    = max(0, (int)($_POST['adv_offset'] ?? 0));

    $target_offset = $is_advance ? $adv_off : 0;
    if ($target_offset < 0 || $target_offset > MAX_ADVANCE_MONTHS) $target_offset = 0;

    $target_due = $this_month_due
        ? due_date_for_offset($this_month_due, $target_offset)->format('Y-m-d')
        : date('Y-m-d', strtotime("+{$target_offset} month"));

    // ── CRITICAL: Re-check state fresh on every POST ──────
    $target_state  = get_month_payment_state($pdo, $tenant_id, $target_offset);
    $target_status = $target_state['status'];
    $already_block = in_array($target_status, ['paid', 'pending', 'overdue']);

    if ($already_block) {
        $dup_msg = $target_status === 'paid'
            ? 'That month\'s payment is already confirmed.'
            : 'You already have a pending/overdue payment for that month. Please wait for admin confirmation.';
    } else {
        $dup_msg = '';
    }

    // ── Manual payment ────────────────────────────────────────
    if ($action === 'request') {
        if ($rent_not_set) {
            $_SESSION['pay_flash'] = ['type'=>'error','msg'=>'Your monthly rent has not been set by admin yet.'];
        } elseif ($already_block) {
            $_SESSION['pay_flash'] = ['type'=>'error','msg'=>$dup_msg];
        } else {
            $payment_method = trim($_POST['payment_method'] ?? '');
            $due_date       = trim($_POST['due_date'] ?? $target_due);
            $base_amount    = floatval($monthly_rent);
            // Manual methods (Cash, GCash manual, Maya manual, Bank Transfer) — no gateway fee
            $fee_data       = calc_fee($base_amount, $payment_method);
            // For manual methods fee is 0; we store only rent amount
            $amount         = $base_amount;
            $flash_msg      = '';
            $flash_type     = 'success';

            if (!$payment_method) {
                $flash_msg = 'Please select a payment method.'; $flash_type = 'error';
            } elseif (!$due_date || !DateTime::createFromFormat('Y-m-d', $due_date)) {
                $flash_msg = 'Invalid due date.'; $flash_type = 'error';
            } else {
                $proof_image = null;
                $needs_proof = in_array($payment_method, ['GCash', 'Maya', 'Bank Transfer']);
                if ($needs_proof && empty($_FILES['proof_image']['tmp_name'])) {
                    $flash_msg = 'Please upload a screenshot or receipt for '.$payment_method.'.'; $flash_type = 'error';
                } elseif (!empty($_FILES['proof_image']['tmp_name'])) {
                    $ftype = mime_content_type($_FILES['proof_image']['tmp_name']);
                    if (strpos($ftype, 'image/') !== 0) {
                        $flash_msg = 'Please upload an image file (JPG, PNG, etc).'; $flash_type = 'error';
                    } elseif ($_FILES['proof_image']['size'] > 5 * 1024 * 1024) {
                        $flash_msg = 'Image must be under 5MB.'; $flash_type = 'error';
                    } else {
                        $uploadDir = __DIR__ . '/../uploads/payment_proofs/';
                        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                        $ext         = pathinfo($_FILES['proof_image']['name'], PATHINFO_EXTENSION);
                        $proof_image = 'proof_'.time().'_'.$tenant_id.'.'.$ext;
                        if (!move_uploaded_file($_FILES['proof_image']['tmp_name'], $uploadDir.$proof_image)) {
                            $proof_image = null; $flash_msg = 'Failed to save image. Please try again.'; $flash_type = 'error';
                        }
                    }
                }
                if ($flash_type !== 'error') {
                    $adv_note = $is_advance
                        ? 'Advance payment — '.date('F Y', strtotime($due_date))
                        : null;
                    db_execute($pdo,
                        "INSERT INTO payments (tenant_id,amount,due_date,payment_method,type,status,submitted_by,proof_image,admin_notes)
                         VALUES (?,?,?,?,'rent','pending','tenant',?,?)",
                        [$tenant_id, $amount, $due_date, $payment_method, $proof_image, $adv_note]
                    );
                    $month_label = date('F Y', strtotime($due_date));
                    $flash_msg   = ($is_advance ? 'Advance payment' : 'Payment').' of ₱'.number_format($amount,2).' via '.$payment_method.' for '.$month_label.' submitted! Awaiting admin confirmation.';
                }
            }
            $_SESSION['pay_flash'] = ['type'=>$flash_type,'msg'=>$flash_msg];
        }
        header("Location: payments.php"); exit();
    }

    // ── PayMongo payment ──────────────────────────────────────
    if ($action === 'paymongo') {
        if ($rent_not_set) {
            $_SESSION['pay_flash'] = ['type'=>'error','msg'=>'Your monthly rent has not been set yet.'];
            header("Location: payments.php"); exit();
        } elseif ($already_block) {
            $_SESSION['pay_flash'] = ['type'=>'error','msg'=>$dup_msg];
            header("Location: payments.php"); exit();
        } else {
            $pm_type     = $_POST['pm_type'] ?? 'gcash';
            $due_date    = $target_due;
            $base_amount = floatval($monthly_rent);
            $fee_data    = calc_fee($base_amount, $pm_type);
            $total       = $fee_data['total'];
            $fee         = $fee_data['fee'];
            $cents       = (int)round($total * 100);

            $labels      = ['gcash'=>'GCash','paymaya'=>'Maya','card'=>'Card'];
            $label       = $labels[$pm_type] ?? 'Online';
            $month_label = date('F Y', strtotime($due_date));
            $pm_note     = ($is_advance ? 'Advance — '.$month_label.' — ' : '').'Paid online via PayMongo';

            $description = ($is_advance ? '[ADVANCE '.$month_label.'] ' : '')
                . "Rent ₱".number_format($base_amount,2)
                . " + Fee ₱".number_format($fee,2)
                . " = ₱".number_format($total,2)
                . " — Room {$tenant_room} — {$tenant_name}";

            // ── GCash / Maya: Sources API ─────────────────────
            if (in_array($pm_type, ['gcash', 'paymaya'])) {
                $payload = json_encode(['data'=>['attributes'=>[
                    'amount'      => $cents,
                    'currency'    => 'PHP',
                    'type'        => $pm_type,
                    'description' => $description,
                    'redirect'    => [
                        'success' => APP_BASE_URL.'/payments.php?pm_status=success',
                        'failed'  => APP_BASE_URL.'/payments.php?pm_status=failed',
                    ],
                    'billing' => ['name'=>$tenant_name,'email'=>$tenant_email ?: 'tenant@email.com'],
                ]]]);

                $ch = curl_init('https://api.paymongo.com/v1/sources');
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $payload,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => false,
                    CURLOPT_HTTPHEADER     => [
                        'Content-Type: application/json',
                        'Authorization: Basic '.base64_encode(PAYMONGO_SECRET_KEY.':')
                    ],
                ]);
                $res  = curl_exec($ch); $data = json_decode($res, true); curl_close($ch);

                $checkout_url = $data['data']['attributes']['redirect']['checkout_url'] ?? null;
                $source_id    = $data['data']['id'] ?? null;

                if ($checkout_url && $source_id) {
                    $_SESSION['pm_source_id']    = $source_id;
                    $_SESSION['pm_amount']       = $total;
                    $_SESSION['pm_rent']         = $base_amount;
                    $_SESSION['pm_fee']          = $fee;
                    $_SESSION['pm_method_label'] = $label;
                    $_SESSION['pm_due_date']     = $due_date;
                    $_SESSION['pm_note']         = $pm_note;
                    header("Location: {$checkout_url}"); exit();
                } else {
                    $_SESSION['pay_flash'] = ['type'=>'error','msg'=>'Could not connect to payment gateway. Please use another method or try again.'];
                    error_log('[PayMongo Error] '.$res);
                    header("Location: payments.php"); exit();
                }

            // ── Card: PaymentIntent API ───────────────────────
            } elseif ($pm_type === 'card') {
                $pi_payload = json_encode(['data' => ['attributes' => [
                    'amount'               => $cents,
                    'currency'             => 'PHP',
                    'payment_method_types' => ['card'],
                    'description'          => $description,
                    'capture_type'         => 'automatic',
                ]]]);

                $ch = curl_init('https://api.paymongo.com/v1/payment_intents');
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $pi_payload,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_SSL_VERIFYHOST => false,
                    CURLOPT_HTTPHEADER     => [
                        'Content-Type: application/json',
                        'Authorization: Basic '.base64_encode(PAYMONGO_SECRET_KEY.':')
                    ],
                ]);
                $res = curl_exec($ch); curl_close($ch);
                $pi  = json_decode($res, true);

                $pi_id      = $pi['data']['id']                        ?? null;
                $client_key = $pi['data']['attributes']['client_key']  ?? null;

                if ($pi_id && $client_key) {
                    $_SESSION['pm_pi_id']        = $pi_id;
                    $_SESSION['pm_client_key']   = $client_key;
                    $_SESSION['pm_amount']       = $total;
                    $_SESSION['pm_rent']         = $base_amount;
                    $_SESSION['pm_fee']          = $fee;
                    $_SESSION['pm_method_label'] = 'Card';
                    $_SESSION['pm_due_date']     = $due_date;
                    $_SESSION['pm_note']         = $pm_note;
                    $_SESSION['pm_tenant_id']    = $tenant_id;
                    header("Location: card_checkout.php"); exit();
                } else {
                    $_SESSION['pay_flash'] = ['type'=>'error','msg'=>'Could not create card payment. Please try another method.'];
                    error_log('[PayMongo Card Error] '.$res);
                    header("Location: payments.php"); exit();
                }
            }
        }
    }

    header("Location: payments.php"); exit();
}

// ══════════════════════════════════════════════════════════════
// GET — read-only data
// ══════════════════════════════════════════════════════════════
$month_states        = get_advance_states($pdo, $tenant_id, MAX_ADVANCE_MONTHS);
$this_month          = $month_states[0];
$paid_this_month     = $this_month['status'] === 'paid';
$pending_this_month  = in_array($this_month['status'], ['pending', 'overdue']);
$rejected_this_month = $this_month['status'] === 'rejected';

$first_open_offset = null;
for ($i = 1; $i <= MAX_ADVANCE_MONTHS; $i++) {
    $s = $month_states[$i]['status'];
    if ($s === null || $s === 'rejected') { $first_open_offset = $i; break; }
}

$advance_summary = [];
for ($i = 1; $i <= MAX_ADVANCE_MONTHS; $i++) {
    if (!$this_month_due) break;
    $dt     = due_date_for_offset($this_month_due, $i);
    $state  = $month_states[$i];
    $status = $state['status'];
    $advance_summary[] = [
        'offset'   => $i,
        'label'    => $dt->format('F Y'),
        'due_str'  => $dt->format('M j, Y'),
        'due_date' => $dt->format('Y-m-d'),
        'status'   => $status,
        'row'      => $state['row'],
        'can_pay'  => ($status === null || $status === 'rejected'),
    ];
}

$months_covered = 0;
for ($i = 0; $i <= MAX_ADVANCE_MONTHS; $i++) {
    $s = $month_states[$i]['status'];
    if ($s === 'paid' || $s === 'pending' || $s === 'overdue') $months_covered++;
    else break;
}

$adv_offset  = max(1, (int)($_GET['adv_offset'] ?? 1));
if ($adv_offset > MAX_ADVANCE_MONTHS) $adv_offset = MAX_ADVANCE_MONTHS;
$show_advance = isset($_GET['advance']) && $_GET['advance'] === '1' && $paid_this_month;

$adv_form_offset   = max(1, $adv_offset);
if ($adv_form_offset > MAX_ADVANCE_MONTHS) $adv_form_offset = MAX_ADVANCE_MONTHS;
$adv_form_due_date = $this_month_due
    ? due_date_for_offset($this_month_due, $adv_form_offset)->format('Y-m-d')
    : date('Y-m-d', strtotime("+{$adv_form_offset} month"));
$adv_form_label = date('F Y', strtotime($adv_form_due_date));

$adv_target_state = $month_states[$adv_form_offset] ?? ['status'=>null,'row'=>null];
$adv_already_paid = $adv_target_state['status'] === 'paid';
$adv_already_pend = in_array($adv_target_state['status'], ['pending','overdue']);

$current_payment = db_fetch_one($pdo, "
    SELECT * FROM payments
    WHERE tenant_id = ?
    ORDER BY
        CASE WHEN MONTH(due_date)=MONTH(NOW()) AND YEAR(due_date)=YEAR(NOW()) THEN 0 ELSE 1 END ASC,
        CASE status
            WHEN 'paid'    THEN 0 WHEN 'rejected' THEN 1
            WHEN 'pending' THEN 2 WHEN 'overdue'  THEN 3 ELSE 4
        END ASC,
        created_at DESC
    LIMIT 1
", [$tenant_id]);

$current_status = null;
if ($current_payment) {
    $db_status = $current_payment['status'] ?? 'pending';
    if ($db_status === 'paid' || $current_payment['payment_date'] || $current_payment['paid_at']) {
        $current_status = 'paid';
    } elseif ($db_status === 'rejected') { $current_status = 'rejected'; }
    elseif ($db_status === 'overdue')    { $current_status = 'overdue'; }
    else {
        $due = new DateTime($current_payment['due_date']);
        $current_status = ($due < new DateTime()) ? 'overdue' : 'pending';
    }
}

$payment_history = [];
foreach (db_fetch_all($pdo, "SELECT * FROM payments WHERE tenant_id=? ORDER BY created_at DESC LIMIT 36", [$tenant_id]) as $row) {
    if ($row['status']==='paid'||$row['payment_date']||$row['paid_at']) {
        $row['status_label']='Paid'; $row['status_key']='paid';
    } elseif ($row['status']==='rejected') {
        $row['status_label']='Rejected'; $row['status_key']='rejected';
    } elseif ($row['status']==='overdue') {
        $row['status_label']='Overdue'; $row['status_key']='overdue';
    } else {
        $due = new DateTime($row['due_date']);
        if ($due < new DateTime()) { $row['status_label']='Overdue'; $row['status_key']='overdue'; }
        else                       { $row['status_label']='Pending'; $row['status_key']='pending'; }
    }
    $payment_history[] = $row;
}

$method_details = [
    'GCash'         => ['icon'=>'📱','color'=>'#007AFF','name'=>'Ellen BH GCash',    'number'=>'09XX-XXX-XXXX','note'=>'Send exact amount then upload screenshot below'],
    'Maya'          => ['icon'=>'💳','color'=>'#00C170','name'=>'Ellen BH Maya',      'number'=>'09XX-XXX-XXXX','note'=>'Send exact amount then upload screenshot below'],
    'Bank Transfer' => ['icon'=>'🏦','color'=>'#6366f1','name'=>'BDO / BPI Account', 'number'=>'Acc# XXXX-XXXX-XXXX','note'=>'Upload deposit slip or bank transfer screenshot'],
    'Cash'          => ['icon'=>'💵','color'=>'#10b981','name'=>'Pay in Person',      'number'=>'Visit the office','note'=>'Pay to the property manager directly — no upload needed'],
];

$right_panel_mode = 'submit';
if ($rent_not_set)                         $right_panel_mode = 'rent_not_set';
elseif ($paid_this_month && $show_advance) $right_panel_mode = 'advance_form';
elseif ($paid_this_month)                  $right_panel_mode = 'paid_done';
elseif ($pending_this_month)               $right_panel_mode = 'pending_block';

// Pre-compute fee data for JS (base rent fees for each online method)
$rent_base    = floatval($monthly_rent ?? 0);
$fees_json    = json_encode([
    'gcash'    => calc_fee($rent_base, 'gcash'),
    'paymaya'  => calc_fee($rent_base, 'paymaya'),
    'card'     => calc_fee($rent_base, 'card'),
    'Cash'     => calc_fee($rent_base, 'Cash'),
    'GCash'    => calc_fee($rent_base, 'GCash'),
    'Maya'     => calc_fee($rent_base, 'Maya'),
    'Bank Transfer' => calc_fee($rent_base, 'Bank Transfer'),
]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Payments — Monticello TMS</title>
<meta http-equiv="refresh" content="30">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{
  --bg:#080d1a;--surface:#0d1424;--accent:#2563eb;--accent-lt:#3b82f6;
  --accent-gl:rgba(37,99,235,0.15);--ok:#10b981;--warn:#f59e0b;--err:#ef4444;
  --silver:#94a3b8;--light:#cbd5e1;--white:#f1f5f9;
  --border:rgba(255,255,255,0.07);--border-2:rgba(255,255,255,0.04);
  --indigo:#6366f1;--indigo-dim:rgba(99,102,241,0.15);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--light);display:flex;min-height:100vh;}

/* ── Sidebar ── */
.sidebar{width:240px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;height:100vh;z-index:100;}
.sb-logo{padding:1.6rem 1.4rem;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:0.7rem;}
.sb-mark{width:32px;height:32px;background:var(--accent);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:0.9rem;flex-shrink:0;}
.sb-name{font-family:'Syne',sans-serif;font-size:0.9rem;font-weight:700;color:var(--white);}
.sb-name small{display:block;font-size:0.58rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:0.1em;text-transform:uppercase;}
.sb-nav{flex:1;padding:1rem 0.75rem;overflow-y:auto;}
.nav-section-label{font-size:0.58rem;font-weight:700;text-transform:uppercase;letter-spacing:0.14em;color:rgba(148,163,184,0.45);padding:0.6rem 0.65rem 0.4rem;margin-top:0.5rem;}
.nav-link{display:flex;align-items:center;gap:0.7rem;padding:0.62rem 0.75rem;border-radius:5px;font-size:0.82rem;font-weight:500;color:var(--silver);text-decoration:none;transition:all 0.18s;margin-bottom:2px;}
.nav-link:hover{background:rgba(255,255,255,0.05);color:var(--white);}
.nav-link.active{background:var(--accent-gl);color:var(--accent-lt);border-left:2px solid var(--accent);padding-left:calc(0.75rem - 2px);}
.nav-link i{width:16px;font-size:0.8rem;}
.sb-user{padding:1rem 1.1rem;border-top:1px solid var(--border);}
.sb-user-row{display:flex;align-items:center;gap:0.7rem;margin-bottom:0.75rem;}
.sb-avatar{width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,var(--accent),#1d4ed8);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:0.8rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user-name{font-size:0.82rem;font-weight:600;color:var(--white);}
.sb-user-room{font-size:0.68rem;color:var(--silver);}
.logout-btn{width:100%;padding:0.55rem;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.18);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:0.76rem;font-weight:600;color:#fca5a5;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:0.5rem;}

/* ── Layout ── */
.main{margin-left:240px;flex:1;min-height:100vh;}
.topbar{background:var(--surface);border-bottom:1px solid var(--border);padding:0 2rem;height:58px;display:flex;align-items:center;position:sticky;top:0;z-index:50;}
.back-link{width:32px;height:32px;background:var(--border-2);border:1px solid var(--border);border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:0.75rem;color:var(--silver);text-decoration:none;margin-right:1rem;}
.topbar-title h1{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);}
.topbar-title p{font-size:0.72rem;color:var(--silver);}
.content{padding:1.75rem 2rem;}

/* ── Alerts ── */
.alert{display:flex;align-items:flex-start;gap:0.6rem;padding:0.75rem 1rem;border-radius:5px;font-size:0.8rem;margin-bottom:1.25rem;border-left:3px solid;line-height:1.5;}
.alert-ok{background:rgba(16,185,129,0.07);border-color:var(--ok);color:#6ee7b7;}
.alert-err{background:rgba(239,68,68,0.07);border-color:var(--err);color:#fca5a5;}

/* ── Due banners ── */
.due-banner{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.25rem;border-radius:8px;margin-bottom:1rem;}
.due-banner.upcoming{background:rgba(37,99,235,0.08);border:1px solid rgba(37,99,235,0.2);}
.due-banner.soon{background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);}
.due-banner.overdue{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);}
.due-banner.paid{background:rgba(16,185,129,0.06);border:1px solid rgba(16,185,129,0.2);}
.due-banner-left{display:flex;align-items:center;gap:0.85rem;}
.due-icon{width:42px;height:42px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;}
.due-label{font-size:0.68rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--silver);margin-bottom:2px;}
.due-date-text{font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:700;color:var(--white);}
.due-rent{font-size:0.78rem;color:var(--silver);margin-top:2px;}
.due-days{font-family:'Syne',sans-serif;font-size:1.5rem;font-weight:800;text-align:right;line-height:1;}
.due-days small{display:block;font-family:'DM Sans',sans-serif;font-size:0.65rem;font-weight:400;color:var(--silver);margin-top:2px;}
.due-notif{display:flex;align-items:center;gap:0.6rem;padding:0.6rem 1rem;border-radius:6px;margin-bottom:1.25rem;font-size:0.78rem;font-weight:600;}
.due-notif.warn{background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.25);color:#fcd34d;}
.due-notif.danger{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.25);color:#fca5a5;}

/* ── Coverage bar ── */
.coverage-bar{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:1rem 1.25rem;margin-bottom:1.25rem;}
.coverage-bar-title{font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--silver);margin-bottom:0.6rem;display:flex;align-items:center;justify-content:space-between;}
.coverage-bar-title span{color:var(--white);font-family:'Syne',sans-serif;font-size:0.85rem;}
.coverage-months{display:flex;gap:6px;flex-wrap:wrap;}
.cov-chip{display:flex;flex-direction:column;align-items:center;padding:0.45rem 0.7rem;border-radius:6px;font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;border:1.5px solid;min-width:72px;cursor:default;transition:all 0.15s;}
.cov-chip.paid{background:rgba(16,185,129,0.1);border-color:rgba(16,185,129,0.3);color:var(--ok);}
.cov-chip.pending{background:rgba(245,158,11,0.1);border-color:rgba(245,158,11,0.25);color:var(--warn);}
.cov-chip.rejected{background:rgba(239,68,68,0.08);border-color:rgba(239,68,68,0.2);color:var(--err);}
.cov-chip.open{background:rgba(255,255,255,0.02);border-color:var(--border);color:var(--silver);cursor:pointer;}
.cov-chip.open:hover{background:var(--indigo-dim);border-color:var(--indigo);color:#a5b4fc;}
.cov-chip-month{font-size:0.7rem;margin-bottom:2px;}
.cov-chip-status{font-size:0.58rem;opacity:0.8;}

/* ── Panels ── */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.25rem;}
.panel{background:var(--surface);border:1px solid var(--border);border-radius:8px;overflow:hidden;margin-bottom:1.25rem;}
.panel-head{padding:1rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.panel-title{font-family:'Syne',sans-serif;font-size:0.82rem;font-weight:700;color:var(--white);display:flex;align-items:center;gap:0.55rem;}
.panel-title i{font-size:0.75rem;color:var(--accent-lt);}
.panel-body{padding:1.25rem;}

/* ── Status chips ── */
.status-chip{display:inline-flex;align-items:center;gap:0.35rem;padding:0.28rem 0.7rem;border-radius:3px;font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;}
.chip-paid{background:rgba(16,185,129,0.1);color:var(--ok);border:1px solid rgba(16,185,129,0.22);}
.chip-pending{background:rgba(245,158,11,0.1);color:var(--warn);border:1px solid rgba(245,158,11,0.22);}
.chip-overdue{background:rgba(239,68,68,0.1);color:var(--err);border:1px solid rgba(239,68,68,0.22);}
.chip-rejected{background:rgba(90,99,128,.2);color:var(--silver);border:1px solid rgba(90,99,128,.3);}
.status-chip::before{content:'';width:5px;height:5px;border-radius:50%;background:currentColor;}

/* ── Left panel payment info ── */
.pay-amount{font-family:'Syne',sans-serif;font-size:2.4rem;font-weight:800;color:var(--white);line-height:1;margin-bottom:0.75rem;}
.pay-info-row{display:flex;align-items:center;justify-content:space-between;padding:0.6rem 0;border-bottom:1px solid var(--border-2);}
.pay-info-row:last-of-type{border-bottom:none;}
.pi-key{font-size:0.7rem;font-weight:600;text-transform:uppercase;letter-spacing:0.08em;color:var(--silver);}
.pi-val{font-size:0.82rem;font-weight:500;color:var(--white);}
.admin-note-box{display:flex;align-items:flex-start;gap:0.6rem;padding:0.7rem 0.9rem;background:rgba(37,99,235,0.06);border:1px solid rgba(37,99,235,0.18);border-radius:5px;margin-top:0.75rem;font-size:0.78rem;color:var(--light);line-height:1.5;}
.awaiting-notice{display:flex;align-items:center;gap:0.6rem;padding:0.7rem 0.9rem;background:rgba(245,158,11,0.07);border:1px solid rgba(245,158,11,0.2);border-radius:5px;margin-top:1rem;font-size:0.78rem;color:#fcd34d;}
.rejected-notice{display:flex;align-items:flex-start;gap:0.6rem;padding:0.7rem 0.9rem;background:rgba(239,68,68,0.07);border:1px solid rgba(239,68,68,0.2);border-radius:5px;margin-top:1rem;font-size:0.78rem;color:#fca5a5;line-height:1.5;}

/* ── Fee breakdown box ── */
.fee-breakdown{background:rgba(15,23,42,0.8);border:1px solid var(--border);border-radius:8px;padding:0.9rem 1.1rem;margin-bottom:1rem;display:none;}
.fee-breakdown.show{display:block;animation:fadeIn 0.25s ease;}
.fee-row{display:flex;justify-content:space-between;align-items:center;padding:0.35rem 0;font-size:0.8rem;}
.fee-row + .fee-row{border-top:1px solid var(--border-2);}
.fee-row.total-row{border-top:1px solid rgba(255,255,255,0.12)!important;padding-top:0.5rem;margin-top:0.2rem;}
.fee-key{color:var(--silver);}
.fee-val{font-weight:600;color:var(--white);}
.fee-val.fee-amount{color:var(--warn);}
.fee-val.total-amount{font-family:'Syne',sans-serif;font-size:1rem;font-weight:800;color:var(--ok);}
.fee-badge{display:inline-block;font-size:0.58rem;font-weight:700;text-transform:uppercase;padding:1px 6px;border-radius:3px;margin-left:6px;background:rgba(245,158,11,0.15);color:var(--warn);vertical-align:middle;}
.fee-badge.free{background:rgba(16,185,129,0.12);color:var(--ok);}

/* ── Fixed amount box ── */
.fixed-amount-box{background:rgba(37,99,235,0.07);border:1px solid rgba(37,99,235,0.2);border-radius:8px;padding:1rem 1.25rem;margin-bottom:1.25rem;display:flex;align-items:center;justify-content:space-between;}
.fixed-amount-label{font-size:0.7rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;color:var(--silver);}
.fixed-amount-value{font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:var(--white);}
.fixed-amount-note{font-size:0.7rem;color:var(--silver);margin-top:2px;}

/* ── Paid done card ── */
.paid-done-card{text-align:center;padding:1.25rem 1rem 1rem;}
.paid-done-icon{font-size:2.8rem;margin-bottom:0.5rem;display:block;}
.paid-done-title{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);margin-bottom:0.25rem;}
.paid-done-sub{font-size:0.78rem;color:var(--silver);line-height:1.6;margin-bottom:0.75rem;}
.advance-divider{display:flex;align-items:center;gap:0.75rem;font-size:0.6rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:rgba(148,163,184,0.35);margin:0.75rem 0;}
.advance-divider::before,.advance-divider::after{content:'';flex:1;height:1px;background:var(--border);}

/* ── Advance grid ── */
.adv-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:0.5rem;margin-bottom:1rem;}
.adv-month-btn{display:flex;flex-direction:column;align-items:center;padding:0.7rem 0.4rem;border-radius:6px;border:1.5px solid var(--border);background:rgba(255,255,255,0.02);cursor:pointer;transition:all 0.18s;text-decoration:none;}
.adv-month-btn:hover:not(.disabled){border-color:rgba(99,102,241,0.5);background:var(--indigo-dim);}
.adv-month-btn.selected{border-color:var(--indigo);background:var(--indigo-dim);box-shadow:0 0 0 1px var(--indigo);}
.adv-month-btn.paid{border-color:rgba(16,185,129,0.3);background:rgba(16,185,129,0.06);cursor:default;}
.adv-month-btn.pending{border-color:rgba(245,158,11,0.25);background:rgba(245,158,11,0.06);cursor:default;}
.adv-month-name{font-family:'Syne',sans-serif;font-size:0.72rem;font-weight:700;color:var(--white);margin-bottom:3px;}
.adv-month-due{font-size:0.6rem;color:var(--silver);}
.adv-month-badge{font-size:0.58rem;font-weight:700;text-transform:uppercase;margin-top:4px;padding:1px 6px;border-radius:3px;}
.badge-paid{background:rgba(16,185,129,0.15);color:var(--ok);}
.badge-pending{background:rgba(245,158,11,0.15);color:var(--warn);}
.badge-open{background:var(--indigo-dim);color:#a5b4fc;}
.badge-rejected{background:rgba(239,68,68,0.12);color:var(--err);}
.adv-pay-btn{width:100%;padding:0.75rem;background:var(--indigo);color:#fff;border:none;border-radius:5px;font-family:'Syne',sans-serif;font-size:0.82rem;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:0.5rem;transition:all 0.2s;margin-top:0.25rem;}
.adv-pay-btn:hover{background:#4f46e5;box-shadow:0 4px 16px rgba(99,102,241,0.3);}
.adv-selected-info{background:var(--indigo-dim);border:1px solid rgba(99,102,241,0.3);border-radius:6px;padding:0.65rem 0.9rem;font-size:0.76rem;color:#c7d2fe;margin-bottom:0.75rem;display:flex;align-items:center;gap:0.5rem;}

/* ── Blocked box ── */
.blocked-box{text-align:center;padding:1.8rem 1rem;}
.blocked-icon{font-size:2.4rem;margin-bottom:0.65rem;}
.blocked-title{font-family:'Syne',sans-serif;font-size:0.95rem;font-weight:700;color:var(--white);margin-bottom:0.35rem;}
.blocked-msg{font-size:0.8rem;color:var(--silver);line-height:1.6;}

/* ── Tabs ── */
.pay-tabs{display:flex;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:6px;padding:3px;gap:3px;margin-bottom:1.25rem;}
.pay-tab{flex:1;padding:0.55rem;background:transparent;border:none;border-radius:4px;font-family:'DM Sans',sans-serif;font-size:0.78rem;font-weight:600;color:var(--silver);cursor:pointer;transition:all 0.2s;}
.pay-tab.active{background:var(--accent);color:#fff;}
.pay-tab-pane{display:none;}
.pay-tab-pane.active{display:block;}

/* ── Online cards ── */
.online-methods{display:flex;flex-direction:column;gap:0.55rem;margin-bottom:1rem;}
.online-card{display:flex;align-items:center;gap:0.9rem;width:100%;padding:0.9rem 1rem;border:1.5px solid var(--border);border-radius:8px;background:rgba(255,255,255,0.02);cursor:pointer;transition:all 0.18s;font-family:'DM Sans',sans-serif;text-align:left;position:relative;}
.online-card:hover{border-color:rgba(255,255,255,0.18);background:rgba(255,255,255,0.05);transform:translateY(-1px);}
.online-card-badge{position:absolute;top:0.5rem;right:0.75rem;font-size:0.58rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;padding:0.18rem 0.5rem;border-radius:3px;}
.badge-instant{background:rgba(16,185,129,0.15);color:var(--ok);}
.badge-secure{background:rgba(99,102,241,0.15);color:#a5b4fc;}
.online-icon{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.gcash-icon{background:rgba(0,122,255,0.15);}
.maya-icon{background:rgba(0,193,112,0.15);}
.card-icon{background:rgba(99,102,241,0.15);}
.online-card-name{font-size:0.9rem;font-weight:700;color:var(--white);}
.online-card-sub{font-size:0.7rem;color:var(--silver);margin-top:2px;}
.online-card-fee{font-size:0.68rem;color:var(--warn);margin-top:3px;font-weight:600;}
.online-card-arrow{margin-left:auto;color:var(--silver);font-size:0.8rem;opacity:0.6;}
.pm-divider{display:flex;align-items:center;gap:0.75rem;font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:rgba(148,163,184,0.4);margin:0.75rem 0;}
.pm-divider::before,.pm-divider::after{content:'';flex:1;height:1px;background:var(--border);}
.pm-secure-note{display:flex;align-items:center;justify-content:center;gap:0.5rem;font-size:0.7rem;color:var(--silver);margin-top:0.75rem;padding:0.6rem;background:rgba(255,255,255,0.02);border-radius:5px;border:1px solid var(--border);}
.pm-secure-note a{color:var(--accent-lt);text-decoration:none;}

/* ── Manual methods ── */
.methods-label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.09em;color:var(--silver);margin-bottom:0.6rem;display:block;}
.methods-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:0.5rem;margin-bottom:1rem;}
.method-radio{display:none;}
.method-card{padding:0.8rem 0.5rem;background:var(--border-2);border:1.5px solid var(--border);border-radius:6px;cursor:pointer;text-align:center;transition:all 0.18s;}
.method-card:hover{border-color:rgba(255,255,255,0.15);background:rgba(255,255,255,0.03);}
.method-radio:checked + .method-card{background:var(--accent-gl);border-color:var(--accent);box-shadow:0 0 0 1px var(--accent);}
.method-ic{width:36px;height:36px;border-radius:6px;background:rgba(255,255,255,0.06);display:flex;align-items:center;justify-content:center;font-size:1rem;margin:0 auto 0.4rem;}
.method-radio:checked + .method-card .method-ic{background:rgba(37,99,235,0.18);}
.method-name{font-size:0.72rem;font-weight:700;color:var(--white);}
.method-sub{font-size:0.62rem;color:var(--silver);margin-top:1px;}
.account-box{display:none;padding:1rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:6px;margin-bottom:1rem;}
.account-box.show{display:block;animation:fadeIn 0.2s ease;}
@keyframes fadeIn{from{opacity:0;transform:translateY(-3px);}to{opacity:1;transform:translateY(0);}}
.account-box-header{display:flex;align-items:center;gap:0.6rem;margin-bottom:0.6rem;}
.account-box-icon{font-size:1.3rem;}
.account-box-name{font-size:0.82rem;font-weight:700;color:var(--white);}
.account-copy-row{display:flex;align-items:center;justify-content:space-between;gap:0.5rem;margin-bottom:0.3rem;}
.account-box-number{font-family:'Syne',sans-serif;font-size:1.1rem;font-weight:700;}
.account-box-note{font-size:0.72rem;color:var(--silver);}
.copy-btn{padding:0.25rem 0.6rem;font-size:0.62rem;font-weight:700;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:3px;color:var(--silver);cursor:pointer;flex-shrink:0;transition:all 0.15s;}
.copy-btn:hover{background:rgba(255,255,255,0.1);color:var(--white);}

/* ── Form ── */
.field{display:flex;flex-direction:column;gap:0.3rem;margin-bottom:0.85rem;}
.field label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.09em;color:var(--silver);}
.field input{width:100%;padding:0.68rem 0.9rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.09);border-radius:4px;font-family:'DM Sans',sans-serif;font-size:0.875rem;color:var(--white);outline:none;transition:border-color 0.2s;}
.field input:focus{border-color:var(--accent);}
.proof-upload{width:100%;padding:.6rem .9rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.09);border-radius:4px;font-family:'DM Sans',sans-serif;font-size:.82rem;color:var(--silver);cursor:pointer;}
.btn-primary{width:100%;padding:0.8rem;background:var(--accent);color:#fff;border:none;border-radius:4px;font-family:'Syne',sans-serif;font-size:0.86rem;font-weight:600;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-top:0.5rem;}
.btn-primary:hover{background:#1d4ed8;box-shadow:0 5px 16px var(--accent-gl);}
.btn-back{display:inline-flex;align-items:center;gap:0.4rem;font-size:0.75rem;color:var(--silver);text-decoration:none;padding:0.4rem 0;transition:color 0.15s;}
.btn-back:hover{color:var(--white);}
#proof_preview{display:none;margin-top:8px;}
#proof_preview img{max-width:100%;max-height:160px;border-radius:6px;border:1px solid rgba(255,255,255,0.1);}
#proof_preview small{display:block;font-size:11px;color:var(--silver);margin-top:4px;}

/* ── History table ── */
.hist-table{width:100%;border-collapse:collapse;}
.hist-table th{text-align:left;font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;color:var(--silver);padding:0 0 0.65rem;border-bottom:1px solid var(--border);}
.hist-table th:last-child,.hist-table td:last-child{text-align:right;}
.hist-table td{padding:0.75rem 0;border-bottom:1px solid var(--border-2);font-size:0.82rem;color:var(--light);vertical-align:middle;}
.hist-table tr:last-child td{border-bottom:none;}
.tbl-status{display:inline-flex;align-items:center;gap:0.3rem;padding:0.22rem 0.6rem;border-radius:3px;font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;}
.tbl-paid{background:rgba(16,185,129,0.1);color:var(--ok);border:1px solid rgba(16,185,129,0.2);}
.tbl-pending{background:rgba(245,158,11,0.1);color:var(--warn);border:1px solid rgba(245,158,11,0.2);}
.tbl-overdue{background:rgba(239,68,68,0.1);color:var(--err);border:1px solid rgba(239,68,68,0.2);}
.tbl-rejected{background:rgba(90,99,128,.15);color:var(--silver);border:1px solid rgba(90,99,128,.25);}
.tbl-status::before{content:'';width:4px;height:4px;border-radius:50%;background:currentColor;}
.tbl-amount{font-family:'Syne',sans-serif;font-weight:700;color:var(--ok);}
.empty{text-align:center;padding:2.5rem 1rem;color:var(--silver);font-size:0.82rem;}
.empty i{font-size:1.6rem;opacity:0.2;display:block;margin-bottom:0.65rem;}

/* ── Advance modal ── */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.7);display:none;align-items:center;justify-content:center;z-index:999;padding:1rem;}
.modal-overlay.open{display:flex;}
.modal-box{background:var(--surface);border:1px solid var(--border);border-radius:10px;width:100%;max-width:460px;max-height:90vh;overflow-y:auto;box-shadow:0 24px 60px rgba(0,0,0,0.6);}
.modal-head{padding:1rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.modal-head-title{font-family:'Syne',sans-serif;font-size:0.92rem;font-weight:700;color:var(--white);}
.modal-close{background:none;border:1px solid var(--border);border-radius:4px;width:28px;height:28px;display:flex;align-items:center;justify-content:center;color:var(--silver);cursor:pointer;font-size:0.8rem;}
.modal-body{padding:1.25rem;}

@media(max-width:900px){.two-col{grid-template-columns:1fr;}.adv-grid{grid-template-columns:repeat(2,1fr);}}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <div class="sb-mark">⬡</div>
    <div class="sb-name">Monticello <small>Tenant Portal</small></div>
  </div>
  <nav class="sb-nav">
    <div class="nav-section-label">Main</div>
    <a href="dashboard.php" class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
    <a href="payments.php"  class="nav-link active"><i class="fas fa-credit-card"></i> Payments</a>
    <div class="nav-section-label">Account</div>
    <a href="invoices.php"       class="nav-link"><i class="fas fa-file-invoice"></i> Invoices</a>
    <a href="maintenance.php"    class="nav-link"><i class="fas fa-tools"></i> Maintenance</a>
    <a href="communications.php" class="nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="profile.php"        class="nav-link"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sb-user">
    <div class="sb-user-row">
      <div class="sb-avatar"><?= htmlspecialchars($initials) ?></div>
      <div>
        <div class="sb-user-name"><?= htmlspecialchars($tenant_name) ?></div>
        <div class="sb-user-room">Room <?= htmlspecialchars($tenant_room) ?></div>
      </div>
    </div>
    <form method="POST" action="logout.php" style="margin:0;">
      <button type="submit" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Sign Out</button>
    </form>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i></a>
    <div class="topbar-title">
      <h1>Payments</h1>
      <p>Submit and track your rental payments</p>
    </div>
  </div>

  <div class="content">

    <?php if ($success_message): ?>
    <div class="alert alert-ok"><i class="fas fa-check-circle"></i> <?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>
    <?php if ($error_message): ?>
    <div class="alert alert-err"><i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>

    <?php if ($next_due && $monthly_rent):
      $today  = new DateTime();
      $diff   = (int)$today->diff($next_due)->days;
      $isPast = $next_due < $today;
      $isSoon = !$isPast && $diff <= 5;
      if ($paid_this_month)      { $bannerCls='paid';     $iconEmoji='✅'; }
      elseif ($isPast)           { $bannerCls='overdue';  $iconEmoji='🔴'; }
      elseif ($isSoon)           { $bannerCls='soon';     $iconEmoji='🟡'; }
      else                       { $bannerCls='upcoming'; $iconEmoji='📅'; }
    ?>

    <?php if (!$paid_this_month):
      if ($isPast): ?>
    <div class="due-notif danger"><i class="fas fa-exclamation-triangle"></i> ⚠ Your rent is <strong><?= $diff ?> day<?= $diff!==1?'s':'' ?> overdue</strong> — due <?= $next_due->format('F j, Y') ?>. Please submit immediately.</div>
    <?php elseif ($diff === 0): ?>
    <div class="due-notif danger"><i class="fas fa-bell"></i> 🔔 Your rent is <strong>due today</strong>. Please submit now.</div>
    <?php elseif ($isSoon): ?>
    <div class="due-notif warn"><i class="fas fa-clock"></i> ⏰ Rent due in <strong><?= $diff ?> day<?= $diff!==1?'s':'' ?></strong> on <?= $next_due->format('F j, Y') ?>.</div>
    <?php endif; endif; ?>

    <div class="due-banner <?= $bannerCls ?>">
      <div class="due-banner-left">
        <div class="due-icon"><?= $iconEmoji ?></div>
        <div>
          <?php if ($paid_this_month): ?>
            <div class="due-label">This Month</div>
            <div class="due-date-text" style="color:var(--ok);">Payment Confirmed ✓</div>
            <div class="due-rent">Next due: <strong style="color:var(--white)"><?= $next_due->format('F j, Y') ?></strong></div>
          <?php else: ?>
            <div class="due-label"><?= $isPast?'Was Due':($diff<=5?'Due Soon':'Next Due Date') ?></div>
            <div class="due-date-text" <?= $isPast?'style="color:var(--err)"':($isSoon?'style="color:var(--warn)"':'') ?>><?= $next_due->format('F j, Y') ?></div>
            <div class="due-rent">Monthly rent: <strong style="color:var(--white)">₱<?= number_format($monthly_rent,2) ?></strong></div>
          <?php endif; ?>
        </div>
      </div>
      <div>
        <?php if ($paid_this_month): ?>
          <div class="due-days" style="color:var(--ok);font-size:1.1rem;">Paid<small>this month</small></div>
        <?php elseif ($isPast): ?>
          <div class="due-days" style="color:#fca5a5;"><?= $diff ?><small>days overdue</small></div>
        <?php elseif ($diff===0): ?>
          <div class="due-days" style="color:var(--err);">Today!<small>due today</small></div>
        <?php else: ?>
          <div class="due-days" style="color:<?= $isSoon?'var(--warn)':'var(--accent-lt)' ?>"><?= $diff ?><small>days left</small></div>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($this_month_due && $monthly_rent):
      $all_chips = [];
      $s0 = $month_states[0]['status'];
      $all_chips[] = ['label'=>date('M Y'),'status'=>$s0??'open','offset'=>0];
      foreach ($advance_summary as $adv) {
          $all_chips[] = ['label'=>date('M Y',strtotime($adv['due_date'])),'status'=>$adv['status']??'open','offset'=>$adv['offset']];
      }
    ?>
    <div class="coverage-bar">
      <div class="coverage-bar-title">
        <span>Payment Coverage</span>
        <span><?= $months_covered ?> month<?= $months_covered!==1?'s':'' ?> covered</span>
      </div>
      <div class="coverage-months">
        <?php foreach ($all_chips as $chip):
          $cls = match($chip['status']){ 'paid'=>'paid','pending','overdue'=>'pending','rejected'=>'rejected',default=>'open'};
          $icon= match($chip['status']){ 'paid'=>'✓','pending','overdue'=>'⏳','rejected'=>'✕',default=>'＋'};
          $is_clickable = ($chip['status']===null||$chip['status']==='rejected') && $chip['offset']>0 && $paid_this_month;
          $href = $is_clickable ? "payments.php?advance=1&adv_offset={$chip['offset']}" : '#';
        ?>
        <<?= $is_clickable?'a href="'.$href.'"':'div' ?> class="cov-chip <?= $cls ?>" title="<?= $chip['label'] ?>">
          <span class="cov-chip-month"><?= $chip['label'] ?></span>
          <span class="cov-chip-status"><?= $icon ?> <?= $chip['status']===null?'Open':ucfirst($chip['status']) ?></span>
        </<?= $is_clickable?'a':'div' ?>>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="two-col">

      <!-- ══ LEFT: Latest Payment ══ -->
      <div class="panel">
        <div class="panel-head">
          <div class="panel-title"><i class="fas fa-file-invoice-dollar"></i> Latest Payment</div>
          <?php if ($current_payment): ?>
          <span class="status-chip chip-<?= $current_status ?>"><?= ucfirst($current_status) ?></span>
          <?php endif; ?>
        </div>
        <div class="panel-body">
          <?php if ($current_payment): ?>
            <div class="pay-amount">₱<?= number_format($current_payment['amount'],2) ?></div>
            <div class="pay-info-row"><span class="pi-key">Due Date</span><span class="pi-val"><?= date('F j, Y',strtotime($current_payment['due_date'])) ?></span></div>
            <div class="pay-info-row"><span class="pi-key">Method</span><span class="pi-val"><?= htmlspecialchars($current_payment['payment_method']??'—') ?></span></div>
            <div class="pay-info-row"><span class="pi-key">Submitted</span><span class="pi-val"><?= date('F j, Y',strtotime($current_payment['created_at'])) ?></span></div>
            <div class="pay-info-row"><span class="pi-key">Confirmed On</span><span class="pi-val"><?php $cd=$current_payment['paid_at']?:$current_payment['payment_date']; echo $cd?date('F j, Y',strtotime($cd)):'—'; ?></span></div>
            <?php if (!empty($current_payment['admin_notes'])): ?>
            <div class="admin-note-box"><i class="fas fa-comment-alt"></i><span><strong>Admin note:</strong> <?= htmlspecialchars($current_payment['admin_notes']) ?></span></div>
            <?php endif; ?>
            <?php if ($current_status==='pending'): ?>
            <div class="awaiting-notice"><i class="fas fa-hourglass-half"></i> Awaiting admin confirmation.</div>
            <?php elseif ($current_status==='rejected'): ?>
            <div class="rejected-notice">
              <i class="fas fa-times-circle" style="margin-top:2px;flex-shrink:0;"></i>
              <span><strong>Payment Rejected.</strong><?php if (!empty($current_payment['admin_notes'])): ?> Reason: <?= htmlspecialchars($current_payment['admin_notes']) ?><?php endif; ?><br>Please resubmit.</span>
            </div>
            <?php endif; ?>
          <?php else: ?>
            <div class="empty"><i class="fas fa-inbox"></i>No payments submitted yet.</div>
          <?php endif; ?>
        </div>
      </div>

      <!-- ══ RIGHT: Action Panel ══ -->
      <div class="panel">
        <div class="panel-head">
          <div class="panel-title">
            <i class="fas fa-paper-plane"></i>
            <?= match($right_panel_mode){
              'paid_done'    => 'This Month\'s Payment',
              'advance_form' => 'Advance Payment — '.$adv_form_label,
              default        => 'Submit Payment',
            } ?>
          </div>
          <?php if ($right_panel_mode==='advance_form'): ?>
          <a href="payments.php" class="btn-back"><i class="fas fa-arrow-left"></i> Back</a>
          <?php endif; ?>
        </div>
        <div class="panel-body">

          <?php if ($right_panel_mode==='rent_not_set'): ?>
          <div class="blocked-box"><div class="blocked-icon">⚙️</div><div class="blocked-title">Rent Not Set Yet</div><div class="blocked-msg">Your monthly rent has not been configured.<br>Please contact the property manager.</div></div>

          <?php elseif ($right_panel_mode==='pending_block'): ?>
          <div class="blocked-box"><div class="blocked-icon">⏳</div><div class="blocked-title">Payment Already Submitted</div><div class="blocked-msg">You already submitted a payment this month.<br>Please wait for admin confirmation.</div></div>

          <?php elseif ($right_panel_mode==='paid_done'): ?>
          <div class="paid-done-card">
            <span class="paid-done-icon">✅</span>
            <div class="paid-done-title">All Paid for This Month!</div>
            <div class="paid-done-sub">Your <?= date('F Y') ?> payment is confirmed.<br>Nothing more to do this month.</div>
          </div>
          <div class="advance-divider">pay ahead for future months</div>
          <div class="adv-grid" id="advGrid">
            <?php foreach ($advance_summary as $adv):
              $s = $adv['status'];
              $chip_cls = match(true){ $s==='paid'=>'paid', in_array($s,['pending','overdue'])=>'pending', default=>'open' };
              $badge_cls = match(true){ $s==='paid'=>'badge-paid', in_array($s,['pending','overdue'])=>'badge-pending', $s==='rejected'=>'badge-rejected', default=>'badge-open' };
              $badge_txt = match(true){ $s==='paid'=>'✓ Paid', in_array($s,['pending','overdue'])=>'⏳ Pending', $s==='rejected'=>'✕ Rejected', default=>'＋ Pay' };
              $can_click = ($s===null||$s==='rejected');
            ?>
            <div class="adv-month-btn <?= $chip_cls ?> <?= $adv['offset']===$adv_form_offset?'selected':'' ?>"
                 <?= $can_click?'onclick="selectAdvMonth('.$adv['offset'].',\''.$adv['due_date'].'\',\''.$adv['label'].'\')" style="cursor:pointer"':'' ?>
                 data-offset="<?= $adv['offset'] ?>" data-status="<?= $s??'open' ?>">
              <div class="adv-month-name"><?= $adv['label'] ?></div>
              <div class="adv-month-due">Due <?= $adv['due_str'] ?></div>
              <div class="adv-month-badge <?= $badge_cls ?>"><?= $badge_txt ?></div>
            </div>
            <?php endforeach; ?>
          </div>
          <div id="advSelectedInfo" class="adv-selected-info" style="display:none;">
            <i class="fas fa-calendar-check"></i><span id="advSelectedText"></span>
          </div>
          <button class="adv-pay-btn" id="advPayBtn" style="display:none;" onclick="openAdvModal()">
            <i class="fas fa-forward"></i> <span id="advPayBtnLabel">Pay in Advance</span>
          </button>

          <?php elseif ($right_panel_mode==='advance_form'): ?>
          <?php if ($adv_already_paid): ?>
          <div class="blocked-box"><div class="blocked-icon">✅</div><div class="blocked-title">Already Confirmed</div><div class="blocked-msg"><?= $adv_form_label ?> rent is already confirmed.<br><a href="payments.php" style="color:var(--accent-lt);">← Back</a></div></div>
          <?php elseif ($adv_already_pend): ?>
          <div class="blocked-box"><div class="blocked-icon">⏳</div><div class="blocked-title">Already Submitted</div><div class="blocked-msg"><?= $adv_form_label ?> advance is awaiting confirmation.<br><a href="payments.php" style="color:var(--accent-lt);">← Back</a></div></div>
          <?php else: ?>
          <div class="fixed-amount-box">
            <div>
              <div class="fixed-amount-label">Advance — <?= $adv_form_label ?></div>
              <div class="fixed-amount-note">Due <?= date('M j, Y',strtotime($adv_form_due_date)) ?> · Fee added at checkout</div>
            </div>
            <div class="fixed-amount-value">₱<?= number_format($monthly_rent,2) ?></div>
          </div>
          <div class="pay-tabs" id="payTabsAdv">
            <button type="button" class="pay-tab active" data-tab="adv-online">⚡ Pay Online</button>
            <button type="button" class="pay-tab"        data-tab="adv-manual">📋 Manual / Cash</button>
          </div>
          <div class="pay-tab-pane active" id="tab-adv-online">
            <form method="POST" action="payments.php" id="pmFormAdv">
              <input type="hidden" name="action"     value="paymongo">
              <input type="hidden" name="is_advance" value="1">
              <input type="hidden" name="adv_offset" value="<?= $adv_form_offset ?>">
              <input type="hidden" name="pm_type"    id="pm_type_adv" value="">
              <input type="hidden" name="due_date"   value="<?= htmlspecialchars($adv_form_due_date) ?>">
              <div class="online-methods">
                <button type="button" class="online-card" onclick="payOnlineAdv('gcash')">
                  <div class="online-icon gcash-icon">📱</div>
                  <div><div class="online-card-name">GCash</div><div class="online-card-sub">Pay via GCash e-wallet</div><div class="online-card-fee" id="adv-fee-gcash">+₱<?= number_format(calc_fee($rent_base,'gcash')['fee'],2) ?> fee → Total ₱<?= number_format(calc_fee($rent_base,'gcash')['total'],2) ?></div></div>
                  <span class="online-card-badge badge-instant">Instant</span>
                  <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
                </button>
                <button type="button" class="online-card" onclick="payOnlineAdv('paymaya')">
                  <div class="online-icon maya-icon">💳</div>
                  <div><div class="online-card-name">Maya</div><div class="online-card-sub">Pay via Maya e-wallet</div><div class="online-card-fee" id="adv-fee-maya">+₱<?= number_format(calc_fee($rent_base,'paymaya')['fee'],2) ?> fee → Total ₱<?= number_format(calc_fee($rent_base,'paymaya')['total'],2) ?></div></div>
                  <span class="online-card-badge badge-instant">Instant</span>
                  <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
                </button>
                <div class="pm-divider">or pay with card</div>
                <button type="button" class="online-card" onclick="payOnlineAdv('card')">
                  <div class="online-icon card-icon">🏦</div>
                  <div><div class="online-card-name">Credit / Debit Card</div><div class="online-card-sub">Visa, Mastercard, JCB</div><div class="online-card-fee" id="adv-fee-card">+₱<?= number_format(calc_fee($rent_base,'card')['fee'],2) ?> fee → Total ₱<?= number_format(calc_fee($rent_base,'card')['total'],2) ?></div></div>
                  <span class="online-card-badge badge-secure">Secure</span>
                  <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
                </button>
              </div>
              <div class="pm-secure-note"><i class="fas fa-lock" style="color:var(--ok);"></i> Secured by <a href="https://paymongo.com" target="_blank">PayMongo</a> — PCI-DSS Level 1.</div>
            </form>
          </div>
          <div class="pay-tab-pane" id="tab-adv-manual">
            <form method="POST" action="payments.php" enctype="multipart/form-data" id="advManualForm">
              <input type="hidden" name="action"     value="request">
              <input type="hidden" name="is_advance" value="1">
              <input type="hidden" name="adv_offset" value="<?= $adv_form_offset ?>">
              <input type="hidden" name="amount"     value="<?= htmlspecialchars($monthly_rent) ?>">
              <input type="hidden" name="due_date"   value="<?= htmlspecialchars($adv_form_due_date) ?>">
              <span class="methods-label">Select Payment Method</span>
              <div class="methods-grid">
                <?php foreach (['Cash'=>['💵','Pay in person'],'GCash'=>['📱','Manual transfer'],'Maya'=>['💳','Manual transfer'],'Bank Transfer'=>['🏦','BDO / BPI']] as $mv=>[$mic,$msub]): ?>
                <div>
                  <input type="radio" name="payment_method" value="<?= $mv ?>" id="a-<?= strtolower(str_replace(' ','-',$mv)) ?>" class="adv-method-radio">
                  <label for="a-<?= strtolower(str_replace(' ','-',$mv)) ?>" class="method-card">
                    <div class="method-ic"><?= $mic ?></div>
                    <div class="method-name"><?= $mv ?></div>
                    <div class="method-sub"><?= $msub ?></div>
                  </label>
                </div>
                <?php endforeach; ?>
              </div>
              <div id="adv-manual-fee-box" class="fee-breakdown"></div>
              <?php foreach ($method_details as $mkey=>$mval): ?>
              <div class="account-box" id="abox-<?= htmlspecialchars(str_replace(' ','-',$mkey)) ?>">
                <div class="account-box-header"><span class="account-box-icon"><?= $mval['icon'] ?></span><span class="account-box-name"><?= htmlspecialchars($mval['name']) ?></span></div>
                <div class="account-copy-row"><div class="account-box-number" style="color:<?= $mval['color'] ?>"><?= htmlspecialchars($mval['number']) ?></div><?php if($mval['number']!=='Visit the office'): ?><button type="button" class="copy-btn" onclick="copyText('<?= htmlspecialchars($mval['number']) ?>',this)">Copy</button><?php endif; ?></div>
                <div class="account-box-note"><?= htmlspecialchars($mval['note']) ?></div>
              </div>
              <?php endforeach; ?>
              <div class="field" id="adv-proof-field" style="display:none;"><label>Upload Screenshot / Receipt <span style="color:var(--err);">*required</span></label><input type="file" name="proof_image" accept="image/*" class="proof-upload"></div>
              <button type="submit" class="btn-primary" style="background:var(--indigo);"><i class="fas fa-forward"></i> Submit Advance for <?= $adv_form_label ?></button>
            </form>
          </div>
          <?php endif; ?>

          <?php else: ?>
          <!-- ════ NORMAL SUBMIT ════ -->
          <?php $form_due_date=$this_month_due?$this_month_due->format('Y-m-d'):date('Y-m-d'); ?>
          <?php if ($rejected_this_month): ?>
          <div class="rejected-notice" style="margin-bottom:1rem;"><i class="fas fa-times-circle" style="margin-top:2px;flex-shrink:0;"></i><span><strong>Your previous payment was rejected.</strong><?php if(!empty($this_month['row']['admin_notes'])): ?> Reason: <?= htmlspecialchars($this_month['row']['admin_notes']) ?><?php endif; ?><br>Please resubmit below.</span></div>
          <?php endif; ?>
          <div class="fixed-amount-box">
            <div>
              <div class="fixed-amount-label">Monthly Rent</div>
              <div class="fixed-amount-note">Fee is added automatically based on method</div>
            </div>
            <div class="fixed-amount-value">₱<?= number_format($monthly_rent,2) ?></div>
          </div>
          <div class="pay-tabs" id="payTabs">
            <button type="button" class="pay-tab active" data-tab="online">⚡ Pay Online</button>
            <button type="button" class="pay-tab"        data-tab="manual">📋 Manual / Cash</button>
          </div>

          <!-- Online Tab -->
          <div class="pay-tab-pane active" id="tab-online">
            <!-- Fee breakdown shown after selecting method -->
            <div class="fee-breakdown" id="online-fee-box"></div>
            <form method="POST" action="payments.php" id="pmForm">
              <input type="hidden" name="action"     value="paymongo">
              <input type="hidden" name="is_advance" value="0">
              <input type="hidden" name="adv_offset" value="0">
              <input type="hidden" name="pm_type"    id="pm_type" value="">
              <input type="hidden" name="due_date"   value="<?= htmlspecialchars($form_due_date) ?>">
              <div class="online-methods">
                <button type="button" class="online-card" onclick="selectOnline('gcash')">
                  <div class="online-icon gcash-icon">📱</div>
                  <div>
                    <div class="online-card-name">GCash</div>
                    <div class="online-card-sub">Pay via GCash e-wallet</div>
                    <div class="online-card-fee">+₱<?= number_format(calc_fee($rent_base,'gcash')['fee'],2) ?> fee &rarr; Total <strong>₱<?= number_format(calc_fee($rent_base,'gcash')['total'],2) ?></strong></div>
                  </div>
                  <span class="online-card-badge badge-instant">Instant</span>
                  <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
                </button>
                <button type="button" class="online-card" onclick="selectOnline('paymaya')">
                  <div class="online-icon maya-icon">💳</div>
                  <div>
                    <div class="online-card-name">Maya</div>
                    <div class="online-card-sub">Pay via Maya e-wallet</div>
                    <div class="online-card-fee">+₱<?= number_format(calc_fee($rent_base,'paymaya')['fee'],2) ?> fee &rarr; Total <strong>₱<?= number_format(calc_fee($rent_base,'paymaya')['total'],2) ?></strong></div>
                  </div>
                  <span class="online-card-badge badge-instant">Instant</span>
                  <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
                </button>
                <div class="pm-divider">or pay with card</div>
                <button type="button" class="online-card" onclick="selectOnline('card')">
                  <div class="online-icon card-icon">🏦</div>
                  <div>
                    <div class="online-card-name">Credit / Debit Card</div>
                    <div class="online-card-sub">Visa, Mastercard, JCB</div>
                    <div class="online-card-fee">+₱<?= number_format(calc_fee($rent_base,'card')['fee'],2) ?> fee &rarr; Total <strong>₱<?= number_format(calc_fee($rent_base,'card')['total'],2) ?></strong></div>
                  </div>
                  <span class="online-card-badge badge-secure">Secure</span>
                  <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
                </button>
              </div>
              <div class="pm-secure-note"><i class="fas fa-lock" style="color:var(--ok);"></i> Secured by <a href="https://paymongo.com" target="_blank">PayMongo</a> — PCI-DSS Level 1.</div>
            </form>
          </div>

          <!-- Manual Tab -->
          <div class="pay-tab-pane" id="tab-manual">
            <form method="POST" action="payments.php" enctype="multipart/form-data">
              <input type="hidden" name="action"     value="request">
              <input type="hidden" name="is_advance" value="0">
              <input type="hidden" name="adv_offset" value="0">
              <input type="hidden" name="amount"     value="<?= htmlspecialchars($monthly_rent) ?>">
              <input type="hidden" name="due_date"   value="<?= htmlspecialchars($form_due_date) ?>">
              <span class="methods-label">Select Payment Method</span>
              <div class="methods-grid">
                <?php foreach (['Cash'=>['💵','Pay in person'],'GCash'=>['📱','Manual transfer'],'Maya'=>['💳','Manual transfer'],'Bank Transfer'=>['🏦','BDO / BPI']] as $mv=>[$mic,$msub]): ?>
                <div>
                  <input type="radio" name="payment_method" value="<?= $mv ?>" id="m-<?= strtolower(str_replace(' ','-',$mv)) ?>" class="method-radio">
                  <label for="m-<?= strtolower(str_replace(' ','-',$mv)) ?>" class="method-card">
                    <div class="method-ic"><?= $mic ?></div>
                    <div class="method-name"><?= $mv ?></div>
                    <div class="method-sub"><?= $msub ?></div>
                  </label>
                </div>
                <?php endforeach; ?>
              </div>
              <!-- Manual fee breakdown (always ₱0 for manual) -->
              <div id="manual-fee-box" class="fee-breakdown"></div>
              <?php foreach ($method_details as $mkey=>$mval): ?>
              <div class="account-box" id="box-<?= htmlspecialchars(str_replace(' ','-',$mkey)) ?>">
                <div class="account-box-header"><span class="account-box-icon"><?= $mval['icon'] ?></span><span class="account-box-name"><?= htmlspecialchars($mval['name']) ?></span></div>
                <div class="account-copy-row"><div class="account-box-number" style="color:<?= $mval['color'] ?>"><?= htmlspecialchars($mval['number']) ?></div><?php if($mval['number']!=='Visit the office'): ?><button type="button" class="copy-btn" onclick="copyText('<?= htmlspecialchars($mval['number']) ?>',this)">Copy</button><?php endif; ?></div>
                <div class="account-box-note"><?= htmlspecialchars($mval['note']) ?></div>
              </div>
              <?php endforeach; ?>
              <div class="field" id="proof-field" style="display:none;"><label>Upload Screenshot / Receipt <span style="color:var(--err);">*required</span></label><input type="file" name="proof_image" id="proof_image" accept="image/*" class="proof-upload" onchange="previewProof(this)"><div id="proof_preview"><img id="proof_img_prev" src="" alt=""><small>Preview — sent to admin for verification</small></div></div>
              <button type="submit" class="btn-primary"><i class="fas fa-paper-plane"></i> Submit Payment Request</button>
            </form>
          </div>

          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- ══ Payment History ══ -->
    <div class="panel">
      <div class="panel-head">
        <div class="panel-title"><i class="fas fa-table"></i> Payment History</div>
        <span style="font-size:0.72rem;color:var(--silver);"><?= count($payment_history) ?> record<?= count($payment_history)!==1?'s':'' ?></span>
      </div>
      <div class="panel-body">
        <?php if (count($payment_history)>0): ?>
        <table class="hist-table">
          <thead><tr><th>Submitted</th><th>Due Date</th><th>Method</th><th>Confirmed On</th><th>Note / Fee</th><th>Status</th><th>Total Paid</th></tr></thead>
          <tbody>
            <?php foreach ($payment_history as $p): ?>
            <tr>
              <td><?= date('M j, Y',strtotime($p['created_at'])) ?></td>
              <td><?= date('M j, Y',strtotime($p['due_date'])) ?></td>
              <td style="font-size:0.75rem;color:var(--silver);"><?= htmlspecialchars($p['payment_method']??'—') ?></td>
              <td><?php $cd=$p['paid_at']?:$p['payment_date']; echo $cd?date('M j, Y',strtotime($cd)):'—'; ?></td>
              <td style="font-size:0.72rem;color:var(--silver);max-width:160px;"><?= $p['admin_notes']?htmlspecialchars($p['admin_notes']):'—' ?></td>
              <td><span class="tbl-status tbl-<?= $p['status_key'] ?>"><?= $p['status_label'] ?></span></td>
              <td class="tbl-amount">₱<?= number_format($p['amount'],2) ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
        <?php else: ?>
        <div class="empty"><i class="fas fa-receipt"></i>No payment history yet.</div>
        <?php endif; ?>
      </div>
    </div>

  </div>
</div>

<!-- ══ Advance Payment Modal ══ -->
<div class="modal-overlay" id="advModal">
  <div class="modal-box">
    <div class="modal-head">
      <div class="modal-head-title">💸 Pay in Advance</div>
      <button class="modal-close" onclick="closeAdvModal()">✕</button>
    </div>
    <div class="modal-body">
      <p style="font-size:0.82rem;color:var(--silver);margin-bottom:1rem;">
        Month: <strong id="modal_month_label" style="color:var(--white);"></strong><br>
        Base rent: <strong style="color:var(--white);">₱<?= number_format($monthly_rent,2) ?></strong> — fee added at checkout
      </p>
      <div class="pay-tabs" id="payTabsModal">
        <button type="button" class="pay-tab active" data-tab="modal-online">⚡ Pay Online</button>
        <button type="button" class="pay-tab"        data-tab="modal-manual">📋 Manual / Cash</button>
      </div>

      <div class="pay-tab-pane active" id="tab-modal-online">
        <div class="fee-breakdown" id="modal-online-fee-box"></div>
        <form method="POST" action="payments.php" id="pmFormModal">
          <input type="hidden" name="action"     value="paymongo">
          <input type="hidden" name="is_advance" value="1">
          <input type="hidden" name="adv_offset" id="modal_adv_offset" value="">
          <input type="hidden" name="pm_type"    id="pm_type_modal" value="">
          <input type="hidden" name="due_date"   id="modal_due_date" value="">
          <div class="online-methods">
            <button type="button" class="online-card" onclick="selectOnlineModal('gcash')">
              <div class="online-icon gcash-icon">📱</div>
              <div><div class="online-card-name">GCash</div><div class="online-card-fee">+₱<?= number_format(calc_fee($rent_base,'gcash')['fee'],2) ?> fee → Total ₱<?= number_format(calc_fee($rent_base,'gcash')['total'],2) ?></div></div>
              <span class="online-card-badge badge-instant">Instant</span>
              <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
            </button>
            <button type="button" class="online-card" onclick="selectOnlineModal('paymaya')">
              <div class="online-icon maya-icon">💳</div>
              <div><div class="online-card-name">Maya</div><div class="online-card-fee">+₱<?= number_format(calc_fee($rent_base,'paymaya')['fee'],2) ?> fee → Total ₱<?= number_format(calc_fee($rent_base,'paymaya')['total'],2) ?></div></div>
              <span class="online-card-badge badge-instant">Instant</span>
              <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
            </button>
            <div class="pm-divider">or card</div>
            <button type="button" class="online-card" onclick="selectOnlineModal('card')">
              <div class="online-icon card-icon">🏦</div>
              <div><div class="online-card-name">Credit / Debit Card</div><div class="online-card-fee">+₱<?= number_format(calc_fee($rent_base,'card')['fee'],2) ?> fee → Total ₱<?= number_format(calc_fee($rent_base,'card')['total'],2) ?></div></div>
              <span class="online-card-badge badge-secure">Secure</span>
              <span class="online-card-arrow"><i class="fas fa-chevron-right"></i></span>
            </button>
          </div>
        </form>
      </div>

      <div class="pay-tab-pane" id="tab-modal-manual">
        <form method="POST" action="payments.php" enctype="multipart/form-data" id="modalManualForm">
          <input type="hidden" name="action"     value="request">
          <input type="hidden" name="is_advance" value="1">
          <input type="hidden" name="adv_offset" id="modal_adv_offset_m" value="">
          <input type="hidden" name="amount"     value="<?= htmlspecialchars($monthly_rent) ?>">
          <input type="hidden" name="due_date"   id="modal_due_date_m" value="">
          <span class="methods-label">Select Payment Method</span>
          <div class="methods-grid">
            <?php foreach (['Cash'=>['💵','In person'],'GCash'=>['📱','Transfer'],'Maya'=>['💳','Transfer'],'Bank Transfer'=>['🏦','BDO/BPI']] as $mv=>[$mic,$msub]): ?>
            <div>
              <input type="radio" name="payment_method" value="<?= $mv ?>" id="mm-<?= strtolower(str_replace(' ','-',$mv)) ?>" class="modal-method-radio">
              <label for="mm-<?= strtolower(str_replace(' ','-',$mv)) ?>" class="method-card">
                <div class="method-ic"><?= $mic ?></div>
                <div class="method-name"><?= $mv ?></div>
                <div class="method-sub"><?= $msub ?></div>
              </label>
            </div>
            <?php endforeach; ?>
          </div>
          <div id="modal-manual-fee-box" class="fee-breakdown"></div>
          <?php foreach ($method_details as $mkey=>$mval): ?>
          <div class="account-box" id="mbox-<?= htmlspecialchars(str_replace(' ','-',$mkey)) ?>">
            <div class="account-box-header"><span class="account-box-icon"><?= $mval['icon'] ?></span><span class="account-box-name"><?= htmlspecialchars($mval['name']) ?></span></div>
            <div class="account-copy-row"><div class="account-box-number" style="color:<?= $mval['color'] ?>"><?= htmlspecialchars($mval['number']) ?></div><?php if($mval['number']!=='Visit the office'): ?><button type="button" class="copy-btn" onclick="copyText('<?= htmlspecialchars($mval['number']) ?>',this)">Copy</button><?php endif; ?></div>
            <div class="account-box-note"><?= htmlspecialchars($mval['note']) ?></div>
          </div>
          <?php endforeach; ?>
          <div class="field" id="modal-proof-field" style="display:none;"><label>Upload Screenshot / Receipt <span style="color:var(--err);">*</span></label><input type="file" name="proof_image" accept="image/*" class="proof-upload"></div>
          <button type="submit" class="btn-primary" style="background:var(--indigo);margin-top:0.75rem;"><i class="fas fa-forward"></i> Submit Advance Payment</button>
        </form>
      </div>
    </div>
  </div>
</div>

<script>
// ── Fee data from PHP ─────────────────────────────────────────
var FEES     = <?= $fees_json ?>;
var RENT     = <?= floatval($monthly_rent) ?>;
var PH       = function(n){ return '₱'+n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,','); };

// ── Fee breakdown HTML builder ────────────────────────────────
function feeHtml(method) {
    var f   = FEES[method];
    if (!f) return '';
    var isFree = f.fee === 0;
    return '<div class="fee-row"><span class="fee-key">Base Rent</span><span class="fee-val">'+PH(RENT)+'</span></div>'
         + '<div class="fee-row"><span class="fee-key">Convenience Fee <span class="fee-badge'+(isFree?' free':'')+'">'+f.label+'</span></span><span class="fee-val fee-amount">'+(isFree?'Free':'+'+PH(f.fee))+'</span></div>'
         + '<div class="fee-row total-row"><span class="fee-key" style="font-weight:700;color:var(--white);">Total Charged</span><span class="fee-val total-amount">'+PH(f.total)+'</span></div>';
}

function showFeeBox(boxId, method) {
    var box = document.getElementById(boxId);
    if (!box) return;
    box.innerHTML = feeHtml(method);
    box.classList.add('show');
}

// ── Online method selection with fee preview + confirm ────────
function selectOnline(type) {
    showFeeBox('online-fee-box', type);
    var f      = FEES[type];
    var labels = {gcash:'GCash',paymaya:'Maya',card:'Credit / Debit Card'};
    var msg    = 'Payment Summary\n\n'
               + 'Method:          ' + (labels[type]||type) + '\n'
               + 'Base Rent:       ' + PH(RENT) + '\n'
               + 'Convenience Fee: ' + (f.fee>0?'+'+PH(f.fee):'Free') + '\n'
               + '─────────────────────\n'
               + 'Total Charged:   ' + PH(f.total) + '\n\n'
               + 'Continue to PayMongo checkout?';
    if (!confirm(msg)) return;
    document.getElementById('pm_type').value = type;
    document.getElementById('pmForm').submit();
}

function selectOnlineAdv(type) {
    var f      = FEES[type];
    var labels = {gcash:'GCash',paymaya:'Maya',card:'Credit / Debit Card'};
    var msg    = 'Advance Payment Summary\n\n'
               + 'Method:          ' + (labels[type]||type) + '\n'
               + 'Base Rent:       ' + PH(RENT) + '\n'
               + 'Convenience Fee: ' + (f.fee>0?'+'+PH(f.fee):'Free') + '\n'
               + '─────────────────────\n'
               + 'Total Charged:   ' + PH(f.total) + '\n\n'
               + 'Continue to PayMongo checkout?';
    if (!confirm(msg)) return;
    document.getElementById('pm_type_adv').value = type;
    document.getElementById('pmFormAdv').submit();
}

function selectOnlineModal(type) {
    showFeeBox('modal-online-fee-box', type);
    var f      = FEES[type];
    var labels = {gcash:'GCash',paymaya:'Maya',card:'Credit / Debit Card'};
    var month  = document.getElementById('modal_month_label').textContent;
    var msg    = 'Advance Payment — ' + month + '\n\n'
               + 'Method:          ' + (labels[type]||type) + '\n'
               + 'Base Rent:       ' + PH(RENT) + '\n'
               + 'Convenience Fee: ' + (f.fee>0?'+'+PH(f.fee):'Free') + '\n'
               + '─────────────────────\n'
               + 'Total Charged:   ' + PH(f.total) + '\n\n'
               + 'Continue to PayMongo checkout?';
    if (!confirm(msg)) return;
    document.getElementById('pm_type_modal').value = type;
    document.getElementById('pmFormModal').submit();
}

// Old aliases kept for advance form buttons
function payOnline(t){ selectOnline(t); }
function payOnlineAdv(t){ selectOnlineAdv(t); }
function payOnlineModal(t){ selectOnlineModal(t); }

// ── Tabs ─────────────────────────────────────────────────────
function initTabs(containerId) {
    var container = document.getElementById(containerId);
    if (!container) return;
    var tabs  = container.querySelectorAll('.pay-tab');
    var body  = container.parentElement;
    var panes = body.querySelectorAll('.pay-tab-pane');
    tabs.forEach(function(btn){
        btn.addEventListener('click', function(){
            var target = this.getAttribute('data-tab');
            tabs.forEach(function(t){t.classList.remove('active');});
            panes.forEach(function(p){p.classList.remove('active');});
            this.classList.add('active');
            var pane = document.getElementById('tab-'+target);
            if (pane) pane.classList.add('active');
        });
    });
}
initTabs('payTabs');
initTabs('payTabsAdv');
initTabs('payTabsModal');

// ── Manual method radios — show account box + fee breakdown ──
function bindMethodRadios(radioClass, boxPrefix, proofFieldId, feeBoxId) {
    var methodKeys = <?= json_encode(array_map(fn($k)=>str_replace(' ','-',$k),array_keys($method_details))) ?>;
    document.querySelectorAll('.'+radioClass).forEach(function(radio){
        radio.addEventListener('change', function(){
            var val = this.value.replace(/ /g,'-');
            methodKeys.forEach(function(k){
                var b=document.getElementById(boxPrefix+k);
                if(b) b.classList.remove('show');
            });
            var box = document.getElementById(boxPrefix+val);
            if (box) box.classList.add('show');
            var needs = ['GCash','Maya','Bank Transfer'].indexOf(this.value)!==-1;
            var pf = document.getElementById(proofFieldId);
            if (pf) pf.style.display = needs?'block':'none';
            // Show fee breakdown (always ₱0 for manual)
            showFeeBox(feeBoxId, this.value);
        });
    });
}
bindMethodRadios('method-radio',      'box-',  'proof-field',       'manual-fee-box');
bindMethodRadios('adv-method-radio',  'abox-', 'adv-proof-field',   'adv-manual-fee-box');
bindMethodRadios('modal-method-radio','mbox-', 'modal-proof-field', 'modal-manual-fee-box');

// ── Advance month selector ────────────────────────────────────
var selectedAdvOffset  = null;
var selectedAdvDueDate = '';
var selectedAdvLabel   = '';

function selectAdvMonth(offset, dueDate, label) {
    selectedAdvOffset  = offset;
    selectedAdvDueDate = dueDate;
    selectedAdvLabel   = label;
    document.querySelectorAll('#advGrid .adv-month-btn').forEach(function(el){
        el.classList.remove('selected');
        if (parseInt(el.getAttribute('data-offset'))===offset) el.classList.add('selected');
    });
    var info = document.getElementById('advSelectedInfo');
    var btn  = document.getElementById('advPayBtn');
    info.style.display = 'flex';
    document.getElementById('advSelectedText').textContent = 'Selected: '+label+' · '+PH(RENT)+' base rent';
    btn.style.display = 'flex';
    document.getElementById('advPayBtnLabel').textContent = 'Pay Advance for '+label;
}

function openAdvModal() {
    if (!selectedAdvOffset) return;
    document.getElementById('modal_adv_offset').value   = selectedAdvOffset;
    document.getElementById('modal_adv_offset_m').value = selectedAdvOffset;
    document.getElementById('modal_due_date').value     = selectedAdvDueDate;
    document.getElementById('modal_due_date_m').value   = selectedAdvDueDate;
    document.getElementById('modal_month_label').textContent = selectedAdvLabel;
    // Reset fee boxes in modal
    var mfb = document.getElementById('modal-online-fee-box');
    if (mfb) { mfb.innerHTML=''; mfb.classList.remove('show'); }
    document.getElementById('advModal').classList.add('open');
}
function closeAdvModal() { document.getElementById('advModal').classList.remove('open'); }
document.getElementById('advModal').addEventListener('click',function(e){ if(e.target===this) closeAdvModal(); });

// ── Proof preview ─────────────────────────────────────────────
function previewProof(input){
    var preview=document.getElementById('proof_preview'),img=document.getElementById('proof_img_prev');
    if(input.files&&input.files[0]){
        var r=new FileReader();r.onload=function(e){img.src=e.target.result;preview.style.display='block';};r.readAsDataURL(input.files[0]);
    } else { preview.style.display='none'; }
}

// ── Copy ─────────────────────────────────────────────────────
function copyText(text,btn){
    var original=btn.textContent;
    if(navigator.clipboard&&navigator.clipboard.writeText){
        navigator.clipboard.writeText(text).then(function(){ btn.textContent='Copied!';btn.style.color='#10b981';setTimeout(function(){btn.textContent=original;btn.style.color='';},2000); });
    } else {
        var ta=document.createElement('textarea');ta.value=text;ta.style.cssText='position:fixed;opacity:0';
        document.body.appendChild(ta);ta.focus();ta.select();document.execCommand('copy');document.body.removeChild(ta);
        btn.textContent='Copied!';setTimeout(function(){btn.textContent=original;},2000);
    }
}
</script>
</body>
</html>