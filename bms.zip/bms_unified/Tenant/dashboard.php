<?php
session_start();
if(isset($_SESSION["tenant_time"]) && (time()-$_SESSION["tenant_time"])>7200){session_destroy();header("Location: index.php");exit();}
$_SESSION["tenant_time"]=time();

if (!isset($_SESSION['tenant_id'])) {
    header("Location: index.php");
    exit();
}

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
$pdo = getDB();

$tenant_id   = (int)$_SESSION['tenant_id'];
$tenant_name = $_SESSION['tenant_name'];
$tenant_room = $_SESSION['tenant_room'];

$initials = '';
foreach (explode(' ', $tenant_name) as $p) {
    if ($p !== '') $initials .= strtoupper($p[0]);
}

// ════════════════════════════════════════════════════════════
// CURRENT PAYMENT — same priority ladder as payments.php:
//   paid=0  →  pending=1  →  overdue=2  →  rejected=3
// This ensures a rejected row NEVER overrides a paid/pending one,
// and a paid row always wins when multiple rows exist for the month.
// ════════════════════════════════════════════════════════════
$current_payment = db_fetch_one($pdo, "
    SELECT * FROM payments
    WHERE tenant_id = ?
    ORDER BY
        CASE status
            WHEN 'paid'     THEN 0
            WHEN 'pending'  THEN 1
            WHEN 'overdue'  THEN 2
            WHEN 'rejected' THEN 3
            ELSE 4
        END ASC,
        created_at DESC
    LIMIT 1
", [$tenant_id]);

// ── Derive display status from the winning row ────────────────
$pay_status = 'no_record';
$pay_label  = 'No Record';
if ($current_payment) {
    $db_status = $current_payment['status'] ?? '';
    if ($db_status === 'paid' || $current_payment['payment_date'] || $current_payment['paid_at']) {
        $pay_status = 'paid';     $pay_label = 'Paid';
    } elseif ($db_status === 'overdue') {
        $pay_status = 'overdue';  $pay_label = 'Overdue';
    } elseif ($db_status === 'rejected') {
        $pay_status = 'rejected'; $pay_label = 'Rejected';
    } else {
        // pending — but check if the due date has already passed
        $due = new DateTime($current_payment['due_date']);
        if ($due < new DateTime()) {
            $pay_status = 'overdue'; $pay_label = 'Overdue';
        } else {
            $pay_status = 'pending'; $pay_label = 'Pending';
        }
    }
}

// ── Recent paid payment history (left panel) ─────────────────
$payment_history = db_fetch_all($pdo, "
    SELECT * FROM payments
    WHERE tenant_id = ?
      AND (status = 'paid' OR payment_date IS NOT NULL OR paid_at IS NOT NULL)
    ORDER BY COALESCE(paid_at, payment_date, created_at) DESC
    LIMIT 3
", [$tenant_id]);

// ── Aggregate stats ───────────────────────────────────────────
$pay_agg = db_fetch_one($pdo, "
    SELECT COUNT(*) AS c, COALESCE(SUM(amount), 0) AS s
    FROM payments
    WHERE tenant_id = ?
      AND (status = 'paid' OR payment_date IS NOT NULL OR paid_at IS NOT NULL)
", [$tenant_id]);
$paid_count = (int)($pay_agg['c'] ?? 0);
$total_paid = (float)($pay_agg['s'] ?? 0);

// ── Profile ───────────────────────────────────────────────────
$profile = db_fetch_one($pdo, "SELECT * FROM tenants WHERE id = ? LIMIT 1", [$tenant_id]);

$today = date('l, F j, Y');

// ── Fetch notifications ───────────────────────────────────────
$notifs       = [];
$unread_count = 0;
try {
    $notifs = db_fetch_all($pdo, "
        SELECT * FROM tenant_notifications
        WHERE tenant_id = ?
        ORDER BY created_at DESC
        LIMIT 20
    ", [$tenant_id]);
    $unread_count = count(array_filter($notifs, fn($n) => !$n['is_read']));

    if (isset($_GET['notifs'])) {
        $pdo->prepare("UPDATE tenant_notifications SET is_read=1 WHERE tenant_id=?")
            ->execute([$tenant_id]);
        header("Location: dashboard.php"); exit;
    }
} catch (PDOException $e) {
    // tenant_notifications table doesn't exist yet — skip
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — Monticello TMS</title>
<meta http-equiv="refresh" content="30">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
  --bg:        #080d1a;
  --surface:   #0d1424;
  --surface-2: #111827;
  --surface-3: #1a2235;
  --accent:    #2563eb;
  --accent-lt: #3b82f6;
  --accent-gl: rgba(37,99,235,0.15);
  --ok:        #10b981;
  --warn:      #f59e0b;
  --err:       #ef4444;
  --silver:    #94a3b8;
  --light:     #cbd5e1;
  --white:     #f1f5f9;
  --border:    rgba(255,255,255,0.07);
  --border-2:  rgba(255,255,255,0.04);
}

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

body {
  font-family: 'DM Sans', sans-serif;
  background: var(--bg);
  color: var(--light);
  display: flex;
  min-height: 100vh;
}

/* ── SIDEBAR ─────────────────────────────────── */
.sidebar {
  width: 240px;
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  position: fixed;
  height: 100vh;
  z-index: 100;
  flex-shrink: 0;
}
.sb-logo {
  padding: 1.6rem 1.4rem;
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  gap: 0.7rem;
}
.sb-mark {
  width: 32px; height: 32px;
  background: var(--accent);
  border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  font-size: 0.9rem; flex-shrink: 0;
}
.sb-name {
  font-family: 'Syne', sans-serif;
  font-size: 0.9rem; font-weight: 700;
  color: var(--white); line-height: 1.2;
}
.sb-name small {
  display: block;
  font-size: 0.58rem;
  font-family: 'DM Sans', sans-serif;
  font-weight: 400;
  color: var(--silver);
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
.sb-nav { flex: 1; padding: 1rem 0.75rem; overflow-y: auto; }
.nav-section-label {
  font-size: 0.58rem; font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.14em;
  color: rgba(148,163,184,0.45);
  padding: 0.6rem 0.65rem 0.4rem;
  margin-top: 0.5rem;
}
.nav-link {
  display: flex; align-items: center; gap: 0.7rem;
  padding: 0.62rem 0.75rem;
  border-radius: 5px;
  font-size: 0.82rem; font-weight: 500;
  color: var(--silver);
  text-decoration: none;
  transition: all 0.18s;
  margin-bottom: 2px;
}
.nav-link:hover { background: rgba(255,255,255,0.05); color: var(--white); }
.nav-link.active {
  background: var(--accent-gl);
  color: var(--accent-lt);
  border-left: 2px solid var(--accent);
  padding-left: calc(0.75rem - 2px);
}
.nav-link i { width: 16px; font-size: 0.8rem; opacity: 0.8; }
.nav-link.active i { opacity: 1; }
.sb-user { padding: 1rem 1.1rem; border-top: 1px solid var(--border); }
.sb-user-row { display: flex; align-items: center; gap: 0.7rem; margin-bottom: 0.75rem; }
.sb-avatar {
  width: 36px; height: 36px; border-radius: 8px;
  background: linear-gradient(135deg, var(--accent), #1d4ed8);
  display: flex; align-items: center; justify-content: center;
  font-family: 'Syne', sans-serif;
  font-size: 0.8rem; font-weight: 700;
  color: #fff; flex-shrink: 0;
}
.sb-user-name { font-size: 0.82rem; font-weight: 600; color: var(--white); line-height: 1.2; }
.sb-user-room { font-size: 0.68rem; color: var(--silver); margin-top: 1px; }
.logout-btn {
  width: 100%; padding: 0.55rem;
  background: rgba(239,68,68,0.08);
  border: 1px solid rgba(239,68,68,0.18);
  border-radius: 5px;
  font-family: 'DM Sans', sans-serif;
  font-size: 0.76rem; font-weight: 600;
  color: #fca5a5; cursor: pointer;
  transition: all 0.2s;
  display: flex; align-items: center; justify-content: center; gap: 0.5rem;
}
.logout-btn:hover { background: rgba(239,68,68,0.14); border-color: rgba(239,68,68,0.3); }

/* ── MAIN ─────────────────────────────────────── */
.main { margin-left: 240px; flex: 1; display: flex; flex-direction: column; min-height: 100vh; }
.topbar {
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  padding: 0 2rem; height: 58px;
  display: flex; align-items: center; justify-content: space-between;
  position: sticky; top: 0; z-index: 50;
}
.topbar-left h1 { font-family: 'Syne', sans-serif; font-size: 1rem; font-weight: 700; color: var(--white); }
.topbar-left p  { font-size: 0.72rem; color: var(--silver); margin-top: 1px; }
.topbar-right   { display: flex; align-items: center; gap: 0.75rem; }
.topbar-date {
  font-size: 0.72rem; color: var(--silver);
  padding: 0.3rem 0.7rem;
  background: var(--border-2);
  border: 1px solid var(--border);
  border-radius: 4px;
}
.content { padding: 1.75rem 2rem; flex: 1; }

/* ── STAT CARDS ──────────────────────────────── */
.status-bar {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 1.1rem 1.25rem;
  position: relative; overflow: hidden;
  transition: border-color 0.2s;
}
.stat-card:hover { border-color: rgba(255,255,255,0.12); }
.stat-card::before {
  content: ''; position: absolute;
  top: 0; left: 0; right: 0; height: 2px;
  background: var(--accent);
}
.stat-card.ok::before   { background: var(--ok); }
.stat-card.warn::before { background: var(--warn); }
.stat-card.err::before  { background: var(--err); }
.stat-card.muted::before { background: var(--silver); }
.stat-icon {
  width: 34px; height: 34px; border-radius: 7px;
  background: rgba(255,255,255,0.05);
  display: flex; align-items: center; justify-content: center;
  font-size: 0.85rem; color: var(--silver);
  margin-bottom: 0.85rem;
}
.stat-card.ok   .stat-icon { background: rgba(16,185,129,0.12);  color: var(--ok); }
.stat-card.warn .stat-icon { background: rgba(245,158,11,0.12);   color: var(--warn); }
.stat-card.err  .stat-icon { background: rgba(239,68,68,0.12);    color: var(--err); }
.stat-card.muted .stat-icon { background: rgba(148,163,184,0.12); color: var(--silver); }
.stat-val { font-family: 'Syne', sans-serif; font-size: 1.4rem; font-weight: 700; color: var(--white); line-height: 1; margin-bottom: 4px; }
.stat-lbl { font-size: 0.7rem; color: var(--silver); text-transform: uppercase; letter-spacing: 0.08em; }

/* ── GRID LAYOUTS ────────────────────────────── */
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.25rem; margin-bottom: 1.25rem; }
.grid-3 { display: grid; grid-template-columns: 2fr 1fr; gap: 1.25rem; }

/* ── PANELS ──────────────────────────────────── */
.panel { background: var(--surface); border: 1px solid var(--border); border-radius: 8px; overflow: hidden; }
.panel-head {
  padding: 1rem 1.25rem; border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between;
}
.panel-title {
  font-family: 'Syne', sans-serif; font-size: 0.82rem; font-weight: 700;
  color: var(--white); letter-spacing: 0.02em;
  display: flex; align-items: center; gap: 0.55rem;
}
.panel-title i { font-size: 0.75rem; color: var(--accent-lt); }
.panel-body { padding: 1.25rem; }

/* ── DATA ROWS ───────────────────────────────── */
.data-row {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0.65rem 0;
  border-bottom: 1px solid var(--border-2);
}
.data-row:last-child  { border-bottom: none; padding-bottom: 0; }
.data-row:first-child { padding-top: 0; }
.data-key { font-size: 0.72rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.08em; color: var(--silver); }
.data-val { font-size: 0.85rem; font-weight: 500; color: var(--white); text-align: right; max-width: 55%; word-break: break-word; }

/* ── PAYMENT STATUS PANEL ────────────────────── */
.pay-amount {
  font-family: 'Syne', sans-serif;
  font-size: 2.2rem; font-weight: 800;
  color: var(--white); line-height: 1;
  margin-bottom: 0.4rem;
}

/* Status chip — all 4 states */
.status-chip {
  display: inline-flex; align-items: center; gap: 0.35rem;
  padding: 0.3rem 0.75rem; border-radius: 3px;
  font-size: 0.68rem; font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.1em;
  margin-bottom: 1rem;
}
.status-chip::before {
  content: ''; width: 5px; height: 5px;
  border-radius: 50%; background: currentColor;
}
.chip-paid     { background: rgba(16,185,129,0.12); color: var(--ok);      border: 1px solid rgba(16,185,129,0.25); }
.chip-pending  { background: rgba(245,158,11,0.12);  color: var(--warn);   border: 1px solid rgba(245,158,11,0.25); }
.chip-overdue  { background: rgba(239,68,68,0.12);   color: var(--err);    border: 1px solid rgba(239,68,68,0.25); }
.chip-rejected { background: rgba(148,163,184,0.10); color: var(--silver); border: 1px solid rgba(148,163,184,0.22); }

.pay-meta { font-size: 0.78rem; color: var(--silver); margin-bottom: 0.35rem; }

/* Rejected notice box */
.rejected-notice {
  display: flex; align-items: flex-start; gap: 0.6rem;
  padding: 0.7rem 0.9rem;
  background: rgba(239,68,68,0.07);
  border: 1px solid rgba(239,68,68,0.2);
  border-radius: 5px;
  margin: 0.75rem 0;
  font-size: 0.78rem; color: #fca5a5; line-height: 1.5;
}

.pay-btn {
  display: flex; align-items: center; justify-content: center; gap: 0.5rem;
  width: 100%; padding: 0.75rem;
  background: var(--accent); color: #fff;
  border: none; border-radius: 5px;
  font-family: 'Syne', sans-serif; font-size: 0.82rem; font-weight: 600;
  letter-spacing: 0.04em; cursor: pointer;
  text-decoration: none; margin-top: 1rem;
  transition: all 0.2s;
}
.pay-btn:hover { background: #1d4ed8; box-shadow: 0 4px 14px var(--accent-gl); }
.pay-btn.resubmit { background: rgba(239,68,68,0.15); border: 1px solid rgba(239,68,68,0.3); color: #fca5a5; }
.pay-btn.resubmit:hover { background: rgba(239,68,68,0.25); }

.next-pay {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0.75rem;
  background: var(--border-2); border: 1px solid var(--border);
  border-radius: 5px; margin-top: 0.75rem;
}
.next-pay-label { font-size: 0.7rem; color: var(--silver); text-transform: uppercase; letter-spacing: 0.08em; }
.next-pay-val   { font-size: 0.82rem; font-weight: 600; color: var(--white); }

/* ── HISTORY LIST ────────────────────────────── */
.hist-item {
  display: flex; align-items: center; gap: 0.85rem;
  padding: 0.7rem 0;
  border-bottom: 1px solid var(--border-2);
}
.hist-item:last-child  { border-bottom: none; padding-bottom: 0; }
.hist-item:first-child { padding-top: 0; }
.hist-icon {
  width: 34px; height: 34px; border-radius: 7px;
  background: rgba(16,185,129,0.1);
  display: flex; align-items: center; justify-content: center;
  font-size: 0.75rem; color: var(--ok); flex-shrink: 0;
}
.hist-month  { font-size: 0.82rem; font-weight: 600; color: var(--white); }
.hist-method { font-size: 0.7rem; color: var(--silver); margin-top: 2px; }
.hist-amount { font-size: 0.9rem; font-weight: 700; color: var(--ok); margin-left: auto; }

/* ── QUICK ACTIONS ───────────────────────────── */
.actions-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 0.65rem; }
.action-btn {
  display: flex; align-items: center; gap: 0.65rem;
  padding: 0.75rem 0.9rem;
  background: var(--border-2); border: 1px solid var(--border);
  border-radius: 5px; text-decoration: none;
  transition: all 0.18s; cursor: pointer;
}
.action-btn:hover { background: var(--accent-gl); border-color: rgba(37,99,235,0.25); }
.action-ic {
  width: 30px; height: 30px; border-radius: 6px;
  background: rgba(255,255,255,0.06);
  display: flex; align-items: center; justify-content: center;
  font-size: 0.75rem; color: var(--silver); flex-shrink: 0;
}
.action-btn:hover .action-ic { background: rgba(37,99,235,0.15); color: var(--accent-lt); }
.action-label { font-size: 0.78rem; font-weight: 600; color: var(--light); }
.action-sub   { font-size: 0.65rem; color: var(--silver); margin-top: 1px; }

.empty { text-align: center; padding: 2rem 1rem; color: var(--silver); font-size: 0.82rem; }
.empty i { font-size: 1.5rem; opacity: 0.25; display: block; margin-bottom: 0.6rem; }

@media (max-width: 1100px) { .status-bar { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 900px)  { .grid-2, .grid-3 { grid-template-columns: 1fr; } }
@media (max-width: 720px)  {
  .sidebar { width: 100%; height: auto; position: relative; }
  .main { margin-left: 0; }
  .status-bar { grid-template-columns: 1fr 1fr; }
}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <div class="sb-mark">⬡</div>
    <div class="sb-name">Monticello <small>Tenant Portal</small></div>
  </div>
  <nav class="sb-nav">
    <div class="nav-section-label">Main</div>
    <a href="dashboard.php" class="nav-link active"><i class="fas fa-th-large"></i> Dashboard</a>
    <a href="payments.php"  class="nav-link"><i class="fas fa-credit-card"></i> Payments</a>
    <div class="nav-section-label">Account</div>
    <a href="invoices.php"       class="nav-link"><i class="fas fa-file-invoice"></i> Invoices</a>
    <a href="maintenance.php"    class="nav-link"><i class="fas fa-tools"></i> Maintenance</a>
    <a href="communications.php" class="nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="profile.php"        class="nav-link"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sb-user">
    <div class="sb-user-row">
      <div class="sb-avatar"><?= htmlspecialchars($initials) ?></div>
      <div>
        <div class="sb-user-name"><?= htmlspecialchars($tenant_name) ?></div>
        <div class="sb-user-room">Room <?= htmlspecialchars($tenant_room) ?></div>
      </div>
    </div>
    <form method="POST" action="logout.php" style="margin:0;">
      <button type="submit" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Sign Out</button>
    </form>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <h1>Dashboard</h1>
      <p>Overview of your tenancy</p>
    </div>
    <div class="topbar-right">
      <div class="topbar-date"><?= $today ?></div>
      <a href="#" class="notif-bell" title="Notifications"
         style="position:relative;width:36px;height:36px;background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:.9rem;text-decoration:none;color:var(--silver);transition:all .2s;"
         onclick="event.preventDefault(); toggleNotifPanel();">
        🔔
        <?php if ($unread_count > 0): ?>
        <span style="position:absolute;top:-4px;right:-4px;width:18px;height:18px;background:var(--err);border-radius:50%;font-size:.58rem;font-weight:700;color:#fff;display:flex;align-items:center;justify-content:center;border:2px solid var(--bg);">
          <?= $unread_count ?>
        </span>
        <?php endif; ?>
      </a>
    </div>
  </div>

  <div class="content">

    <!-- ── STAT CARDS ── -->
    <div class="status-bar">
      <div class="stat-card">
        <div class="stat-icon"><i class="fas fa-door-open"></i></div>
        <div class="stat-val"><?= htmlspecialchars($tenant_room) ?></div>
        <div class="stat-lbl">Room Assigned</div>
      </div>

      <div class="stat-card ok">
        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
        <div class="stat-val"><?= $paid_count ?></div>
        <div class="stat-lbl">Payments Made</div>
      </div>

      <?php
        // Stat card accent color per status
        $statClass = match($pay_status) {
            'paid'      => 'ok',
            'pending'   => 'warn',
            'overdue'   => 'err',
            'rejected'  => 'muted',
            default     => '',
        };
        $statIcon = match($pay_status) {
            'paid'      => 'fas fa-check-circle',
            'pending'   => 'fas fa-hourglass-half',
            'overdue'   => 'fas fa-exclamation-circle',
            'rejected'  => 'fas fa-times-circle',
            default     => 'fas fa-receipt',
        };
      ?>
      <div class="stat-card <?= $statClass ?>">
        <div class="stat-icon"><i class="<?= $statIcon ?>"></i></div>
        <div class="stat-val"><?= $pay_label ?></div>
        <div class="stat-lbl">Payment Status</div>
      </div>

      <div class="stat-card">
        <div class="stat-icon"><i class="fas fa-peso-sign"></i></div>
        <div class="stat-val">₱<?= number_format($total_paid, 0) ?></div>
        <div class="stat-lbl">Total Paid</div>
      </div>
    </div>

    <!-- ── ROW 1: Account Info + Payment Status ── -->
    <div class="grid-2">

      <!-- Account Info -->
      <div class="panel">
        <div class="panel-head">
          <div class="panel-title"><i class="fas fa-id-card"></i> Account Information</div>
        </div>
        <div class="panel-body">
          <div class="data-row"><span class="data-key">Full Name</span><span class="data-val"><?= htmlspecialchars($profile['full_name'] ?? '—') ?></span></div>
          <div class="data-row"><span class="data-key">Email</span><span class="data-val"><?= htmlspecialchars($profile['email'] ?? '—') ?></span></div>
          <div class="data-row"><span class="data-key">Phone</span><span class="data-val"><?= htmlspecialchars($profile['phone'] ?? '—') ?></span></div>
          <div class="data-row"><span class="data-key">Room No.</span><span class="data-val"><?= htmlspecialchars($profile['room_number'] ?? '—') ?></span></div>
          <div class="data-row"><span class="data-key">Address</span><span class="data-val"><?= htmlspecialchars($profile['address'] ?? '—') ?></span></div>
          <div class="data-row"><span class="data-key">Emergency</span><span class="data-val"><?= htmlspecialchars($profile['emergency_contact'] ?? '—') ?></span></div>
          <div class="data-row"><span class="data-key">Emerg. Phone</span><span class="data-val"><?= htmlspecialchars($profile['emergency_phone'] ?? '—') ?></span></div>
          <div class="data-row"><span class="data-key">Member Since</span><span class="data-val"><?= date('M j, Y', strtotime($profile['created_at'])) ?></span></div>
        </div>
      </div>

      <!-- Current Payment Status -->
      <div class="panel">
        <div class="panel-head">
          <div class="panel-title"><i class="fas fa-wallet"></i> Current Payment</div>
        </div>
        <div class="panel-body">
          <?php if ($current_payment): ?>

            <span class="status-chip chip-<?= $pay_status ?>">
              <?= $pay_label ?>
            </span>

            <div class="pay-amount">₱<?= number_format($current_payment['amount'], 2) ?></div>

            <?php if ($pay_status === 'paid'): ?>
              <div class="pay-meta">Paid on: <?= date('F j, Y', strtotime($current_payment['paid_at'] ?: $current_payment['payment_date'])) ?></div>
              <div class="pay-meta">Via: <?= htmlspecialchars($current_payment['payment_method'] ?? '—') ?></div>

            <?php elseif ($pay_status === 'pending'): ?>
              <div class="pay-meta">Due: <?= date('F j, Y', strtotime($current_payment['due_date'])) ?></div>
              <div class="pay-meta" style="color:var(--warn);">⏳ Awaiting admin confirmation.</div>
              <a href="payments.php" class="pay-btn"><i class="fas fa-eye"></i> View Submission</a>

            <?php elseif ($pay_status === 'overdue'): ?>
              <div class="pay-meta" style="color:var(--err);">Due: <?= date('F j, Y', strtotime($current_payment['due_date'])) ?></div>
              <a href="payments.php" class="pay-btn"><i class="fas fa-arrow-right"></i> Pay Now</a>

            <?php elseif ($pay_status === 'rejected'): ?>
              <?php if (!empty($current_payment['admin_notes'])): ?>
              <div class="rejected-notice">
                <i class="fas fa-times-circle" style="margin-top:2px;flex-shrink:0;"></i>
                <span><strong>Rejected.</strong> Reason: <?= htmlspecialchars($current_payment['admin_notes']) ?></span>
              </div>
              <?php else: ?>
              <div class="rejected-notice">
                <i class="fas fa-times-circle" style="margin-top:2px;flex-shrink:0;"></i>
                <span>Your payment was rejected. Please resubmit.</span>
              </div>
              <?php endif; ?>
              <a href="payments.php" class="pay-btn resubmit"><i class="fas fa-redo"></i> Resubmit Payment</a>

            <?php endif; ?>

            <div class="next-pay">
              <span class="next-pay-label">Next Due</span>
              <span class="next-pay-val"><?= date('M j, Y', strtotime('+1 month', strtotime($current_payment['due_date']))) ?></span>
            </div>

          <?php else: ?>
            <div class="empty"><i class="fas fa-inbox"></i>No payment records yet.</div>
            <a href="payments.php" class="pay-btn" style="margin-top:0.5rem;"><i class="fas fa-arrow-right"></i> Submit First Payment</a>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- ── ROW 2: Payment History + Quick Actions ── -->
    <div class="grid-3">

      <div class="panel">
        <div class="panel-head">
          <div class="panel-title"><i class="fas fa-history"></i> Recent Payments</div>
          <a href="payments.php" style="font-size:0.72rem;color:var(--accent-lt);text-decoration:none;">View All →</a>
        </div>
        <div class="panel-body">
          <?php if (count($payment_history) > 0): ?>
            <?php foreach ($payment_history as $p): ?>
            <div class="hist-item">
              <div class="hist-icon"><i class="fas fa-check"></i></div>
              <div>
                <div class="hist-month"><?= date('F Y', strtotime($p['due_date'])) ?></div>
                <div class="hist-method"><?= htmlspecialchars($p['payment_method'] ?? '—') ?> · <?= date('M j', strtotime($p['paid_at'] ?: $p['payment_date'] ?: $p['created_at'])) ?></div>
              </div>
              <div class="hist-amount">₱<?= number_format($p['amount'], 2) ?></div>
            </div>
            <?php endforeach; ?>
          <?php else: ?>
          <div class="empty"><i class="fas fa-receipt"></i>No payment history yet.</div>
          <?php endif; ?>
        </div>
      </div>

      <div class="panel">
        <div class="panel-head">
          <div class="panel-title"><i class="fas fa-bolt"></i> Quick Actions</div>
        </div>
        <div class="panel-body">
          <div class="actions-grid">
            <a href="payments.php" class="action-btn">
              <div class="action-ic"><i class="fas fa-credit-card"></i></div>
              <div><div class="action-label">Pay Rent</div><div class="action-sub">Make payment</div></div>
            </a>
            <a href="payments.php#history" class="action-btn">
              <div class="action-ic"><i class="fas fa-history"></i></div>
              <div><div class="action-label">History</div><div class="action-sub">View records</div></div>
            </a>
            <a href="maintenance.php" class="action-btn">
              <div class="action-ic"><i class="fas fa-tools"></i></div>
              <div><div class="action-label">Request</div><div class="action-sub">Maintenance</div></div>
            </a>
            <a href="communications.php" class="action-btn">
              <div class="action-ic"><i class="fas fa-bullhorn"></i></div>
              <div><div class="action-label">Announcements</div><div class="action-sub">View updates</div></div>
            </a>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

<!-- ── NOTIFICATION PANEL ── -->
<div id="notifPanel" style="display:none;position:fixed;top:58px;right:16px;width:360px;max-height:520px;background:var(--surface);border:1px solid var(--border);border-radius:10px;box-shadow:0 16px 40px rgba(0,0,0,.5);z-index:9999;overflow:hidden;flex-direction:column;">
  <div style="display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid var(--border);">
    <div style="font-family:'Syne',sans-serif;font-size:.88rem;font-weight:700;color:var(--white);">
      🔔 Notifications
      <?php if ($unread_count > 0): ?>
      <span style="margin-left:6px;padding:1px 7px;background:var(--err);border-radius:99px;font-size:.62rem;font-weight:700;color:#fff;"><?= $unread_count ?> new</span>
      <?php endif; ?>
    </div>
    <?php if (!empty($notifs)): ?>
    <a href="?notifs=1" style="font-size:.72rem;color:var(--accent-lt);text-decoration:none;">Mark all read</a>
    <?php endif; ?>
  </div>
  <div style="overflow-y:auto;max-height:440px;">
    <?php if (empty($notifs)): ?>
    <div style="text-align:center;padding:2.5rem 1rem;color:var(--silver);font-size:.82rem;">
      <div style="font-size:1.6rem;opacity:.2;margin-bottom:.5rem;">🔔</div>No notifications yet.
    </div>
    <?php else: foreach ($notifs as $n):
      $isUnread = !$n['is_read'];
      $typeColors = [
        'approval'  => ['bg'=>'rgba(16,185,129,0.08)', 'border'=>'rgba(16,185,129,0.18)', 'dot'=>'#10b981'],
        'rejection' => ['bg'=>'rgba(239,68,68,0.07)',  'border'=>'rgba(239,68,68,0.18)',  'dot'=>'#ef4444'],
        'general'   => ['bg'=>'rgba(37,99,235,0.06)',  'border'=>'rgba(37,99,235,0.15)',  'dot'=>'#3b82f6'],
      ];
      $tc = $typeColors[$n['type']] ?? $typeColors['general'];
    ?>
    <div style="padding:12px 16px;border-bottom:1px solid var(--border-2);background:<?= $isUnread ? $tc['bg'] : 'transparent' ?>;border-left:3px solid <?= $isUnread ? $tc['dot'] : 'transparent' ?>;">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:5px;">
        <div style="font-size:.8rem;font-weight:<?= $isUnread ? '700' : '500' ?>;color:var(--white);line-height:1.3;">
          <?= htmlspecialchars($n['title'], ENT_QUOTES, 'UTF-8') ?>
        </div>
        <?php if ($isUnread): ?>
        <span style="width:7px;height:7px;border-radius:50%;background:<?= $tc['dot'] ?>;flex-shrink:0;margin-top:4px;"></span>
        <?php endif; ?>
      </div>
      <div style="font-size:.75rem;color:var(--silver);line-height:1.6;white-space:pre-wrap;max-height:120px;overflow:hidden;cursor:pointer;"
           onclick="toggleNotifBody(this)">
        <?= htmlspecialchars($n['message'], ENT_QUOTES, 'UTF-8') ?>
      </div>
      <div style="font-size:.65rem;color:rgba(148,163,184,.45);margin-top:5px;">
        <?= date('M j, Y · g:i A', strtotime($n['created_at'])) ?>
      </div>
    </div>
    <?php endforeach; endif; ?>
  </div>
</div>
<div id="notifOverlay" onclick="closeNotifPanel()" style="display:none;position:fixed;inset:0;z-index:9998;"></div>

<script>
function toggleNotifPanel(){
  var p=document.getElementById('notifPanel'), o=document.getElementById('notifOverlay');
  var open = p.style.display === 'flex';
  p.style.display = open ? 'none' : 'flex';
  p.style.flexDirection = 'column';
  o.style.display = open ? 'none' : 'block';
}
function closeNotifPanel(){
  document.getElementById('notifPanel').style.display='none';
  document.getElementById('notifOverlay').style.display='none';
}
function toggleNotifBody(el){
  el.style.maxHeight = el.style.maxHeight==='none' ? '120px' : 'none';
}
</script>
</body>
</html>