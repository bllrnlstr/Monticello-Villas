<?php
/**
 * Tenant/inquiry.php — Public Room Inquiry Form
 * Now includes a live "Available Rooms" section so tenants can
 * browse vacancies BEFORE submitting their inquiry.
 *
 * Flow: Browse Rooms → Inquire → Register → Admin approves → Login
 */
session_start();

if (isset($_SESSION['tenant_id'])) {
    header("Location: dashboard.php"); exit();
}

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';

$pdo     = getDB();
$error   = '';
$success = false;

// ── Fetch available rooms (vacant only) ─────────────────────────────────────
$availableRooms = [];
try {
    $stmt = $pdo->query("
        SELECT id, room_number, room_type, floor, capacity, monthly_rate,
               amenities, description, status
        FROM rooms
        WHERE status = 'vacant'
        ORDER BY monthly_rate ASC, room_number ASC
    ");
    $availableRooms = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // silently fail — rooms section just won't show
}

// ── Pre-selected room from URL (when clicking "Inquire about this room") ────
$preRoom     = trim($_GET['room']      ?? '');
$preRoomType = trim($_GET['room_type'] ?? '');

// ── Handle POST (inquiry submission) ────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name      = trim($_POST['name']      ?? '');
    $email     = strtolower(trim($_POST['email']   ?? ''));
    $contact   = trim($_POST['contact']   ?? '');
    $room_type = trim($_POST['room_type'] ?? '') ?: null;
    $move_in   = trim($_POST['move_in']   ?? '') ?: null;
    $message   = trim($_POST['message']   ?? '');
    $fb_link   = trim($_POST['fb_link']   ?? '') ?: null;
    $room_ref  = trim($_POST['room_ref']  ?? '') ?: null; // specific room number

    if (!$name || !$email || !$contact || !$message) {
        $error = 'Name, email, contact number, and message are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($message) < 10) {
        $error = 'Please write a more detailed message (at least 10 characters).';
    } else {
        $notesParts = [];
        if ($room_ref) $notesParts[] = "Interested in Room: {$room_ref}";
        if ($move_in)  $notesParts[] = "Preferred move-in: {$move_in}";
        if ($fb_link)  $notesParts[] = "Facebook: {$fb_link}";
        $notes = $notesParts ? implode(' | ', $notesParts) : null;

        try {
            $pdo->exec("ALTER TABLE inquiries ADD COLUMN fb_link VARCHAR(500) NULL AFTER notes");
        } catch (PDOException $e) { /* already exists */ }

        db_execute($pdo, SQL_INQUIRY_INSERT, [
            $name, $email, $contact, $room_type, $message, 'new', $notes
        ]);

        if ($fb_link) {
            $lastId = (int)$pdo->lastInsertId();
            $pdo->prepare("UPDATE inquiries SET fb_link=? WHERE id=?")->execute([$fb_link, $lastId]);
        }

        $statusUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://'
            . $_SERVER['HTTP_HOST']
            . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/inquiry.php';
        try {
            require_once __DIR__ . '/../shared/notifications.php';
            notify_inquiry_received($email, $name, $statusUrl);
        } catch (Throwable $e) {
            error_log('[Inquiry notify] ' . $e->getMessage());
        }

        $success = true;
    }
}

// ── Inquiry status check ────────────────────────────────────────────────────
$statusResult = null;
$statusError  = '';
if (isset($_GET['check_email'])) {
    $checkEmail = strtolower(trim($_GET['check_email']));
    if (!filter_var($checkEmail, FILTER_VALIDATE_EMAIL)) {
        $statusError = 'Please enter a valid email address.';
    } else {
        $sq = $pdo->prepare("
            SELECT id, name, room_type, status, notes, created_at
            FROM inquiries WHERE email = ?
            ORDER BY created_at DESC LIMIT 1
        ");
        $sq->execute([$checkEmail]);
        $statusResult = $sq->fetch(PDO::FETCH_ASSOC);
        if (!$statusResult) $statusError = 'No inquiry found for that email address.';
    }
}

// ── Room type icon map ───────────────────────────────────────────────────────
function roomIcon(string $type): string {
    $map = [
        'single'    => '🛏',
        'double'    => '🛏',
        'studio'    => '🏠',
        'dormitory' => '🏢',
        'suite'     => '✨',
        'family'    => '👨‍👩‍👧',
        'triple'    => '🛏',
    ];
    return $map[strtolower($type)] ?? '🚪';
}

// ── Build amenity tags from comma-separated string ──────────────────────────
function amenityTags(string $amenities): array {
    if (!$amenities) return [];
    return array_filter(array_map('trim', explode(',', $amenities)));
}

// ── Amenity icon map ─────────────────────────────────────────────────────────
function amenityIcon(string $tag): string {
    $tag = strtolower($tag);
    if (str_contains($tag, 'ac') || str_contains($tag, 'aircon'))  return '❄️';
    if (str_contains($tag, 'wifi') || str_contains($tag, 'wi-fi')) return '📶';
    if (str_contains($tag, 'bath') || str_contains($tag, 'cr'))    return '🚿';
    if (str_contains($tag, 'kitchen') || str_contains($tag, 'ref')) return '🍳';
    if (str_contains($tag, 'cabinet') || str_contains($tag, 'closet')) return '🗄️';
    if (str_contains($tag, 'desk') || str_contains($tag, 'table')) return '🪑';
    if (str_contains($tag, 'tv') || str_contains($tag, 'cable'))   return '📺';
    if (str_contains($tag, 'balcony'))                             return '🌅';
    if (str_contains($tag, 'parking'))                             return '🚗';
    if (str_contains($tag, 'laundry') || str_contains($tag, 'washer')) return '👕';
    if (str_contains($tag, 'water'))                               return '💧';
    if (str_contains($tag, 'electric') || str_contains($tag, 'bill')) return '⚡';
    if (str_contains($tag, 'window'))                              return '🪟';
    if (str_contains($tag, 'bed') || str_contains($tag, 'mattress')) return '🛏';
    return '✓';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Available Rooms &amp; Inquiry — Tenant Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
/* ══════════════════════════ BASE ══════════════════════════ */
:root {
  --bg:#080d1a; --surface:#0d1424; --surface-2:#111827; --surface-3:#0f1729;
  --accent:#2563eb; --accent-lt:#3b82f6; --accent-gl:rgba(37,99,235,0.15);
  --ok:#10b981; --ok-dim:rgba(16,185,129,0.1);
  --err:#ef4444; --warn:#f59e0b;
  --silver:#94a3b8; --light:#cbd5e1; --white:#f1f5f9;
  --border:rgba(255,255,255,0.07); --border-2:rgba(255,255,255,0.04);
  --gold:#f59e0b; --gold-dim:rgba(245,158,11,0.12);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
html{scroll-behavior:smooth;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);min-height:100vh;color:var(--white);}

/* ══════════════════════════ NAVBAR ══════════════════════════ */
.navbar {
  position:sticky;top:0;z-index:50;
  background:rgba(8,13,26,0.92);
  backdrop-filter:blur(12px);
  border-bottom:1px solid var(--border);
  padding:0 2rem;
  display:flex;align-items:center;justify-content:space-between;
  height:56px;
}
.navbar-logo{display:flex;align-items:center;gap:.6rem;}
.logo-mark{width:30px;height:30px;background:var(--accent);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:.85rem;}
.logo-name{font-family:'Syne',sans-serif;font-size:.9rem;font-weight:700;color:var(--white);}
.logo-name small{display:block;font-size:.55rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:.12em;text-transform:uppercase;margin-top:1px;}
.nav-links{display:flex;align-items:center;gap:.25rem;}
.nav-link{padding:.4rem .85rem;font-size:.8rem;font-weight:500;color:var(--silver);text-decoration:none;border-radius:4px;transition:all .2s;}
.nav-link:hover{color:var(--white);background:rgba(255,255,255,0.05);}
.nav-link.cta{background:var(--accent);color:#fff;font-weight:600;}
.nav-link.cta:hover{background:#1d4ed8;}

/* ══════════════════════════ HERO ══════════════════════════ */
.hero-section {
  position:relative;
  padding:5rem 2rem 4rem;
  text-align:center;
  overflow:hidden;
}
.hero-section::before {
  content:'';position:absolute;inset:0;
  background:
    radial-gradient(ellipse 60% 50% at 50% 0%, rgba(37,99,235,0.18) 0%, transparent 65%),
    radial-gradient(ellipse 40% 30% at 80% 60%, rgba(16,185,129,0.06) 0%, transparent 55%);
  pointer-events:none;
}
.hero-grid {
  position:absolute;inset:0;
  background-image:linear-gradient(rgba(255,255,255,0.02) 1px,transparent 1px),
    linear-gradient(90deg,rgba(255,255,255,0.02) 1px,transparent 1px);
  background-size:44px 44px;
  pointer-events:none;
}
.hero-section>*:not(.hero-grid){position:relative;}
.hero-badge {
  display:inline-flex;align-items:center;gap:.5rem;
  padding:.35rem .9rem;
  background:rgba(37,99,235,0.12);
  border:1px solid rgba(37,99,235,0.3);
  border-radius:99px;
  font-size:.72rem;font-weight:600;color:var(--accent-lt);
  letter-spacing:.08em;text-transform:uppercase;
  margin-bottom:1.25rem;
}
.hero-badge .dot{width:6px;height:6px;border-radius:50%;background:var(--ok);box-shadow:0 0 8px var(--ok);}
.hero-title{font-family:'Syne',sans-serif;font-size:clamp(2rem,5vw,3.25rem);font-weight:800;line-height:1.06;margin-bottom:1rem;}
.hero-title em{font-style:normal;color:var(--accent-lt);}
.hero-sub{font-size:.95rem;color:var(--silver);line-height:1.75;max-width:520px;margin:0 auto 2rem;}
.hero-actions{display:flex;align-items:center;justify-content:center;gap:.75rem;flex-wrap:wrap;}
.btn-primary{padding:.72rem 1.5rem;background:var(--accent);color:#fff;border:none;border-radius:5px;font-family:'Syne',sans-serif;font-size:.85rem;font-weight:700;cursor:pointer;text-decoration:none;transition:all .2s;display:inline-flex;align-items:center;gap:.4rem;}
.btn-primary:hover{background:#1d4ed8;box-shadow:0 6px 20px var(--accent-gl);}
.btn-ghost{padding:.72rem 1.5rem;background:transparent;color:var(--light);border:1px solid var(--border);border-radius:5px;font-family:'Syne',sans-serif;font-size:.85rem;font-weight:600;cursor:pointer;text-decoration:none;transition:all .2s;display:inline-flex;align-items:center;gap:.4rem;}
.btn-ghost:hover{background:rgba(255,255,255,0.05);border-color:rgba(255,255,255,0.15);}

/* ══════════════════════════ STATS BAR ══════════════════════════ */
.stats-bar {
  display:flex;align-items:center;justify-content:center;gap:2.5rem;
  padding:1rem 2rem;
  background:rgba(255,255,255,0.02);
  border-top:1px solid var(--border);
  border-bottom:1px solid var(--border);
  flex-wrap:wrap;
}
.stat-item{text-align:center;}
.stat-num{font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:var(--white);line-height:1;}
.stat-num.green{color:var(--ok);}
.stat-label{font-size:.68rem;color:var(--silver);text-transform:uppercase;letter-spacing:.1em;margin-top:3px;}
.stat-divider{width:1px;height:36px;background:var(--border);}

/* ══════════════════════════ SECTION HEADERS ══════════════════════════ */
.section-wrap{max-width:1200px;margin:0 auto;padding:3rem 2rem;}
.section-header{text-align:center;margin-bottom:2.5rem;}
.section-tag{display:inline-block;font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.14em;color:var(--accent-lt);margin-bottom:.6rem;}
.section-title{font-family:'Syne',sans-serif;font-size:clamp(1.5rem,3vw,2rem);font-weight:800;color:var(--white);margin-bottom:.6rem;}
.section-sub{font-size:.875rem;color:var(--silver);line-height:1.7;}

/* ══════════════════════════ FILTER BAR ══════════════════════════ */
.filter-bar{display:flex;align-items:center;gap:.5rem;justify-content:center;margin-bottom:2rem;flex-wrap:wrap;}
.filter-btn{padding:.45rem 1rem;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:99px;font-family:'DM Sans',sans-serif;font-size:.76rem;font-weight:500;color:var(--silver);cursor:pointer;transition:all .2s;white-space:nowrap;}
.filter-btn:hover{color:var(--white);border-color:rgba(255,255,255,0.18);}
.filter-btn.active{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600;}

/* ══════════════════════════ ROOMS GRID ══════════════════════════ */
.rooms-grid {
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
  gap:1.25rem;
}

/* ── Room Card ── */
.room-card {
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;
  overflow:hidden;
  transition:transform .25s, box-shadow .25s, border-color .25s;
  display:flex;flex-direction:column;
  cursor:pointer;
}
.room-card:hover{
  transform:translateY(-4px);
  box-shadow:0 16px 40px rgba(0,0,0,0.4), 0 0 0 1px rgba(37,99,235,0.25);
  border-color:rgba(37,99,235,0.35);
}

/* Room card banner */
.card-banner{
  position:relative;
  height:140px;
  background:linear-gradient(135deg, #0f1e3e 0%, #0d1829 50%, #061124 100%);
  display:flex;align-items:center;justify-content:center;
  overflow:hidden;
}
.card-banner::before{
  content:'';position:absolute;inset:0;
  background:radial-gradient(circle at 30% 50%, rgba(37,99,235,0.2) 0%, transparent 60%);
}
.card-banner-icon{
  font-size:3.5rem;position:relative;z-index:1;
  filter:drop-shadow(0 4px 12px rgba(37,99,235,0.4));
}
.card-banner-pattern{
  position:absolute;inset:0;
  background-image:linear-gradient(rgba(255,255,255,0.03) 1px,transparent 1px),
    linear-gradient(90deg,rgba(255,255,255,0.03) 1px,transparent 1px);
  background-size:24px 24px;
}
.card-floor-badge{
  position:absolute;top:10px;left:10px;
  padding:.25rem .6rem;
  background:rgba(0,0,0,0.5);
  backdrop-filter:blur(4px);
  border:1px solid rgba(255,255,255,0.1);
  border-radius:99px;
  font-size:.62rem;font-weight:600;color:var(--light);
  z-index:2;
}
.card-vacant-badge{
  position:absolute;top:10px;right:10px;
  padding:.25rem .65rem;
  background:rgba(16,185,129,0.15);
  border:1px solid rgba(16,185,129,0.35);
  border-radius:99px;
  font-size:.62rem;font-weight:700;color:var(--ok);
  z-index:2;display:flex;align-items:center;gap:.3rem;
}
.card-vacant-badge::before{content:'';width:5px;height:5px;border-radius:50%;background:var(--ok);box-shadow:0 0 6px var(--ok);}

/* Room card body */
.card-body{padding:1.1rem 1.1rem .8rem;flex:1;display:flex;flex-direction:column;gap:.6rem;}
.card-top{display:flex;align-items:flex-start;justify-content:space-between;gap:.5rem;}
.card-room-num{font-family:'Syne',sans-serif;font-size:1.05rem;font-weight:800;color:var(--white);}
.card-type{font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.1em;color:var(--accent-lt);background:var(--accent-gl);padding:.2rem .55rem;border-radius:99px;white-space:nowrap;}
.card-rate{font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:800;color:var(--white);}
.card-rate span{font-family:'DM Sans',sans-serif;font-size:.72rem;font-weight:400;color:var(--silver);}
.card-desc{font-size:.78rem;color:var(--silver);line-height:1.6;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
.card-desc-empty{font-size:.78rem;color:rgba(148,163,184,0.35);font-style:italic;}

/* Amenity tags */
.amenity-tags{display:flex;flex-wrap:wrap;gap:.35rem;margin-top:.2rem;}
.amenity-tag{display:flex;align-items:center;gap:.25rem;padding:.22rem .55rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:99px;font-size:.65rem;color:var(--light);}
.amenity-tag .aico{font-size:.7rem;}
.amenity-more{padding:.22rem .55rem;background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.06);border-radius:99px;font-size:.65rem;color:var(--silver);}

/* Card meta row */
.card-meta{display:flex;align-items:center;gap:1rem;font-size:.72rem;color:var(--silver);border-top:1px solid var(--border-2);padding-top:.65rem;margin-top:auto;}
.card-meta-item{display:flex;align-items:center;gap:.3rem;}

/* Card action */
.card-action{padding:.75rem 1.1rem;border-top:1px solid var(--border-2);}
.btn-inquire{
  width:100%;padding:.62rem;
  background:linear-gradient(135deg,var(--accent),#1d4ed8);
  border:none;border-radius:6px;
  font-family:'Syne',sans-serif;font-size:.8rem;font-weight:700;
  color:#fff;cursor:pointer;
  transition:all .2s;
  display:flex;align-items:center;justify-content:center;gap:.4rem;
}
.btn-inquire:hover{opacity:.9;box-shadow:0 4px 14px var(--accent-gl);}

/* ── No rooms state ── */
.no-rooms{
  grid-column:1/-1;
  text-align:center;
  padding:4rem 2rem;
  background:rgba(255,255,255,0.02);
  border:1px dashed var(--border);
  border-radius:12px;
}
.no-rooms-icon{font-size:3rem;margin-bottom:1rem;opacity:.4;}
.no-rooms-title{font-family:'Syne',sans-serif;font-size:1.1rem;font-weight:700;color:var(--silver);margin-bottom:.4rem;}
.no-rooms-sub{font-size:.82rem;color:rgba(148,163,184,0.5);line-height:1.6;}

/* ══════════════════════════ SPLIT SECTION (form + steps) ══════════════════════════ */
.inquiry-split {
  display:grid;
  grid-template-columns:1fr 420px;
  gap:2rem;
  max-width:1200px;
  margin:0 auto;
  padding:0 2rem 4rem;
  align-items:start;
}
@media(max-width:900px){.inquiry-split{grid-template-columns:1fr;}}

/* ── Form card ── */
.form-card{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:14px;
  overflow:hidden;
}
.form-card-header{
  padding:1.5rem 1.75rem 1.25rem;
  border-bottom:1px solid var(--border);
  background:rgba(37,99,235,0.04);
}
.form-card-title{font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:800;color:var(--white);margin-bottom:.2rem;}
.form-card-sub{font-size:.78rem;color:var(--silver);line-height:1.6;}
.form-card-body{padding:1.5rem 1.75rem;}

/* Room interest banner (shown when room is pre-selected) */
.room-interest-banner{
  display:flex;align-items:center;gap:.75rem;
  padding:.75rem 1rem;
  background:rgba(37,99,235,0.1);
  border:1px solid rgba(37,99,235,0.25);
  border-radius:6px;
  margin-bottom:1.1rem;
}
.rib-icon{font-size:1.2rem;}
.rib-text{font-size:.78rem;color:var(--light);line-height:1.5;flex:1;}
.rib-text strong{color:var(--accent-lt);}
.rib-clear{font-size:.7rem;color:var(--silver);background:rgba(255,255,255,0.05);border:1px solid var(--border);border-radius:4px;padding:.25rem .55rem;text-decoration:none;white-space:nowrap;transition:all .2s;}
.rib-clear:hover{color:var(--white);}

/* Form fields */
.fields{display:flex;flex-direction:column;gap:.75rem;}
.row-2{display:grid;grid-template-columns:1fr 1fr;gap:.6rem;}
.field{display:flex;flex-direction:column;gap:.3rem;}
.field label{font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.09em;color:var(--silver);}
.wrap{position:relative;}
.wrap input,.wrap select,.wrap textarea{
  width:100%;padding:.7rem 1rem .7rem 2.3rem;
  background:rgba(255,255,255,0.04);
  border:1px solid rgba(255,255,255,0.09);
  border-radius:5px;
  font-family:'DM Sans',sans-serif;font-size:.875rem;
  color:var(--white);outline:none;
  transition:border-color .2s,box-shadow .2s;
}
.wrap select{appearance:none;-webkit-appearance:none;}
.wrap select option{background:#111827;color:var(--white);}
.wrap textarea{padding-left:2.3rem;resize:vertical;min-height:100px;}
.wrap input::placeholder,.wrap textarea::placeholder{color:rgba(148,163,184,0.35);}
.wrap input:focus,.wrap select:focus,.wrap textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-gl);}
.wrap input[type="date"]::-webkit-calendar-picker-indicator{filter:invert(.5);}
.wrap .ico{position:absolute;left:.72rem;top:50%;transform:translateY(-50%);font-size:.72rem;color:rgba(148,163,184,0.4);pointer-events:none;}
.wrap .ico-top{position:absolute;left:.72rem;top:.82rem;font-size:.72rem;color:rgba(148,163,184,0.4);pointer-events:none;}
.char-count{font-size:.62rem;color:var(--silver);text-align:right;margin-top:2px;}

.alert-err{display:flex;align-items:center;gap:.5rem;padding:.65rem .9rem;border-radius:5px;font-size:.78rem;margin-bottom:1rem;border-left:3px solid var(--err);background:rgba(239,68,68,0.07);color:#fca5a5;}

.btn-submit{
  width:100%;padding:.82rem;
  background:var(--accent);
  color:#fff;border:none;border-radius:5px;
  font-family:'Syne',sans-serif;font-size:.88rem;font-weight:700;
  cursor:pointer;transition:all .2s;
  display:flex;align-items:center;justify-content:center;gap:.5rem;
  margin-top:.25rem;
}
.btn-submit:hover{background:#1d4ed8;box-shadow:0 6px 20px var(--accent-gl);}
.sec-note{display:flex;align-items:center;justify-content:center;gap:.4rem;font-size:.63rem;color:rgba(148,163,184,0.4);margin-top:.85rem;}

/* ── Sidebar cards ── */
.sidebar-cards{display:flex;flex-direction:column;gap:1rem;}

.info-card{
  background:var(--surface);
  border:1px solid var(--border);
  border-radius:12px;
  padding:1.25rem 1.35rem;
}
.info-card-title{font-family:'Syne',sans-serif;font-size:.88rem;font-weight:700;color:var(--white);margin-bottom:.85rem;display:flex;align-items:center;gap:.45rem;}
.step-item{display:flex;align-items:flex-start;gap:.75rem;margin-bottom:.65rem;}
.step-item:last-child{margin-bottom:0;}
.step-circle{
  width:26px;height:26px;border-radius:50%;flex-shrink:0;
  background:var(--accent-gl);border:1px solid rgba(37,99,235,0.3);
  display:flex;align-items:center;justify-content:center;
  font-size:.65rem;font-weight:700;color:var(--accent-lt);margin-top:1px;
}
.step-circle.done{background:rgba(16,185,129,0.15);border-color:rgba(16,185,129,0.3);color:var(--ok);}
.step-text strong{display:block;font-size:.78rem;font-weight:600;color:var(--white);margin-bottom:1px;}
.step-text span{font-size:.7rem;color:var(--silver);line-height:1.5;}
.step-connector{width:1px;height:12px;background:rgba(37,99,235,0.2);margin:0 0 .5rem 12px;}

/* Status checker */
.checker-form{display:flex;gap:.5rem;}
.checker-form .wrap{flex:1;}
.checker-btn{
  padding:.7rem 1rem;
  background:rgba(255,255,255,0.05);border:1px solid var(--border);
  border-radius:5px;font-family:'DM Sans',sans-serif;font-size:.78rem;
  font-weight:600;color:var(--silver);cursor:pointer;
  white-space:nowrap;transition:all .2s;
}
.checker-btn:hover{color:var(--white);border-color:rgba(255,255,255,0.2);}

/* Status result */
.status-result{
  margin-top:.85rem;
  padding:.9rem 1rem;
  border-radius:6px;
}

/* ══════════════════════════ SUCCESS STATE ══════════════════════════ */
.success-card{text-align:center;padding:1rem 0;}
.success-icon{width:64px;height:64px;border-radius:16px;background:rgba(16,185,129,0.12);border:1px solid rgba(16,185,129,0.25);display:flex;align-items:center;justify-content:center;font-size:1.8rem;margin:0 auto 1.25rem;}
.success-title{font-family:'Syne',sans-serif;font-size:1.25rem;font-weight:800;color:var(--white);margin-bottom:.5rem;}
.success-sub{font-size:.82rem;color:var(--silver);line-height:1.75;margin-bottom:1.5rem;}
.next-steps{display:flex;flex-direction:column;gap:.5rem;margin-bottom:1.5rem;text-align:left;}
.next-step{display:flex;align-items:center;gap:.75rem;padding:.6rem .85rem;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:5px;font-size:.78rem;color:var(--light);}
.ns-num{width:22px;height:22px;border-radius:50%;background:var(--accent-gl);border:1px solid rgba(37,99,235,0.3);display:flex;align-items:center;justify-content:center;font-size:.65rem;font-weight:700;color:var(--accent-lt);flex-shrink:0;}
.ns-done{background:rgba(16,185,129,0.15);border-color:rgba(16,185,129,0.3);color:var(--ok);}
.btn-back{display:block;width:100%;padding:.72rem;background:rgba(255,255,255,0.04);border:1px solid var(--border);border-radius:5px;font-family:'Syne',sans-serif;font-size:.85rem;font-weight:600;color:var(--light);text-decoration:none;text-align:center;transition:all .2s;}
.btn-back:hover{background:rgba(255,255,255,0.07);}

/* ══════════════════════════ FOOTER ══════════════════════════ */
.page-footer{
  text-align:center;padding:2rem;
  border-top:1px solid var(--border);
  font-size:.7rem;color:rgba(148,163,184,0.35);
}

/* ══════════════════════════ MODAL ══════════════════════════ */
.modal-overlay{
  position:fixed;inset:0;z-index:200;
  background:rgba(0,0,0,0.75);
  backdrop-filter:blur(4px);
  display:none;align-items:center;justify-content:center;padding:1rem;
}
.modal-overlay.open{display:flex;}
.modal-box{
  background:var(--surface-2);
  border:1px solid var(--border);
  border-radius:16px;
  width:100%;max-width:540px;
  max-height:90vh;overflow-y:auto;
  animation:popIn .25s cubic-bezier(.22,1,.36,1);
}
@keyframes popIn{from{opacity:0;transform:scale(.96) translateY(10px);}to{opacity:1;transform:none;}}
.modal-header{
  padding:1.25rem 1.5rem;
  border-bottom:1px solid var(--border);
  display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;
  background:rgba(37,99,235,0.04);
}
.modal-room-num{font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:800;color:var(--white);}
.modal-type{font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:.1em;color:var(--accent-lt);background:var(--accent-gl);padding:.2rem .55rem;border-radius:99px;margin-top:.2rem;display:inline-block;}
.modal-close{width:30px;height:30px;border-radius:50%;background:rgba(255,255,255,0.06);border:none;color:var(--silver);cursor:pointer;font-size:1rem;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s;}
.modal-close:hover{background:rgba(255,255,255,0.12);color:var(--white);}
.modal-body{padding:1.5rem;}
.modal-rate{font-family:'Syne',sans-serif;font-size:2rem;font-weight:800;color:var(--white);margin-bottom:.25rem;}
.modal-rate span{font-family:'DM Sans',sans-serif;font-size:.85rem;font-weight:400;color:var(--silver);}
.modal-section{margin-top:1.25rem;}
.modal-section-label{font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--silver);margin-bottom:.6rem;}
.modal-amenities{display:flex;flex-wrap:wrap;gap:.4rem;}
.modal-amenity{display:flex;align-items:center;gap:.3rem;padding:.3rem .7rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:99px;font-size:.72rem;color:var(--light);}
.modal-desc{font-size:.82rem;color:var(--silver);line-height:1.7;background:rgba(255,255,255,0.02);border:1px solid var(--border-2);border-radius:6px;padding:.85rem 1rem;}
.modal-meta-grid{display:grid;grid-template-columns:1fr 1fr;gap:.6rem;}
.modal-meta-item{background:rgba(255,255,255,0.02);border:1px solid var(--border-2);border-radius:6px;padding:.65rem .85rem;}
.modal-meta-label{font-size:.62rem;color:var(--silver);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.2rem;}
.modal-meta-value{font-size:.9rem;font-weight:600;color:var(--white);}
.modal-footer{padding:1rem 1.5rem 1.5rem;}
.btn-modal-inquire{
  width:100%;padding:.8rem;
  background:linear-gradient(135deg,var(--accent),#1d4ed8);
  border:none;border-radius:6px;
  font-family:'Syne',sans-serif;font-size:.9rem;font-weight:700;
  color:#fff;cursor:pointer;
  transition:all .2s;
  display:flex;align-items:center;justify-content:center;gap:.5rem;
}
.btn-modal-inquire:hover{opacity:.9;box-shadow:0 6px 20px var(--accent-gl);}

/* ══════════════════════════ RESPONSIVE ══════════════════════════ */
@media(max-width:768px){
  .stats-bar{gap:1.25rem;}
  .stat-divider{display:none;}
  .rooms-grid{grid-template-columns:1fr;}
  .row-2{grid-template-columns:1fr;}
  .navbar{padding:0 1rem;}
}
@media(max-width:460px){
  .hero-section{padding:3.5rem 1rem 3rem;}
}

/* Scroll animation */
.fade-up{opacity:0;transform:translateY(20px);transition:opacity .5s ease,transform .5s ease;}
.fade-up.visible{opacity:1;transform:none;}
</style>
</head>
<body>

<!-- ══════════ NAVBAR ══════════ -->
<nav class="navbar">
  <div class="navbar-logo">
    <div class="logo-mark">⬡</div>
    <div class="logo-name">Tenant Portal <small>Boarding House</small></div>
  </div>
  <div class="nav-links">
    <a href="index.php"    class="nav-link">Sign In</a>
    <a href="register.php" class="nav-link">Register</a>
    <a href="#inquire"     class="nav-link cta">📋 Inquire Now</a>
  </div>
</nav>

<!-- ══════════ HERO ══════════ -->
<section class="hero-section">
  <div class="hero-grid"></div>
  <div class="hero-badge">
    <span class="dot"></span>
    <?= count($availableRooms) ?> Room<?= count($availableRooms) !== 1 ? 's' : '' ?> Available Now
  </div>
  <h1 class="hero-title">Find Your Perfect<br><em>Room Today</em></h1>
  <p class="hero-sub">Browse our available rooms, check what's included, and send us an inquiry — all in one place.</p>
  <div class="hero-actions">
    <a href="#rooms"   class="btn-primary">🛏 Browse Rooms</a>
    <a href="#inquire" class="btn-ghost">📋 Send Inquiry</a>
  </div>
</section>

<!-- Stats bar -->
<?php
$totalVacant = count($availableRooms);
$minRate = $totalVacant ? min(array_column($availableRooms, 'monthly_rate')) : 0;
$maxRate = $totalVacant ? max(array_column($availableRooms, 'monthly_rate')) : 0;
$types   = $totalVacant ? count(array_unique(array_column($availableRooms, 'room_type'))) : 0;
?>
<div class="stats-bar">
  <div class="stat-item">
    <div class="stat-num green"><?= $totalVacant ?></div>
    <div class="stat-label">Vacant Rooms</div>
  </div>
  <div class="stat-divider"></div>
  <div class="stat-item">
    <div class="stat-num"><?= $types ?></div>
    <div class="stat-label">Room Types</div>
  </div>
  <div class="stat-divider"></div>
  <div class="stat-item">
    <div class="stat-num">₱<?= $minRate ? number_format($minRate, 0) : '—' ?></div>
    <div class="stat-label">Starting Rate</div>
  </div>
  <div class="stat-divider"></div>
  <div class="stat-item">
    <div class="stat-num">✅</div>
    <div class="stat-label">Move-In Ready</div>
  </div>
</div>

<!-- ══════════ AVAILABLE ROOMS ══════════ -->
<section id="rooms">
  <div class="section-wrap">
    <div class="section-header fade-up">
      <div class="section-tag">🏠 Available Now</div>
      <h2 class="section-title">Browse Vacant Rooms</h2>
      <p class="section-sub">Click any room to see full details — amenities, floor, capacity, and monthly rate.</p>
    </div>

    <?php if (!empty($availableRooms)): ?>
    <!-- Filter buttons by room type -->
    <?php $uniqueTypes = array_unique(array_column($availableRooms, 'room_type')); ?>
    <?php if (count($uniqueTypes) > 1): ?>
    <div class="filter-bar fade-up">
      <button class="filter-btn active" data-filter="all">All Rooms</button>
      <?php foreach ($uniqueTypes as $ut): ?>
      <button class="filter-btn" data-filter="<?= strtolower($ut) ?>"><?= roomIcon($ut) ?> <?= ucfirst($ut) ?></button>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="rooms-grid">
      <?php foreach ($availableRooms as $room):
        $tags   = amenityTags($room['amenities'] ?? '');
        $showTags = array_slice($tags, 0, 4);
        $moreCnt  = count($tags) - count($showTags);
      ?>
      <div class="room-card fade-up"
           data-type="<?= strtolower($room['room_type']) ?>"
           onclick="openRoomModal(<?= htmlspecialchars(json_encode($room), ENT_QUOTES, 'UTF-8') ?>)">
        <div class="card-banner">
          <div class="card-banner-pattern"></div>
          <div class="card-banner-icon"><?= roomIcon($room['room_type']) ?></div>
          <div class="card-floor-badge">Floor <?= (int)$room['floor'] ?></div>
          <div class="card-vacant-badge">Vacant</div>
        </div>
        <div class="card-body">
          <div class="card-top">
            <div>
              <div class="card-room-num">Room <?= htmlspecialchars($room['room_number'], ENT_QUOTES, 'UTF-8') ?></div>
              <div style="margin-top:.2rem;"><span class="card-type"><?= ucfirst($room['room_type']) ?></span></div>
            </div>
            <div style="text-align:right;">
              <div class="card-rate">₱<?= number_format($room['monthly_rate'], 0) ?><span>/mo</span></div>
              <?php if ($room['capacity'] > 1): ?>
              <div style="font-size:.68rem;color:var(--silver);margin-top:2px;">Up to <?= $room['capacity'] ?> persons</div>
              <?php endif; ?>
            </div>
          </div>

          <?php if (!empty($room['description'])): ?>
          <div class="card-desc"><?= htmlspecialchars($room['description'], ENT_QUOTES, 'UTF-8') ?></div>
          <?php else: ?>
          <div class="card-desc-empty">No description provided.</div>
          <?php endif; ?>

          <?php if (!empty($showTags)): ?>
          <div class="amenity-tags">
            <?php foreach ($showTags as $tag): ?>
            <div class="amenity-tag"><span class="aico"><?= amenityIcon($tag) ?></span><?= htmlspecialchars($tag, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endforeach; ?>
            <?php if ($moreCnt > 0): ?>
            <div class="amenity-more">+<?= $moreCnt ?> more</div>
            <?php endif; ?>
          </div>
          <?php endif; ?>

          <div class="card-meta">
            <div class="card-meta-item">🏢 Floor <?= (int)$room['floor'] ?></div>
            <div class="card-meta-item">👥 <?= (int)$room['capacity'] ?> person<?= $room['capacity'] > 1 ? 's' : '' ?></div>
            <div class="card-meta-item" style="margin-left:auto;color:var(--accent-lt);font-size:.68rem;font-weight:600;">View Details →</div>
          </div>
        </div>
        <div class="card-action">
          <button class="btn-inquire" onclick="event.stopPropagation();inquireAbout('<?= htmlspecialchars($room['room_number'], ENT_QUOTES, 'UTF-8') ?>','<?= strtolower(htmlspecialchars($room['room_type'], ENT_QUOTES, 'UTF-8')) ?>')">
            📋 Inquire About This Room
          </button>
        </div>
      </div>
      <?php endforeach; ?>
    </div>

    <?php else: ?>
    <div class="rooms-grid">
      <div class="no-rooms fade-up">
        <div class="no-rooms-icon">🏠</div>
        <div class="no-rooms-title">No Vacant Rooms Right Now</div>
        <div class="no-rooms-sub">All rooms are currently occupied. You can still send us an inquiry and we'll notify you as soon as a room becomes available.</div>
        <a href="#inquire" class="btn-primary" style="display:inline-flex;margin-top:1.25rem;">📋 Send Inquiry Anyway</a>
      </div>
    </div>
    <?php endif; ?>
  </div>
</section>

<!-- ══════════ INQUIRY + SIDEBAR ══════════ -->
<section id="inquire" style="background:rgba(255,255,255,0.01);border-top:1px solid var(--border);padding-top:3rem;">
  <div style="max-width:1200px;margin:0 auto;padding:0 2rem 1rem;">
    <div class="section-header fade-up" style="margin-bottom:2rem;">
      <div class="section-tag">📋 Get In Touch</div>
      <h2 class="section-title">Send an Inquiry</h2>
      <p class="section-sub">Fill out the form below and we'll get back to you as soon as possible.</p>
    </div>
  </div>
  <div class="inquiry-split">

    <!-- ── FORM ── -->
    <div class="form-card fade-up">
      <div class="form-card-header">
        <div class="form-card-title">📋 Room Inquiry Form</div>
        <div class="form-card-sub">Tell us about yourself and what you're looking for.</div>
      </div>
      <div class="form-card-body">

        <?php if ($success): ?>
        <!-- SUCCESS -->
        <div class="success-card">
          <div class="success-icon">✅</div>
          <div class="success-title">Inquiry Sent!</div>
          <div class="success-sub">
            Thank you! We received your inquiry. A <strong style="color:var(--white)">confirmation email</strong> has been sent to
            <strong style="color:var(--accent-lt)"><?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?></strong>.
          </div>
          <div class="next-steps">
            <div class="next-step"><div class="ns-num ns-done">✓</div> Inquiry submitted &amp; confirmation email sent</div>
            <div class="next-step"><div class="ns-num">2</div> Admin reviews and contacts you via email or Facebook</div>
            <div class="next-step"><div class="ns-num">3</div> If room is available — you'll get an invite to register</div>
            <div class="next-step"><div class="ns-num">4</div> Admin approves and sends your login credentials</div>
          </div>
          <div style="margin-bottom:1rem;padding:12px 14px;background:rgba(37,99,235,0.08);border:1px solid rgba(37,99,235,0.2);border-radius:6px;font-size:.78rem;color:var(--light);line-height:1.65;text-align:left;">
            📌 <strong>Bookmark this page</strong> — you can check your inquiry status anytime using the status checker on the right.
          </div>
          <a href="#rooms" class="btn-back" style="margin-bottom:.6rem;">← Browse More Rooms</a>
          <a href="inquiry.php" class="btn-back" style="opacity:.6;margin-top:.4rem;">Submit Another Inquiry</a>
        </div>

        <?php else: ?>
        <!-- FORM -->
        <?php if ($error): ?>
        <div class="alert-err">⚠ <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>

        <?php
          // Pre-selected room from clicking "Inquire About This Room"
          $prefRoom     = $_POST['room_ref']  ?? $_GET['room']      ?? '';
          $prefRoomType = $_POST['room_type'] ?? $_GET['room_type'] ?? '';
        ?>
        <?php if ($prefRoom): ?>
        <div class="room-interest-banner">
          <span class="rib-icon">🛏</span>
          <div class="rib-text">You're inquiring about <strong>Room <?= htmlspecialchars($prefRoom, ENT_QUOTES, 'UTF-8') ?></strong>. This will be noted in your inquiry.</div>
          <a href="inquiry.php#inquire" class="rib-clear">✕ Clear</a>
        </div>
        <?php endif; ?>

        <form method="POST" action="inquiry.php#inquire" class="fields">
          <input type="hidden" name="room_ref" value="<?= htmlspecialchars($prefRoom, ENT_QUOTES, 'UTF-8') ?>">

          <div class="row-2">
            <div class="field">
              <label>Full Name *</label>
              <div class="wrap">
                <span class="ico">👤</span>
                <input type="text" name="name" placeholder="Juan dela Cruz"
                       value="<?= htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required>
              </div>
            </div>
            <div class="field">
              <label>Contact Number *</label>
              <div class="wrap">
                <span class="ico">📱</span>
                <input type="tel" name="contact" placeholder="09XX-XXX-XXXX"
                       value="<?= htmlspecialchars($_POST['contact'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required>
              </div>
            </div>
          </div>

          <div class="field">
            <label>Email Address *</label>
            <div class="wrap">
              <span class="ico">✉</span>
              <input type="email" name="email" placeholder="your@email.com"
                     value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required>
            </div>
          </div>

          <div class="row-2">
            <div class="field">
              <label>Room Type Interest</label>
              <div class="wrap">
                <span class="ico">🚪</span>
                <select name="room_type">
                  <option value="">— Any —</option>
                  <?php
                  $allTypes = ['Single','Double','Triple','Studio','Family','Dormitory','Suite'];
                  foreach ($allTypes as $t):
                    $sel = (($_POST['room_type'] ?? $prefRoomType) === strtolower($t) || ($_POST['room_type'] ?? $prefRoomType) === $t) ? 'selected' : '';
                  ?>
                  <option value="<?= strtolower($t) ?>" <?= $sel ?>><?= $t ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
            </div>
            <div class="field">
              <label>Preferred Move-In</label>
              <div class="wrap">
                <span class="ico">📅</span>
                <input type="date" name="move_in"
                       min="<?= date('Y-m-d') ?>"
                       value="<?= htmlspecialchars($_POST['move_in'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
              </div>
            </div>
          </div>

          <div class="field">
            <label>Facebook Profile Link <span style="font-weight:400;text-transform:none;color:rgba(148,163,184,.4)">(optional)</span></label>
            <div class="wrap">
              <span class="ico">👤</span>
              <input type="url" name="fb_link"
                     placeholder="https://facebook.com/yourname"
                     value="<?= htmlspecialchars($_POST['fb_link'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
            </div>
            <span style="font-size:.62rem;color:var(--silver);margin-top:2px;">So admin can reach you on Facebook if needed.</span>
          </div>

          <div class="field">
            <label>Message / Questions *</label>
            <div class="wrap">
              <span class="ico-top">💬</span>
              <textarea name="message" id="msg" placeholder="Tell us what you're looking for — room preferences, budget, any questions…"
                        maxlength="500" oninput="updateCount(this)" required><?= htmlspecialchars($_POST['message'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
            </div>
            <div class="char-count"><span id="char-count">0</span> / 500</div>
          </div>

          <button type="submit" class="btn-submit">📨 Send Inquiry</button>
        </form>

        <div class="sec-note">🔒 Your info is kept private and only shared with the property manager.</div>
        <?php endif; ?>

      </div>
    </div>

    <!-- ── SIDEBAR ── -->
    <div class="sidebar-cards">

      <!-- How it works -->
      <div class="info-card fade-up">
        <div class="info-card-title">🗺️ How It Works</div>
        <div class="step-item">
          <div class="step-circle done">✓</div>
          <div class="step-text">
            <strong>Browse &amp; Inquire</strong>
            <span>Pick a room you like and send us your inquiry with your details.</span>
          </div>
        </div>
        <div class="step-connector"></div>
        <div class="step-item">
          <div class="step-circle">2</div>
          <div class="step-text">
            <strong>Admin Reviews &amp; Contacts You</strong>
            <span>We'll get back to you via email or Facebook to confirm availability.</span>
          </div>
        </div>
        <div class="step-connector"></div>
        <div class="step-item">
          <div class="step-circle">3</div>
          <div class="step-text">
            <strong>Register Your Account</strong>
            <span>Once confirmed, create your tenant account to manage rent online.</span>
          </div>
        </div>
        <div class="step-connector"></div>
        <div class="step-item">
          <div class="step-circle">4</div>
          <div class="step-text">
            <strong>Move In!</strong>
            <span>Admin approves your account, assigns your room &amp; you're all set.</span>
          </div>
        </div>
      </div>

      <!-- Status checker -->
      <div class="info-card fade-up">
        <div class="info-card-title">🔍 Check Inquiry Status</div>
        <p style="font-size:.75rem;color:var(--silver);margin-bottom:.85rem;line-height:1.6;">Already submitted an inquiry? Enter your email to check the status.</p>
        <form method="GET" action="inquiry.php#inquire" class="checker-form">
          <input type="hidden" name="anchor" value="inquire">
          <div class="wrap">
            <span class="ico">✉</span>
            <input type="email" name="check_email"
                   placeholder="your@email.com"
                   value="<?= htmlspecialchars($_GET['check_email'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                   required style="font-size:.82rem;">
          </div>
          <button type="submit" class="checker-btn">Check →</button>
        </form>

        <?php if ($statusError): ?>
        <div style="margin-top:.75rem;padding:.65rem .85rem;background:rgba(239,68,68,0.07);border:1px solid rgba(239,68,68,0.18);border-radius:5px;font-size:.78rem;color:#fca5a5;">
          ⚠ <?= htmlspecialchars($statusError, ENT_QUOTES, 'UTF-8') ?>
        </div>

        <?php elseif ($statusResult): ?>
        <?php
          $statusMap = [
            'new' => ['icon'=>'📬','bg'=>'rgba(245,158,11,0.1)','border'=>'rgba(245,158,11,0.25)','tc'=>'#fcd34d','title'=>'Inquiry Received','msg'=>'We received your inquiry and will be reviewing it soon.'],
            'contacted' => ['icon'=>'📞','bg'=>'rgba(37,99,235,0.1)','border'=>'rgba(37,99,235,0.25)','tc'=>'var(--accent-lt)','title'=>"We've Contacted You",'msg'=>'Our team has reached out. Please check your phone or email.'],
            'converted' => ['icon'=>'🎉','bg'=>'rgba(16,185,129,0.1)','border'=>'rgba(16,185,129,0.25)','tc'=>'var(--ok)','title'=>"You're Invited to Register!",'msg'=>"Great news! A room is available for you. Click below to create your account."],
            'closed' => ['icon'=>'❌','bg'=>'rgba(239,68,68,0.08)','border'=>'rgba(239,68,68,0.22)','tc'=>'#fca5a5','title'=>'Room Not Available','msg'=>'Unfortunately we could not accommodate your inquiry at this time. Please submit a new one.'],
          ];
          $s = $statusMap[$statusResult['status']] ?? $statusMap['new'];
        ?>
        <div class="status-result" style="background:<?= $s['bg'] ?>;border:1px solid <?= $s['border'] ?>;margin-top:.85rem;">
          <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.4rem;">
            <span style="font-size:1.1rem;"><?= $s['icon'] ?></span>
            <span style="font-family:'Syne',sans-serif;font-size:.85rem;font-weight:700;color:<?= $s['tc'] ?>;"><?= $s['title'] ?></span>
          </div>
          <div style="font-size:.76rem;color:var(--light);line-height:1.65;margin-bottom:.5rem;"><?= htmlspecialchars($s['msg'], ENT_QUOTES, 'UTF-8') ?></div>
          <div style="font-size:.66rem;color:var(--silver);">
            Submitted: <?= date('M j, Y', strtotime($statusResult['created_at'])) ?>
            <?php if ($statusResult['room_type']): ?> · Type: <?= ucfirst(htmlspecialchars($statusResult['room_type'], ENT_QUOTES, 'UTF-8')) ?><?php endif; ?>
          </div>
          <?php if ($statusResult['status'] === 'converted'): ?>
          <a href="register.php" style="display:inline-flex;align-items:center;gap:.4rem;margin-top:.7rem;padding:.55rem .9rem;background:var(--ok);border-radius:4px;font-family:'Syne',sans-serif;font-size:.75rem;font-weight:700;color:#fff;text-decoration:none;">
            Create Account →
          </a>
          <?php endif; ?>
          <?php if ($statusResult['status'] === 'closed'): ?>
          <a href="inquiry.php#inquire" style="display:inline-flex;align-items:center;gap:.4rem;margin-top:.7rem;padding:.55rem .9rem;background:rgba(255,255,255,0.06);border:1px solid var(--border);border-radius:4px;font-family:'Syne',sans-serif;font-size:.75rem;font-weight:600;color:var(--light);text-decoration:none;">
            Submit New Inquiry
          </a>
          <?php endif; ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- Quick links -->
      <div class="info-card fade-up">
        <div class="info-card-title">🔗 Quick Links</div>
        <div style="display:flex;flex-direction:column;gap:.5rem;">
          <a href="index.php" style="display:flex;align-items:center;gap:.6rem;padding:.6rem .75rem;background:rgba(255,255,255,0.02);border:1px solid var(--border-2);border-radius:6px;text-decoration:none;font-size:.78rem;color:var(--light);transition:all .2s;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='rgba(255,255,255,0.02)'">
            <span>🔐</span> Sign In to Tenant Portal
          </a>
          <a href="register.php" style="display:flex;align-items:center;gap:.6rem;padding:.6rem .75rem;background:rgba(255,255,255,0.02);border:1px solid var(--border-2);border-radius:6px;text-decoration:none;font-size:.78rem;color:var(--light);transition:all .2s;" onmouseover="this.style.background='rgba(255,255,255,0.05)'" onmouseout="this.style.background='rgba(255,255,255,0.02)'">
            <span>📝</span> Register as a New Tenant
          </a>
        </div>
      </div>

    </div>
  </div>
</section>

<!-- ══════════ ROOM DETAIL MODAL ══════════ -->
<div class="modal-overlay" id="roomModal" onclick="if(event.target===this)closeModal()">
  <div class="modal-box">
    <div class="modal-header">
      <div>
        <div class="modal-room-num" id="m_room_num">Room —</div>
        <div class="modal-type" id="m_room_type">—</div>
      </div>
      <button class="modal-close" onclick="closeModal()">✕</button>
    </div>
    <div class="modal-body">
      <div class="modal-rate" id="m_rate">₱—<span>/month</span></div>

      <div class="modal-meta-grid">
        <div class="modal-meta-item">
          <div class="modal-meta-label">Floor</div>
          <div class="modal-meta-value" id="m_floor">—</div>
        </div>
        <div class="modal-meta-item">
          <div class="modal-meta-label">Capacity</div>
          <div class="modal-meta-value" id="m_capacity">—</div>
        </div>
        <div class="modal-meta-item">
          <div class="modal-meta-label">Status</div>
          <div class="modal-meta-value" style="color:var(--ok);">✅ Vacant</div>
        </div>
        <div class="modal-meta-item">
          <div class="modal-meta-label">Move-In</div>
          <div class="modal-meta-value" style="color:var(--ok);">Available</div>
        </div>
      </div>

      <div class="modal-section" id="m_amenities_section">
        <div class="modal-section-label">What's Included</div>
        <div class="modal-amenities" id="m_amenities"></div>
      </div>

      <div class="modal-section" id="m_desc_section">
        <div class="modal-section-label">About This Room</div>
        <div class="modal-desc" id="m_desc"></div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-modal-inquire" id="m_inquire_btn">
        📋 Inquire About This Room
      </button>
    </div>
  </div>
</div>

<footer class="page-footer">
  &copy; <?= date('Y') ?> Boarding House Management System. All rights reserved.
</footer>

<script>
// ── Char counter ─────────────────────────────────────────────
function updateCount(el){document.getElementById('char-count').textContent=el.value.length;}
(function(){const m=document.getElementById('msg');if(m)updateCount(m);})();

// ── Room filter ──────────────────────────────────────────────
document.querySelectorAll('.filter-btn').forEach(btn=>{
  btn.addEventListener('click',function(){
    document.querySelectorAll('.filter-btn').forEach(b=>b.classList.remove('active'));
    this.classList.add('active');
    const filter=this.dataset.filter;
    document.querySelectorAll('.room-card').forEach(card=>{
      if(filter==='all'||card.dataset.type===filter){
        card.style.display='flex';
      }else{
        card.style.display='none';
      }
    });
  });
});

// ── Room modal ───────────────────────────────────────────────
const amenityIconMap={
  'ac':'❄️','aircon':'❄️','air con':'❄️','wifi':'📶','wi-fi':'📶','internet':'📶',
  'bath':'🚿','cr':'🚿','comfort room':'🚿','kitchen':'🍳','ref':'🍳','refrigerator':'🍳',
  'cabinet':'🗄️','closet':'🗄️','desk':'🪑','table':'🪑','tv':'📺','cable':'📺',
  'balcony':'🌅','parking':'🚗','laundry':'👕','washer':'👕','water':'💧',
  'electric':'⚡','bills':'⚡','window':'🪟','bed':'🛏','mattress':'🛏',
};
function getAmenityIcon(tag){
  const t=tag.toLowerCase();
  for(const[k,v]of Object.entries(amenityIconMap)){if(t.includes(k))return v;}
  return '✓';
}

let currentRoom=null;
function openRoomModal(room){
  currentRoom=room;
  document.getElementById('m_room_num').textContent='Room '+room.room_number;
  document.getElementById('m_room_type').textContent=room.room_type.charAt(0).toUpperCase()+room.room_type.slice(1);
  document.getElementById('m_rate').innerHTML='₱'+parseFloat(room.monthly_rate).toLocaleString('en-PH',{maximumFractionDigits:0})+'<span>/month</span>';
  document.getElementById('m_floor').textContent='Floor '+room.floor;
  document.getElementById('m_capacity').textContent=room.capacity+(room.capacity>1?' persons':' person');

  // Amenities
  const amenSec=document.getElementById('m_amenities_section');
  const amenDiv=document.getElementById('m_amenities');
  amenDiv.innerHTML='';
  if(room.amenities&&room.amenities.trim()){
    const tags=room.amenities.split(',').map(t=>t.trim()).filter(Boolean);
    tags.forEach(tag=>{
      const span=document.createElement('div');
      span.className='modal-amenity';
      span.innerHTML=`<span>${getAmenityIcon(tag)}</span>${tag}`;
      amenDiv.appendChild(span);
    });
    amenSec.style.display='block';
  }else{
    amenSec.style.display='none';
  }

  // Description
  const descSec=document.getElementById('m_desc_section');
  const descDiv=document.getElementById('m_desc');
  if(room.description&&room.description.trim()){
    descDiv.textContent=room.description;
    descSec.style.display='block';
  }else{
    descSec.style.display='none';
  }

  // Inquire button
  document.getElementById('m_inquire_btn').onclick=function(){
    closeModal();
    inquireAbout(room.room_number,room.room_type.toLowerCase());
  };

  document.getElementById('roomModal').classList.add('open');
  document.body.style.overflow='hidden';
}
function closeModal(){
  document.getElementById('roomModal').classList.remove('open');
  document.body.style.overflow='';
}

// ── Inquire about room (pre-fill form) ───────────────────────
function inquireAbout(roomNum,roomType){
  // Navigate to inquiry section with room pre-filled
  window.location.href='inquiry.php?room='+encodeURIComponent(roomNum)+'&room_type='+encodeURIComponent(roomType)+'#inquire';
}

// ── Scroll animations ────────────────────────────────────────
const obs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');}});
},{threshold:.08});
document.querySelectorAll('.fade-up').forEach(el=>obs.observe(el));

// ── Keyboard: close modal on Escape ─────────────────────────
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
</script>
</body>
</html>