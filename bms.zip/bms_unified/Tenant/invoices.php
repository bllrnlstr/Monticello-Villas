<?php
session_start();
if (!isset($_SESSION['tenant_id'])) { header("Location: index.php"); exit(); }

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';

$pdo         = getDB();
$tenant_id   = $_SESSION['tenant_id'];
$tenant_name = $_SESSION['tenant_name'];
$tenant_room = $_SESSION['tenant_room'];

$initials = '';
foreach (explode(' ', $tenant_name) as $part) {
    if ($part !== '') $initials .= strtoupper($part[0]);
}

$filter_status = $_GET['status'] ?? '';
$filter_year   = $_GET['year']   ?? date('Y');
$filter_month  = $_GET['month']  ?? '';

$sql    = "SELECT p.*, r.room_number FROM payments p LEFT JOIN rooms r ON r.id=p.room_id WHERE p.tenant_id=?";
$params = [$tenant_id];
if ($filter_status) { $sql .= " AND p.status=?";          $params[] = $filter_status; }
if ($filter_year)   { $sql .= " AND YEAR(p.due_date)=?";  $params[] = (int)$filter_year; }
if ($filter_month)  { $sql .= " AND MONTH(p.due_date)=?"; $params[] = (int)$filter_month; }
$sql .= " ORDER BY p.due_date DESC, p.id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$invoices = [];
foreach ($stmt->fetchAll() as $row) {
    $row['display_status'] = $row['paid_at'] ? 'paid' : ((new DateTime($row['due_date']) < new DateTime()) ? 'overdue' : 'pending');
    $row['payment_date']   = $row['paid_at'] ? date('Y-m-d', strtotime($row['paid_at'])) : null;
    $row['method']         = $row['payment_method'] ?? null;
    $invoices[] = $row;
}

$sum = $pdo->prepare("SELECT COUNT(*) AS total_invoices, COALESCE(SUM(CASE WHEN status='paid' THEN amount ELSE 0 END),0) AS total_paid, COALESCE(SUM(CASE WHEN status IN ('pending','overdue') THEN amount ELSE 0 END),0) AS total_due, COALESCE(SUM(amount),0) AS total_amount FROM payments WHERE tenant_id=?");
$sum->execute([$tenant_id]);
$summary = $sum->fetch();

$yrq = $pdo->prepare("SELECT DISTINCT YEAR(due_date) AS year FROM payments WHERE tenant_id=? ORDER BY year DESC");
$yrq->execute([$tenant_id]);
$available_years = array_column($yrq->fetchAll(), 'year');
if (!in_array((int)date('Y'), $available_years)) array_unshift($available_years, (int)date('Y'));

function getInvoiceNumber(int $id, string $date): string {
    return 'INV-' . date('Ym', strtotime($date)) . '-' . str_pad($id, 4, '0', STR_PAD_LEFT);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Invoices — Monticello TMS</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
  --bg:#080d1a;--surface:#0d1424;--surface-2:#111827;--surface-3:#1a2235;
  --accent:#2563eb;--accent-lt:#3b82f6;--accent-gl:rgba(37,99,235,0.15);
  --ok:#10b981;--warn:#f59e0b;--err:#ef4444;
  --silver:#94a3b8;--light:#cbd5e1;--white:#f1f5f9;
  --border:rgba(255,255,255,0.07);--border-2:rgba(255,255,255,0.04);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--light);display:flex;min-height:100vh;}

/* SIDEBAR */
.sidebar{width:240px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;height:100vh;z-index:100;}
.sb-logo{padding:1.6rem 1.4rem;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:.7rem;}
.sb-mark{width:32px;height:32px;background:var(--accent);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:.9rem;flex-shrink:0;}
.sb-name{font-family:'Syne',sans-serif;font-size:.9rem;font-weight:700;color:var(--white);}
.sb-name small{display:block;font-size:.58rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:.1em;text-transform:uppercase;margin-top:1px;}
.sb-nav{flex:1;padding:1rem .75rem;overflow-y:auto;}
.nav-section-label{font-size:.58rem;font-weight:700;text-transform:uppercase;letter-spacing:.14em;color:rgba(148,163,184,.45);padding:.6rem .65rem .4rem;margin-top:.5rem;}
.nav-link{display:flex;align-items:center;gap:.7rem;padding:.62rem .75rem;border-radius:5px;font-size:.82rem;font-weight:500;color:var(--silver);text-decoration:none;transition:all .18s;margin-bottom:2px;}
.nav-link:hover{background:rgba(255,255,255,.05);color:var(--white);}
.nav-link.active{background:var(--accent-gl);color:var(--accent-lt);border-left:2px solid var(--accent);padding-left:calc(.75rem - 2px);}
.nav-link i{width:16px;font-size:.8rem;opacity:.8;}
.nav-link.active i{opacity:1;}
.sb-user{padding:1rem 1.1rem;border-top:1px solid var(--border);}
.sb-user-row{display:flex;align-items:center;gap:.7rem;margin-bottom:.75rem;}
.sb-avatar{width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,var(--accent),#1d4ed8);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:.8rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user-name{font-size:.82rem;font-weight:600;color:var(--white);}
.sb-user-room{font-size:.68rem;color:var(--silver);margin-top:1px;}
.logout-btn{width:100%;padding:.55rem;background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.18);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:.76rem;font-weight:600;color:#fca5a5;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:.5rem;}
.logout-btn:hover{background:rgba(239,68,68,.14);}

/* MAIN */
.main{margin-left:240px;flex:1;min-height:100vh;display:flex;flex-direction:column;}
.topbar{background:var(--surface);border-bottom:1px solid var(--border);padding:0 2rem;height:58px;display:flex;align-items:center;position:sticky;top:0;z-index:50;}
.back-link{width:32px;height:32px;background:var(--border-2);border:1px solid var(--border);border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:.75rem;color:var(--silver);text-decoration:none;transition:all .18s;margin-right:1rem;flex-shrink:0;}
.back-link:hover{background:var(--accent-gl);border-color:rgba(37,99,235,.25);color:var(--accent-lt);}
.topbar-title h1{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);}
.topbar-title p{font-size:.72rem;color:var(--silver);margin-top:1px;}
.content{padding:1.75rem 2rem;flex:1;}

/* STAT CARDS */
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:1rem;margin-bottom:1.5rem;}
.stat-card{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:1.25rem;}
.stat-icon{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;margin-bottom:.85rem;}
.stat-icon.blue  {background:rgba(37,99,235,.15);color:var(--accent-lt);}
.stat-icon.green {background:rgba(16,185,129,.12);color:var(--ok);}
.stat-icon.yellow{background:rgba(245,158,11,.12);color:var(--warn);}
.stat-icon.purple{background:rgba(139,92,246,.12);color:#a78bfa;}
.stat-label{font-size:.68rem;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--silver);margin-bottom:.4rem;}
.stat-value{font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:700;color:var(--white);}

/* FILTERS */
.filters-panel{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:1rem 1.25rem;margin-bottom:1.25rem;display:flex;gap:1rem;align-items:flex-end;flex-wrap:wrap;}
.filter-group{display:flex;flex-direction:column;gap:.35rem;}
.filter-label{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.09em;color:var(--silver);}
.filter-select{padding:.55rem .85rem;background:var(--surface-2);border:1px solid var(--border);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:.82rem;color:var(--white);cursor:pointer;outline:none;transition:border-color .2s;}
.filter-select:focus{border-color:var(--accent);}
.filter-select option{background:var(--surface-2);}
.btn-filter{padding:.55rem 1.1rem;background:var(--accent);color:#fff;border:none;border-radius:5px;font-family:'DM Sans',sans-serif;font-size:.82rem;font-weight:600;cursor:pointer;display:flex;align-items:center;gap:.4rem;transition:all .2s;}
.btn-filter:hover{background:#1d4ed8;}
.btn-clear{padding:.55rem 1rem;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:.82rem;color:var(--silver);cursor:pointer;text-decoration:none;display:flex;align-items:center;gap:.4rem;transition:all .2s;}
.btn-clear:hover{background:rgba(255,255,255,.08);color:var(--white);}

/* TABLE PANEL */
.panel{background:var(--surface);border:1px solid var(--border);border-radius:8px;overflow:hidden;}
.panel-head{padding:1rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;}
.panel-title{font-family:'Syne',sans-serif;font-size:.9rem;font-weight:700;color:var(--white);}
.panel-count{font-size:.75rem;color:var(--silver);}
table{width:100%;border-collapse:collapse;}
thead th{text-align:left;padding:.75rem 1rem;font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.09em;color:var(--silver);border-bottom:1px solid var(--border);background:var(--surface-3);white-space:nowrap;}
tbody tr{border-bottom:1px solid var(--border-2);transition:background .15s;}
tbody tr:hover{background:rgba(255,255,255,.025);}
tbody tr:last-child{border-bottom:none;}
td{padding:.85rem 1rem;font-size:.82rem;color:var(--light);vertical-align:middle;}
.inv-no{font-weight:700;color:var(--accent-lt);font-size:.8rem;}
.inv-date{font-size:.75rem;color:var(--silver);}
.inv-amount{font-family:'Syne',sans-serif;font-weight:700;color:var(--white);}

/* BADGES */
.badge{display:inline-flex;align-items:center;gap:.3rem;padding:.22rem .65rem;border-radius:3px;font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;}
.badge::before{content:'';width:4px;height:4px;border-radius:50%;background:currentColor;}
.badge-paid   {background:rgba(16,185,129,.1); color:var(--ok);  border:1px solid rgba(16,185,129,.2);}
.badge-pending{background:rgba(245,158,11,.1); color:var(--warn);border:1px solid rgba(245,158,11,.2);}
.badge-overdue{background:rgba(239,68,68,.1);  color:var(--err); border:1px solid rgba(239,68,68,.2);}

/* ACTION BUTTONS */
.btn-view{padding:.4rem .85rem;background:var(--accent-gl);border:1px solid rgba(37,99,235,.25);border-radius:4px;color:var(--accent-lt);font-size:.75rem;font-weight:600;cursor:pointer;font-family:'DM Sans',sans-serif;transition:all .2s;}
.btn-view:hover{background:rgba(37,99,235,.25);}
.btn-print{padding:.4rem .75rem;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:4px;color:var(--silver);font-size:.75rem;cursor:pointer;font-family:'DM Sans',sans-serif;transition:all .2s;}
.btn-print:hover{background:rgba(255,255,255,.08);color:var(--white);}

/* EMPTY */
.empty-state{text-align:center;padding:4rem 1rem;color:var(--silver);}
.empty-icon{font-size:2.5rem;opacity:.15;display:block;margin-bottom:.75rem;}
.empty-title{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--light);margin-bottom:.4rem;}

/* MODAL */
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.75);z-index:9999;align-items:center;justify-content:center;padding:20px;}
.modal.active{display:flex;}
.modal-content{background:var(--surface);border:1px solid var(--border);border-radius:12px;max-width:640px;width:100%;max-height:90vh;overflow-y:auto;box-shadow:0 25px 60px rgba(0,0,0,.5);}
.modal-header{padding:1.25rem 1.5rem;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;}
.modal-title-text{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);}
.modal-close{width:30px;height:30px;background:rgba(255,255,255,.05);border:1px solid var(--border);border-radius:5px;cursor:pointer;font-size:.9rem;color:var(--silver);display:flex;align-items:center;justify-content:center;}
.modal-close:hover{background:rgba(255,255,255,.1);color:var(--white);}
.modal-body{padding:1.5rem;}
.modal-inv-header{background:linear-gradient(135deg,var(--accent),#1d4ed8);padding:1.5rem;border-radius:8px;color:#fff;margin-bottom:1.5rem;}
.modal-inv-logo{font-size:.9rem;font-weight:700;margin-bottom:.75rem;opacity:.9;}
.modal-inv-no{font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:800;margin-bottom:.25rem;}
.modal-inv-date{font-size:.78rem;opacity:.8;}
.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1.25rem;}
.detail-item-label{font-size:.62rem;font-weight:600;text-transform:uppercase;letter-spacing:.08em;color:var(--silver);margin-bottom:.3rem;}
.detail-item-value{font-size:.88rem;font-weight:600;color:var(--white);}
.detail-table{width:100%;border-collapse:collapse;margin-bottom:1rem;}
.detail-table th{padding:.6rem .75rem;text-align:left;font-size:.62rem;font-weight:700;text-transform:uppercase;color:var(--silver);background:var(--surface-3);border-bottom:1px solid var(--border);}
.detail-table td{padding:.75rem .75rem;border-bottom:1px solid var(--border-2);font-size:.82rem;color:var(--light);}
.total-row{background:var(--surface-3);border:1px solid var(--border);padding:1rem 1.25rem;border-radius:8px;display:flex;justify-content:space-between;align-items:center;}
.total-label{font-size:.88rem;font-weight:600;color:var(--light);}
.total-amount{font-family:'Syne',sans-serif;font-size:1.6rem;font-weight:800;color:var(--accent-lt);}
.pay-info{margin-top:1.25rem;padding:1rem;background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.2);border-radius:8px;}
.pay-info-title{font-size:.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.09em;color:var(--ok);margin-bottom:.75rem;}
.modal-footer{padding:1rem 1.5rem;border-top:1px solid var(--border);display:flex;gap:.75rem;justify-content:flex-end;}

@media(max-width:768px){.sidebar{display:none;}.main{margin-left:0;}.stats-grid{grid-template-columns:1fr 1fr;}.filters-panel{flex-direction:column;align-items:stretch;} table{display:block;overflow-x:auto;}}
@media print{.sidebar,.topbar,.filters-panel,.modal-footer{display:none!important;}.modal{display:flex!important;position:static;background:none;padding:0;}.modal-content{box-shadow:none;max-height:none;border:none;}}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <div class="sb-mark">⬡</div>
    <div class="sb-name">Monticello <small>Tenant Portal</small></div>
  </div>
  <nav class="sb-nav">
    <div class="nav-section-label">Main</div>
    <a href="dashboard.php" class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
    <a href="payments.php"  class="nav-link"><i class="fas fa-credit-card"></i> Payments</a>
    <div class="nav-section-label">Account</div>
    <a href="invoices.php"    class="nav-link active"><i class="fas fa-file-invoice"></i> Invoices</a>
    <a href="maintenance.php" class="nav-link"><i class="fas fa-tools"></i> Maintenance</a>
    <a href="communications.php" class="nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="profile.php"     class="nav-link"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sb-user">
    <div class="sb-user-row">
      <div class="sb-avatar"><?php echo htmlspecialchars($initials); ?></div>
      <div>
        <div class="sb-user-name"><?php echo htmlspecialchars($tenant_name); ?></div>
        <div class="sb-user-room">Room <?php echo htmlspecialchars($tenant_room); ?></div>
      </div>
    </div>
    <form method="POST" action="logout.php" style="margin:0;">
      <button type="submit" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Sign Out</button>
    </form>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i></a>
    <div class="topbar-title">
      <h1>My Invoices</h1>
      <p>View and manage your billing history</p>
    </div>
  </div>

  <div class="content">

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card"><div class="stat-icon blue"><i class="fas fa-file-invoice-dollar"></i></div><div class="stat-label">Total Invoices</div><div class="stat-value"><?php echo (int)$summary['total_invoices']; ?></div></div>
      <div class="stat-card"><div class="stat-icon green"><i class="fas fa-check-circle"></i></div><div class="stat-label">Total Paid</div><div class="stat-value">₱<?php echo number_format($summary['total_paid'],2); ?></div></div>
      <div class="stat-card"><div class="stat-icon yellow"><i class="fas fa-clock"></i></div><div class="stat-label">Amount Due</div><div class="stat-value">₱<?php echo number_format($summary['total_due'],2); ?></div></div>
      <div class="stat-card"><div class="stat-icon purple"><i class="fas fa-chart-line"></i></div><div class="stat-label">Total Amount</div><div class="stat-value">₱<?php echo number_format($summary['total_amount'],2); ?></div></div>
    </div>

    <!-- Filters -->
    <div class="filters-panel">
      <div class="filter-group">
        <label class="filter-label">Status</label>
        <select class="filter-select" id="f-status">
          <option value="">All Statuses</option>
          <option value="paid"    <?php echo $filter_status==='paid'   ?'selected':''; ?>>Paid</option>
          <option value="pending" <?php echo $filter_status==='pending'?'selected':''; ?>>Pending</option>
          <option value="overdue" <?php echo $filter_status==='overdue'?'selected':''; ?>>Overdue</option>
        </select>
      </div>
      <div class="filter-group">
        <label class="filter-label">Year</label>
        <select class="filter-select" id="f-year">
          <?php foreach ($available_years as $y): ?>
          <option value="<?php echo $y; ?>" <?php echo $filter_year==$y?'selected':''; ?>><?php echo $y; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="filter-group">
        <label class="filter-label">Month</label>
        <select class="filter-select" id="f-month">
          <option value="">All Months</option>
          <?php for ($m=1;$m<=12;$m++): ?>
          <option value="<?php echo $m; ?>" <?php echo $filter_month==$m?'selected':''; ?>><?php echo date('F',mktime(0,0,0,$m,1)); ?></option>
          <?php endfor; ?>
        </select>
      </div>
      <button class="btn-filter" onclick="applyFilters()"><i class="fas fa-filter"></i> Apply</button>
      <a href="invoices.php" class="btn-clear"><i class="fas fa-times"></i> Clear</a>
    </div>

    <!-- Table -->
    <div class="panel">
      <div class="panel-head">
        <span class="panel-title">Invoice History</span>
        <span class="panel-count"><?php echo count($invoices); ?> invoice<?php echo count($invoices)!==1?'s':''; ?></span>
      </div>

      <?php if (count($invoices) > 0): ?>
      <table>
        <thead>
          <tr><th>Invoice #</th><th>Issued</th><th>Due Date</th><th>Description</th><th>Amount</th><th>Status</th><th>Actions</th></tr>
        </thead>
        <tbody>
        <?php foreach ($invoices as $inv): ?>
        <tr>
          <td><div class="inv-no"><?php echo getInvoiceNumber((int)$inv['id'],$inv['due_date']); ?></div></td>
          <td><div class="inv-date"><?php echo date('M j, Y',strtotime($inv['created_at'])); ?></div></td>
          <td><div class="inv-date"><?php echo date('M j, Y',strtotime($inv['due_date'])); ?></div></td>
          <td><?php echo ucfirst(htmlspecialchars($inv['type']??'rent')); ?> — Room <?php echo htmlspecialchars($inv['room_number']??$tenant_room); ?></td>
          <td><div class="inv-amount">₱<?php echo number_format($inv['amount'],2); ?></div></td>
          <td><span class="badge badge-<?php echo $inv['display_status']; ?>"><?php echo ucfirst($inv['display_status']); ?></span></td>
          <td style="white-space:nowrap;display:flex;gap:6px;">
            <button class="btn-view" onclick='viewInvoice(<?php echo json_encode($inv,JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP); ?>)'><i class="fas fa-eye"></i> View</button>
            <button class="btn-print" onclick="window.print()" title="Print"><i class="fas fa-print"></i></button>
          </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php else: ?>
      <div class="empty-state">
        <i class="fas fa-file-invoice empty-icon"></i>
        <div class="empty-title">No Invoices Found</div>
        <p>No invoices match the selected filters.</p>
      </div>
      <?php endif; ?>
    </div>

  </div>
</div>

<!-- Modal -->
<div class="modal" id="invoiceModal">
  <div class="modal-content">
    <div class="modal-header">
      <span class="modal-title-text">Invoice Details</span>
      <button class="modal-close" onclick="closeModal()"><i class="fas fa-times"></i></button>
    </div>
    <div class="modal-body">
      <div class="modal-inv-header">
        <div class="modal-inv-logo"><i class="fas fa-home"></i> Monticello Boarding House</div>
        <div class="modal-inv-no" id="m-invno"></div>
        <div class="modal-inv-date" id="m-invdate"></div>
      </div>
      <div class="detail-grid">
        <div><div class="detail-item-label">Invoice Number</div><div class="detail-item-value" id="m-number"></div></div>
        <div><div class="detail-item-label">Date Issued</div><div class="detail-item-value" id="m-issued"></div></div>
        <div><div class="detail-item-label">Due Date</div><div class="detail-item-value" id="m-due"></div></div>
        <div><div class="detail-item-label">Status</div><div class="detail-item-value" id="m-status"></div></div>
      </div>
      <table class="detail-table">
        <thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th style="text-align:right">Amount</th></tr></thead>
        <tbody id="m-items"></tbody>
      </table>
      <div class="total-row">
        <div class="total-label">Total Amount</div>
        <div class="total-amount" id="m-total"></div>
      </div>
      <div class="pay-info" id="m-payinfo" style="display:none">
        <div class="pay-info-title"><i class="fas fa-check-circle"></i> Payment Confirmed</div>
        <div class="detail-grid" style="margin-bottom:0">
          <div><div class="detail-item-label">Payment Date</div><div class="detail-item-value" id="m-paydate"></div></div>
          <div><div class="detail-item-label">Method</div><div class="detail-item-value" id="m-paymethod"></div></div>
        </div>
      </div>
    </div>
    <div class="modal-footer">
      <button class="btn-print" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
      <button class="btn-view" onclick="closeModal()">Close</button>
    </div>
  </div>
</div>

<script>
function applyFilters(){
  const p=new URLSearchParams();
  const s=document.getElementById('f-status').value,y=document.getElementById('f-year').value,m=document.getElementById('f-month').value;
  if(s)p.set('status',s);if(y)p.set('year',y);if(m)p.set('month',m);
  window.location.href='invoices.php?'+p.toString();
}
function viewInvoice(inv){
  const pad=n=>String(n).padStart(4,'0');
  const ym=inv.due_date.substring(0,7).replace('-','');
  const no='INV-'+ym+'-'+pad(inv.id);
  document.getElementById('m-invno').textContent=no;
  document.getElementById('m-invdate').textContent='Issued: '+fmt(inv.created_at);
  document.getElementById('m-number').textContent=no;
  document.getElementById('m-issued').textContent=fmt(inv.created_at);
  document.getElementById('m-due').textContent=fmt(inv.due_date);
  const sc={paid:'badge-paid',pending:'badge-pending',overdue:'badge-overdue'};
  document.getElementById('m-status').innerHTML='<span class="badge '+(sc[inv.display_status]||'badge-pending')+'">'+inv.display_status+'</span>';
  const money=v=>parseFloat(v).toLocaleString('en-PH',{minimumFractionDigits:2});
  const desc=(inv.type?inv.type.charAt(0).toUpperCase()+inv.type.slice(1):'Rent')+' — Room '+(inv.room_number||'');
  document.getElementById('m-items').innerHTML='<tr><td>'+esc(desc)+'</td><td>1</td><td>₱'+money(inv.amount)+'</td><td style="text-align:right">₱'+money(inv.amount)+'</td></tr>';
  document.getElementById('m-total').textContent='₱'+money(inv.amount);
  if(inv.payment_date){
    document.getElementById('m-payinfo').style.display='block';
    document.getElementById('m-paydate').textContent=fmt(inv.payment_date);
    document.getElementById('m-paymethod').textContent=inv.method||'—';
  } else {
    document.getElementById('m-payinfo').style.display='none';
  }
  document.getElementById('invoiceModal').classList.add('active');
}
function closeModal(){document.getElementById('invoiceModal').classList.remove('active');}
function fmt(d){if(!d)return'—';return new Date(d.replace(' ','T')).toLocaleDateString('en-US',{year:'numeric',month:'short',day:'numeric'});}
function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
document.getElementById('invoiceModal').addEventListener('click',function(e){if(e.target===this)closeModal();});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal();});
</script>
</body>
</html>