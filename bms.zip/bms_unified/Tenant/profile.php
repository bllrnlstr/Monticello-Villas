<?php
session_start();
if(isset($_SESSION["tenant_time"]) && (time()-$_SESSION["tenant_time"])>7200){session_destroy();header("Location: index.php");exit();}
$_SESSION["tenant_time"]=time();

if (!isset($_SESSION['tenant_id'])) {
    header("Location: index.php");
    exit();
}

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
$pdo = getDB();

$tenant_id   = $_SESSION['tenant_id'];
$tenant_name = $_SESSION['tenant_name'];
$tenant_room = $_SESSION['tenant_room'];

$initials = '';
foreach (explode(' ', $tenant_name) as $p) {
    if ($p !== '') $initials .= strtoupper($p[0]);
}

$success_message = '';
$error_message   = '';

// ── Handle: update profile info ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    $full_name         = trim($_POST['full_name']         ?? '');
    $phone             = trim($_POST['phone']             ?? '');
    $address           = trim($_POST['address']           ?? '');
    $room_number       = trim($_POST['room_number']       ?? '');
    $emergency_contact = trim($_POST['emergency_contact'] ?? '');
    $emergency_phone   = trim($_POST['emergency_phone']   ?? '');

    if (!$full_name || !$phone || !$address || !$room_number || !$emergency_contact || !$emergency_phone) {
        $error_message = 'All fields are required.';
    } else {
        $upd = $pdo->prepare("
            UPDATE tenants
            SET full_name = ?, phone = ?, address = ?, room_number = ?,
                emergency_contact = ?, emergency_phone = ?
            WHERE id = ?
        ");
        if ($upd->execute([$full_name, $phone, $address, $room_number, $emergency_contact, $emergency_phone, $tenant_id])) {
            // Update session name
            $_SESSION['tenant_name'] = $full_name;
            $_SESSION['tenant_room'] = $room_number;
            $tenant_name             = $full_name;
            $tenant_room             = $room_number;
            // Recalculate initials
            $initials = '';
            foreach (explode(' ', $full_name) as $p) {
                if ($p !== '') $initials .= strtoupper($p[0]);
            }
            $success_message = 'Profile updated successfully.';
        } else {
            $error_message = 'Could not update profile. Please try again.';
        }
    }
}

// ── Handle: change password ───────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $current_password  = $_POST['current_password']  ?? '';
    $new_password      = $_POST['new_password']      ?? '';
    $confirm_password  = $_POST['confirm_password']  ?? '';

    if (!$current_password || !$new_password || !$confirm_password) {
        $error_message = 'All password fields are required.';
    } elseif (strlen($new_password) < 6) {
        $error_message = 'New password must be at least 6 characters.';
    } elseif ($new_password !== $confirm_password) {
        $error_message = 'New passwords do not match.';
    } else {
        $stmt = $pdo->prepare("SELECT password_hash FROM tenants WHERE id = ?");
        $stmt->execute([$tenant_id]);
        $row = $stmt->fetch();

        if (!password_verify($current_password, $row['password_hash'])) {
            $error_message = 'Current password is incorrect.';
        } else {
            $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
            $upd = $pdo->prepare("UPDATE tenants SET password_hash = ? WHERE id = ?");
            if ($upd->execute([$new_hash, $tenant_id])) {
                $success_message = 'Password changed successfully.';
            } else {
                $error_message = 'Could not change password. Please try again.';
            }
        }
    }
}

// ── Fetch current profile ─────────────────────────────────────────────────
$stmt = $pdo->prepare("SELECT * FROM tenants WHERE id = ? LIMIT 1");
$stmt->execute([$tenant_id]);
$profile = $stmt->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profile — Monticello TMS</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root {
  --bg:#080d1a;--surface:#0d1424;--surface-2:#111827;--accent:#2563eb;--accent-lt:#3b82f6;
  --accent-gl:rgba(37,99,235,0.15);--ok:#10b981;--warn:#f59e0b;--err:#ef4444;
  --silver:#94a3b8;--light:#cbd5e1;--white:#f1f5f9;
  --border:rgba(255,255,255,0.07);--border-2:rgba(255,255,255,0.04);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--light);display:flex;min-height:100vh;}

/* SIDEBAR */
.sidebar{width:240px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;height:100vh;z-index:100;}
.sb-logo{padding:1.6rem 1.4rem;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:0.7rem;}
.sb-mark{width:32px;height:32px;background:var(--accent);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:0.9rem;flex-shrink:0;}
.sb-name{font-family:'Syne',sans-serif;font-size:0.9rem;font-weight:700;color:var(--white);}
.sb-name small{display:block;font-size:0.58rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:0.1em;text-transform:uppercase;margin-top:1px;}
.sb-nav{flex:1;padding:1rem 0.75rem;overflow-y:auto;}
.nav-section-label{font-size:0.58rem;font-weight:700;text-transform:uppercase;letter-spacing:0.14em;color:rgba(148,163,184,0.45);padding:0.6rem 0.65rem 0.4rem;margin-top:0.5rem;}
.nav-link{display:flex;align-items:center;gap:0.7rem;padding:0.62rem 0.75rem;border-radius:5px;font-size:0.82rem;font-weight:500;color:var(--silver);text-decoration:none;transition:all 0.18s;margin-bottom:2px;}
.nav-link:hover{background:rgba(255,255,255,0.05);color:var(--white);}
.nav-link.active{background:var(--accent-gl);color:var(--accent-lt);border-left:2px solid var(--accent);padding-left:calc(0.75rem - 2px);}
.nav-link i{width:16px;font-size:0.8rem;opacity:0.8;}
.nav-link.active i{opacity:1;}
.sb-user{padding:1rem 1.1rem;border-top:1px solid var(--border);}
.sb-user-row{display:flex;align-items:center;gap:0.7rem;margin-bottom:0.75rem;}
.sb-avatar{width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,var(--accent),#1d4ed8);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:0.8rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user-name{font-size:0.82rem;font-weight:600;color:var(--white);}
.sb-user-room{font-size:0.68rem;color:var(--silver);margin-top:1px;}
.logout-btn{width:100%;padding:0.55rem;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.18);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:0.76rem;font-weight:600;color:#fca5a5;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;}
.logout-btn:hover{background:rgba(239,68,68,0.14);border-color:rgba(239,68,68,0.3);}

/* MAIN */
.main{margin-left:240px;flex:1;min-height:100vh;}
.topbar{background:var(--surface);border-bottom:1px solid var(--border);padding:0 2rem;height:58px;display:flex;align-items:center;position:sticky;top:0;z-index:50;}
.topbar-left{display:flex;align-items:center;gap:1rem;}
.back-link{width:32px;height:32px;background:var(--border-2);border:1px solid var(--border);border-radius:5px;display:flex;align-items:center;justify-content:center;font-size:0.75rem;color:var(--silver);text-decoration:none;transition:all 0.18s;}
.back-link:hover{background:var(--accent-gl);border-color:rgba(37,99,235,0.25);color:var(--accent-lt);}
.topbar-title h1{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);}
.topbar-title p{font-size:0.72rem;color:var(--silver);margin-top:1px;}
.content{padding:1.75rem 2rem;max-width:1100px;}

/* Alerts */
.alert{display:flex;align-items:center;gap:0.6rem;padding:0.75rem 1rem;border-radius:5px;font-size:0.8rem;margin-bottom:1.5rem;border-left:3px solid;}
.alert-ok {background:rgba(16,185,129,0.07);border-color:var(--ok); color:#6ee7b7;}
.alert-err{background:rgba(239,68,68,0.07); border-color:var(--err);color:#fca5a5;}

/* Profile header card */
.profile-header{background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:1.75rem;margin-bottom:1.5rem;display:flex;align-items:center;gap:1.5rem;}
.profile-avatar{width:64px;height:64px;border-radius:14px;background:linear-gradient(135deg,var(--accent),#1d4ed8);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:800;color:#fff;flex-shrink:0;}
.profile-meta{}
.profile-name{font-family:'Syne',sans-serif;font-size:1.25rem;font-weight:700;color:var(--white);line-height:1.2;margin-bottom:0.3rem;}
.profile-email{font-size:0.8rem;color:var(--silver);margin-bottom:0.5rem;}
.profile-badges{display:flex;gap:0.5rem;flex-wrap:wrap;}
.badge{display:inline-flex;align-items:center;gap:0.3rem;padding:0.22rem 0.65rem;border-radius:3px;font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.08em;background:var(--accent-gl);color:var(--accent-lt);border:1px solid rgba(37,99,235,0.22);}
.badge-room{background:rgba(16,185,129,0.08);color:var(--ok);border-color:rgba(16,185,129,0.2);}
.badge-since{background:rgba(255,255,255,0.04);color:var(--silver);border-color:var(--border);}

/* Layout */
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;}

/* Panels */
.panel{background:var(--surface);border:1px solid var(--border);border-radius:8px;overflow:hidden;}
.panel-head{padding:1rem 1.25rem;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:0.55rem;}
.panel-title{font-family:'Syne',sans-serif;font-size:0.82rem;font-weight:700;color:var(--white);letter-spacing:0.02em;display:flex;align-items:center;gap:0.55rem;}
.panel-title i{font-size:0.75rem;color:var(--accent-lt);}
.panel-body{padding:1.25rem;}

/* Form */
.row-2{display:grid;grid-template-columns:1fr 1fr;gap:0.75rem;}
.field{display:flex;flex-direction:column;gap:0.3rem;margin-bottom:0.85rem;}
.field:last-of-type{margin-bottom:0;}
.field label{font-size:0.65rem;font-weight:700;text-transform:uppercase;letter-spacing:0.09em;color:var(--silver);}

.input-wrap{position:relative;}
.input-wrap .ico{position:absolute;left:0.75rem;top:50%;transform:translateY(-50%);font-size:0.72rem;color:rgba(148,163,184,0.4);pointer-events:none;}
.input-wrap input{padding-left:2.2rem;}

.field input{width:100%;padding:0.68rem 0.9rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.09);border-radius:4px;font-family:'DM Sans',sans-serif;font-size:0.875rem;color:var(--white);outline:none;transition:border-color 0.2s,box-shadow 0.2s;}
.field input::placeholder{color:rgba(148,163,184,0.35);}
.field input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-gl);}
.field input[readonly]{background:rgba(255,255,255,0.02);color:var(--silver);cursor:not-allowed;border-color:rgba(255,255,255,0.05);}

.field-hint{font-size:0.68rem;color:rgba(148,163,184,0.5);margin-top:0.25rem;}

/* Section separator */
.sec-label{font-size:0.6rem;font-weight:700;text-transform:uppercase;letter-spacing:0.15em;color:var(--accent-lt);margin:1.1rem 0 0.75rem;display:flex;align-items:center;gap:0.55rem;}
.sec-label::after{content:'';flex:1;height:1px;background:var(--border);}

/* Eye toggle */
.eye-btn{position:absolute;right:0.7rem;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:0.72rem;color:var(--silver);padding:2px;transition:color 0.2s;}
.eye-btn:hover{color:var(--accent-lt);}

/* Buttons */
.btn-primary{width:100%;padding:0.8rem;background:var(--accent);color:#fff;border:none;border-radius:4px;font-family:'Syne',sans-serif;font-size:0.86rem;font-weight:600;letter-spacing:0.04em;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-top:1.1rem;}
.btn-primary:hover{background:#1d4ed8;box-shadow:0 5px 16px var(--accent-gl);}

.btn-danger{width:100%;padding:0.8rem;background:rgba(239,68,68,0.1);color:#fca5a5;border:1px solid rgba(239,68,68,0.25);border-radius:4px;font-family:'Syne',sans-serif;font-size:0.86rem;font-weight:600;letter-spacing:0.04em;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;margin-top:0.6rem;}
.btn-danger:hover{background:rgba(239,68,68,0.18);border-color:rgba(239,68,68,0.4);}

/* Password strength bar */
.strength-bar{height:3px;border-radius:2px;background:var(--border);margin-top:0.4rem;overflow:hidden;}
.strength-fill{height:100%;border-radius:2px;width:0%;transition:width 0.3s,background 0.3s;}

/* Read-only info rows (right column top) */
.info-row{display:flex;align-items:center;justify-content:space-between;padding:0.62rem 0;border-bottom:1px solid var(--border-2);}
.info-row:last-child{border-bottom:none;}
.ir-key{font-size:0.7rem;font-weight:600;text-transform:uppercase;letter-spacing:0.08em;color:var(--silver);}
.ir-val{font-size:0.82rem;font-weight:500;color:var(--white);text-align:right;}

@media(max-width:960px){.two-col{grid-template-columns:1fr;}.row-2{grid-template-columns:1fr;}}
@media(max-width:720px){.sidebar{width:100%;height:auto;position:relative;}.main{margin-left:0;}.profile-header{flex-direction:column;align-items:flex-start;}}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <div class="sb-mark">⬡</div>
    <div class="sb-name">Monticello <small>Tenant Portal</small></div>
  </div>
  <nav class="sb-nav">
    <div class="nav-section-label">Main</div>
    <a href="dashboard.php" class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
    <a href="payments.php"  class="nav-link"><i class="fas fa-credit-card"></i> Payments</a>
    <div class="nav-section-label">Account</div>
    <a href="invoices.php" class="nav-link"><i class="fas fa-file-invoice"></i> Invoices</a>
    <a href="maintenance.php" class="nav-link"><i class="fas fa-tools"></i> Maintenance</a>
    <a href="communications.php" class="nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="profile.php" class="nav-link active"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sb-user">
    <div class="sb-user-row">
      <div class="sb-avatar"><?php echo htmlspecialchars($initials); ?></div>
      <div>
        <div class="sb-user-name"><?php echo htmlspecialchars($tenant_name); ?></div>
        <div class="sb-user-room">Room <?php echo htmlspecialchars($tenant_room); ?></div>
      </div>
    </div>
    <form method="POST" action="logout.php" style="margin:0;">
      <button type="submit" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Sign Out</button>
    </form>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <a href="dashboard.php" class="back-link"><i class="fas fa-arrow-left"></i></a>
      <div class="topbar-title">
        <h1>My Profile</h1>
        <p>Manage your account information</p>
      </div>
    </div>
  </div>

  <div class="content">

    <?php if ($success_message): ?>
    <div class="alert alert-ok"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?></div>
    <?php endif; ?>
    <?php if ($error_message): ?>
    <div class="alert alert-err"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?></div>
    <?php endif; ?>

    <!-- Profile Header -->
    <div class="profile-header">
      <div class="profile-avatar"><?php echo htmlspecialchars($initials); ?></div>
      <div class="profile-meta">
        <div class="profile-name"><?php echo htmlspecialchars($profile['full_name']); ?></div>
        <div class="profile-email"><?php echo htmlspecialchars($profile['email']); ?></div>
        <div class="profile-badges">
          <span class="badge"><i class="fas fa-door-open"></i> Room <?php echo htmlspecialchars($profile['room_number'] ?? '—'); ?></span>
          <span class="badge badge-since"><i class="fas fa-calendar"></i> Member since <?php echo date('M Y', strtotime($profile['created_at'])); ?></span>
        </div>
      </div>
    </div>

    <div class="two-col">

      <!-- ── Edit Profile Form ──────────────────────── -->
      <div class="panel">
        <div class="panel-head">
          <div class="panel-title"><i class="fas fa-user-edit"></i> Edit Profile</div>
        </div>
        <div class="panel-body">
          <form method="POST" action="profile.php">
            <input type="hidden" name="action" value="update_profile">

            <div class="sec-label">Personal Information</div>

            <div class="field">
              <label>Full Name</label>
              <div class="input-wrap">
                <span class="ico"><i class="fas fa-user"></i></span>
                <input type="text" name="full_name" value="<?php echo htmlspecialchars($profile['full_name']); ?>" placeholder="Juan dela Cruz" required>
              </div>
            </div>

            <div class="row-2">
              <div class="field">
                <label>Phone Number</label>
                <div class="input-wrap">
                  <span class="ico"><i class="fas fa-mobile-alt"></i></span>
                  <input type="tel" name="phone" value="<?php echo htmlspecialchars($profile['phone'] ?? ''); ?>" placeholder="09XX-XXX-XXXX" required>
                </div>
              </div>
              <div class="field">
                <label>Room Number</label>
                <div class="input-wrap">
                  <span class="ico"><i class="fas fa-door-open"></i></span>
                  <input type="text" name="room_number" value="<?php echo htmlspecialchars($profile['room_number'] ?? ''); ?>" placeholder="e.g. 2A" required>
                </div>
              </div>
            </div>

            <div class="field">
              <label>Home Address</label>
              <div class="input-wrap">
                <span class="ico"><i class="fas fa-map-marker-alt"></i></span>
                <input type="text" name="address" value="<?php echo htmlspecialchars($profile['address'] ?? ''); ?>" placeholder="Street, Barangay, City" required>
              </div>
            </div>

            <div class="sec-label">Emergency Contact</div>

            <div class="row-2">
              <div class="field">
                <label>Contact Name</label>
                <div class="input-wrap">
                  <span class="ico"><i class="fas fa-user-shield"></i></span>
                  <input type="text" name="emergency_contact" value="<?php echo htmlspecialchars($profile['emergency_contact'] ?? ''); ?>" placeholder="Full name" required>
                </div>
              </div>
              <div class="field">
                <label>Contact Phone</label>
                <div class="input-wrap">
                  <span class="ico"><i class="fas fa-phone"></i></span>
                  <input type="tel" name="emergency_phone" value="<?php echo htmlspecialchars($profile['emergency_phone'] ?? ''); ?>" placeholder="09XX-XXX-XXXX" required>
                </div>
              </div>
            </div>

            <div class="sec-label">Account</div>

            <div class="field">
              <label>Email Address</label>
              <div class="input-wrap">
                <span class="ico"><i class="fas fa-envelope"></i></span>
                <input type="email" value="<?php echo htmlspecialchars($profile['email']); ?>" readonly>
              </div>
              <span class="field-hint">Email cannot be changed. Contact admin if needed.</span>
            </div>

            <button type="submit" class="btn-primary">
              <i class="fas fa-save"></i> Save Changes
            </button>
          </form>
        </div>
      </div>

      <!-- ── Right Column ───────────────────────────── -->
      <div style="display:flex;flex-direction:column;gap:1.25rem;">

        <!-- Account Info (read-only) -->
        <div class="panel">
          <div class="panel-head">
            <div class="panel-title"><i class="fas fa-id-card"></i> Account Details</div>
          </div>
          <div class="panel-body">
            <div class="info-row">
              <span class="ir-key">Tenant ID</span>
              <span class="ir-val">#<?php echo str_pad($profile['id'], 5, '0', STR_PAD_LEFT); ?></span>
            </div>
            <div class="info-row">
              <span class="ir-key">Email</span>
              <span class="ir-val" style="font-size:0.78rem;"><?php echo htmlspecialchars($profile['email']); ?></span>
            </div>
            <div class="info-row">
              <span class="ir-key">Room</span>
              <span class="ir-val"><?php echo htmlspecialchars($profile['room_number'] ?? '—'); ?></span>
            </div>
            <div class="info-row">
              <span class="ir-key">Phone</span>
              <span class="ir-val"><?php echo htmlspecialchars($profile['phone'] ?? '—'); ?></span>
            </div>
            <div class="info-row">
              <span class="ir-key">Member Since</span>
              <span class="ir-val"><?php echo date('F j, Y', strtotime($profile['created_at'])); ?></span>
            </div>
            <div class="info-row">
              <span class="ir-key">Emergency</span>
              <span class="ir-val"><?php echo htmlspecialchars($profile['emergency_contact'] ?? '—'); ?></span>
            </div>
            <div class="info-row">
              <span class="ir-key">Emerg. Phone</span>
              <span class="ir-val"><?php echo htmlspecialchars($profile['emergency_phone'] ?? '—'); ?></span>
            </div>
          </div>
        </div>

        <!-- Change Password -->
        <div class="panel">
          <div class="panel-head">
            <div class="panel-title"><i class="fas fa-lock"></i> Change Password</div>
          </div>
          <div class="panel-body">
            <form method="POST" action="profile.php">
              <input type="hidden" name="action" value="change_password">

              <div class="field">
                <label>Current Password</label>
                <div class="input-wrap" style="position:relative;">
                  <span class="ico"><i class="fas fa-lock"></i></span>
                  <input type="password" name="current_password" id="pw-current" placeholder="Enter current password" required>
                  <button type="button" class="eye-btn" onclick="togglePw('pw-current',this)"><i class="fas fa-eye"></i></button>
                </div>
              </div>

              <div class="field">
                <label>New Password</label>
                <div class="input-wrap" style="position:relative;">
                  <span class="ico"><i class="fas fa-key"></i></span>
                  <input type="password" name="new_password" id="pw-new" placeholder="At least 6 characters" oninput="checkStrength(this.value)" required>
                  <button type="button" class="eye-btn" onclick="togglePw('pw-new',this)"><i class="fas fa-eye"></i></button>
                </div>
                <div class="strength-bar"><div class="strength-fill" id="strength-fill"></div></div>
              </div>

              <div class="field">
                <label>Confirm New Password</label>
                <div class="input-wrap" style="position:relative;">
                  <span class="ico"><i class="fas fa-key"></i></span>
                  <input type="password" name="confirm_password" id="pw-confirm" placeholder="Repeat new password" required>
                  <button type="button" class="eye-btn" onclick="togglePw('pw-confirm',this)"><i class="fas fa-eye"></i></button>
                </div>
              </div>

              <button type="submit" class="btn-danger">
                <i class="fas fa-key"></i> Update Password
              </button>
            </form>
          </div>
        </div>

      </div><!-- /right col -->
    </div><!-- /two-col -->

  </div>
</div>

<script>
function togglePw(id, btn) {
  const f = document.getElementById(id);
  const icon = btn.querySelector('i');
  if (f.type === 'password') {
    f.type = 'text';
    icon.className = 'fas fa-eye-slash';
  } else {
    f.type = 'password';
    icon.className = 'fas fa-eye';
  }
}

function checkStrength(val) {
  const fill = document.getElementById('strength-fill');
  let score = 0;
  if (val.length >= 6)  score++;
  if (val.length >= 10) score++;
  if (/[A-Z]/.test(val) && /[a-z]/.test(val)) score++;
  if (/[0-9]/.test(val)) score++;
  if (/[^A-Za-z0-9]/.test(val)) score++;

  const pct   = ['0%','20%','40%','65%','85%','100%'][score];
  const color = ['','#ef4444','#f59e0b','#f59e0b','#3b82f6','#10b981'][score];
  fill.style.width      = pct;
  fill.style.background = color;
}
</script>
</body>
</html>