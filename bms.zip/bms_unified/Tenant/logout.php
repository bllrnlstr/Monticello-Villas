<?php
session_start();
require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';

if (isset($_SESSION['tenant_id'])) {
    $pdo = getDB();
    db_audit_tenant($pdo, (int)$_SESSION['tenant_id'], 'LOGOUT', 'Tenant signed out');
}
session_destroy();
header("Location: index.php");
exit();