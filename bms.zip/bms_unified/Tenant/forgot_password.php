<?php
/**
 * tenant/forgot_password.php — Password Reset Request
 * Tenant enters email → receives a reset link valid for 1 hour.
 */
session_start();

if (isset($_SESSION['tenant_id'])) {
    header("Location: dashboard.php"); exit();
}

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
require_once __DIR__ . '/../shared/notifications.php';

$pdo     = getDB();
$success = false;
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));

    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Always show success to prevent email enumeration
        $tenant = db_fetch_one($pdo, "SELECT id, full_name, email FROM tenants WHERE email = ? AND approval_status = 'approved' LIMIT 1", [$email]);

        if ($tenant) {
            // Create reset_tokens table if not exists
            try {
                $pdo->exec("CREATE TABLE IF NOT EXISTS password_reset_tokens (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    tenant_id INT NOT NULL,
                    token VARCHAR(64) NOT NULL UNIQUE,
                    used TINYINT(1) DEFAULT 0,
                    expires_at DATETIME NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_token (token),
                    INDEX idx_tenant (tenant_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            } catch (PDOException $e) {}

            // Invalidate previous unused tokens
            $pdo->prepare("DELETE FROM password_reset_tokens WHERE tenant_id = ? AND used = 0")
                ->execute([$tenant['id']]);

            // Generate token — 1 hour expiry
            $token     = bin2hex(random_bytes(32));
            $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));
            $pdo->prepare("INSERT INTO password_reset_tokens (tenant_id, token, expires_at) VALUES (?, ?, ?)")
                ->execute([$tenant['id'], $token, $expiresAt]);

            $resetUrl = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://'
                      . $_SERVER['HTTP_HOST']
                      . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/') . '/reset_password.php?token=' . $token;

            notify_password_reset($tenant['email'], $tenant['full_name'], $resetUrl);
        }

        $success = true; // Always show success
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password — Tenant Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
:root{--bg:#080d1a;--surface:#0d1424;--accent:#2563eb;--accent-lt:#3b82f6;--accent-gl:rgba(37,99,235,0.15);--ok:#10b981;--err:#ef4444;--silver:#94a3b8;--light:#cbd5e1;--white:#f1f5f9;--border:rgba(255,255,255,0.07);}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1.5rem;}
.card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:2.5rem 2rem;width:100%;max-width:420px;box-shadow:0 24px 48px rgba(0,0,0,.5);}
.logo-row{display:flex;align-items:center;gap:.7rem;margin-bottom:2rem;}
.logo-mark{width:34px;height:34px;background:var(--accent);border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:1rem;}
.logo-name{font-family:'Syne',sans-serif;font-size:.92rem;font-weight:700;color:var(--white);}
.logo-name small{display:block;font-size:.55rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:.1em;text-transform:uppercase;}
h1{font-family:'Syne',sans-serif;font-size:1.5rem;font-weight:800;color:var(--white);margin-bottom:.4rem;}
.subtitle{font-size:.82rem;color:var(--silver);line-height:1.7;margin-bottom:1.5rem;}
.alert-err{display:flex;align-items:center;gap:.5rem;padding:.65rem .9rem;border-radius:5px;font-size:.78rem;margin-bottom:1rem;border-left:3px solid var(--err);background:rgba(239,68,68,0.07);color:#fca5a5;}
.success-box{text-align:center;padding:.5rem 0;}
.success-icon{width:64px;height:64px;border-radius:16px;background:rgba(16,185,129,0.12);border:1px solid rgba(16,185,129,0.25);display:flex;align-items:center;justify-content:center;font-size:1.8rem;margin:0 auto 1.25rem;}
.success-title{font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:800;color:var(--white);margin-bottom:.5rem;}
.success-sub{font-size:.82rem;color:var(--silver);line-height:1.75;margin-bottom:1.5rem;}
.field{margin-bottom:1rem;}
.field label{display:block;font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.09em;color:var(--silver);margin-bottom:.4rem;}
.field .wrap{position:relative;}
.field .ico{position:absolute;left:.75rem;top:50%;transform:translateY(-50%);font-size:.72rem;color:rgba(148,163,184,0.4);}
.field input{width:100%;padding:.72rem 1rem .72rem 2.3rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.09);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:.875rem;color:var(--white);outline:none;transition:border-color .2s;}
.field input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-gl);}
.field input::placeholder{color:rgba(148,163,184,0.35);}
.btn-submit{width:100%;padding:.8rem;background:var(--accent);color:#fff;border:none;border-radius:5px;font-family:'Syne',sans-serif;font-size:.88rem;font-weight:700;cursor:pointer;transition:all .2s;margin-top:.25rem;}
.btn-submit:hover{background:#1d4ed8;box-shadow:0 5px 16px var(--accent-gl);}
.back-link{display:block;text-align:center;margin-top:1.25rem;font-size:.78rem;color:var(--silver);text-decoration:none;}
.back-link:hover{color:var(--white);}
</style>
</head>
<body>
<div class="card">
  <div class="logo-row">
    <div class="logo-mark">⬡</div>
    <div class="logo-name">Tenant Portal <small>Boarding House</small></div>
  </div>

  <?php if ($success): ?>
  <div class="success-box">
    <div class="success-icon">📧</div>
    <div class="success-title">Check Your Email</div>
    <div class="success-sub">
      If that email is registered in our system, you'll receive a password reset link shortly.<br><br>
      The link is valid for <strong style="color:var(--white)">1 hour</strong> and can only be used once.
    </div>
    <a href="index.php" class="btn-submit" style="display:block;text-align:center;text-decoration:none;">← Back to Sign In</a>
  </div>

  <?php else: ?>
  <h1>Forgot Password?</h1>
  <p class="subtitle">Enter the email address linked to your account and we'll send you a reset link.</p>

  <?php if ($error): ?>
  <div class="alert-err">⚠ <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>

  <form method="POST">
    <div class="field">
      <label>Email Address</label>
      <div class="wrap">
        <span class="ico">✉</span>
        <input type="email" name="email" placeholder="your@email.com"
               value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>" required autofocus>
      </div>
    </div>
    <button type="submit" class="btn-submit">📧 Send Reset Link</button>
  </form>

  <a href="index.php" class="back-link">← Back to Sign In</a>
  <?php endif; ?>
</div>
</body>
</html>