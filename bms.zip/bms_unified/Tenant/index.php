<?php
/**
 * tenant/index.php — Tenant Login Page
 * Updated: Added "Forgot password?" link
 */
session_start();

if (isset($_SESSION['tenant_id'])) {
    header("Location: dashboard.php"); exit();
}

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';

$pdo   = getDB();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = strtolower(trim($_POST['email']    ?? ''));
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = 'Please enter your email and password.';
    } else {
        $tenant = db_fetch_one($pdo, "SELECT * FROM tenants WHERE email=? AND approval_status='approved' LIMIT 1", [$email]);

        if (!$tenant || !password_verify($password, $tenant['password_hash'] ?? '')) {
            $error = 'Invalid email or password.';
        } elseif (($tenant['status'] ?? '') !== 'active') {
            $error = 'Your account is not active. Please contact management.';
        } else {
            session_regenerate_id(true);
            $_SESSION['tenant_id']   = $tenant['id'];
            $_SESSION['tenant_name'] = $tenant['full_name'];
            $_SESSION['tenant_room'] = $tenant['room_number'] ?? '';
            $_SESSION['tenant_time'] = time();

            // Update last seen
            try { $pdo->prepare("UPDATE tenants SET updated_at=NOW() WHERE id=?")->execute([$tenant['id']]); } catch (Throwable $e) {}

            header("Location: dashboard.php"); exit();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sign In — Tenant Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
:root{--bg:#080d1a;--surface:#0d1424;--surface-2:#111827;--accent:#2563eb;--accent-lt:#3b82f6;--accent-gl:rgba(37,99,235,0.15);--err:#ef4444;--silver:#94a3b8;--light:#cbd5e1;--white:#f1f5f9;--border:rgba(255,255,255,0.07);}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);min-height:100vh;display:grid;grid-template-columns:1fr 1fr;}

/* Left panel */
.left{position:relative;background:var(--surface);display:flex;flex-direction:column;justify-content:space-between;padding:3rem;overflow:hidden;}
.left::before{content:'';position:absolute;inset:0;background:radial-gradient(ellipse 55% 45% at 15% 85%,rgba(37,99,235,0.16) 0%,transparent 65%);pointer-events:none;}
.grid-bg{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,0.02) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.02) 1px,transparent 1px);background-size:44px 44px;}
.left>*:not(.grid-bg){position:relative;z-index:1;}
.logo-row{display:flex;align-items:center;gap:.75rem;}
.logo-mark{width:34px;height:34px;background:var(--accent);border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:1rem;color:#fff;}
.logo-name{font-family:'Syne',sans-serif;font-size:.95rem;font-weight:700;color:var(--white);}
.logo-name small{display:block;font-size:.57rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:.12em;text-transform:uppercase;margin-top:1px;}
.hero h1{font-family:'Syne',sans-serif;font-size:2.5rem;font-weight:800;line-height:1.08;color:var(--white);margin-bottom:1rem;}
.hero h1 em{font-style:normal;color:var(--accent-lt);}
.hero p{font-size:.875rem;color:var(--silver);line-height:1.8;margin-bottom:1.75rem;}
.feature{display:flex;align-items:center;gap:.7rem;padding:.55rem 0;font-size:.82rem;color:var(--light);}
.feature-ic{width:28px;height:28px;border-radius:6px;background:var(--accent-gl);border:1px solid rgba(37,99,235,0.25);display:flex;align-items:center;justify-content:center;font-size:.7rem;flex-shrink:0;}
.left-foot{font-size:.63rem;color:rgba(255,255,255,0.18);}

/* Right panel */
.right{background:var(--surface-2);border-left:1px solid var(--border);display:flex;align-items:center;justify-content:center;padding:2rem 2.5rem;overflow-y:auto;}
.form-wrap{width:100%;max-width:380px;animation:rise .38s cubic-bezier(.22,1,.36,1) both;}
@keyframes rise{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:none;}}

/* Tabs */
.tabs{display:flex;background:rgba(255,255,255,0.03);border:1px solid var(--border);border-radius:5px;padding:3px;gap:3px;margin-bottom:1.75rem;}
.tab{flex:1;padding:.52rem .2rem;background:transparent;border:none;border-radius:3px;font-family:'DM Sans',sans-serif;font-size:.76rem;font-weight:500;color:var(--silver);cursor:pointer;transition:all .2s;text-decoration:none;display:block;text-align:center;white-space:nowrap;}
.tab.active{background:var(--accent);color:#fff;font-weight:600;}
.tab:hover:not(.active){color:var(--white);background:rgba(255,255,255,0.05);}

.form-title{font-family:'Syne',sans-serif;font-size:1.4rem;font-weight:700;color:var(--white);margin-bottom:.25rem;}
.form-sub{font-size:.8rem;color:var(--silver);margin-bottom:1.5rem;line-height:1.6;}
.alert-err{display:flex;align-items:center;gap:.5rem;padding:.65rem .9rem;border-radius:4px;font-size:.78rem;margin-bottom:1rem;border-left:3px solid var(--err);background:rgba(239,68,68,0.07);color:#fca5a5;}

/* Form fields */
.field{display:flex;flex-direction:column;gap:.28rem;margin-bottom:.75rem;}
.field label{font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.09em;color:var(--silver);}
.wrap{position:relative;}
.wrap input{width:100%;padding:.7rem 1rem .7rem 2.3rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.09);border-radius:4px;font-family:'DM Sans',sans-serif;font-size:.875rem;color:var(--white);outline:none;transition:border-color .2s,box-shadow .2s;}
.wrap input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-gl);}
.wrap input::placeholder{color:rgba(148,163,184,0.35);}
.wrap .ico{position:absolute;left:.72rem;top:50%;transform:translateY(-50%);font-size:.72rem;color:rgba(148,163,184,0.4);pointer-events:none;}

.btn-submit{width:100%;padding:.8rem;background:var(--accent);color:#fff;border:none;border-radius:4px;font-family:'Syne',sans-serif;font-size:.86rem;font-weight:600;letter-spacing:.05em;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:.5rem;margin-top:.5rem;}
.btn-submit:hover{background:#1d4ed8;box-shadow:0 5px 16px var(--accent-gl);}

/* ── Forgot password link ── */
.forgot-link{display:block;text-align:center;margin-top:1rem;font-size:.78rem;color:var(--silver);text-decoration:none;transition:color .2s;}
.forgot-link:hover{color:var(--accent-lt);}

.divider{display:flex;align-items:center;gap:.75rem;margin:1.25rem 0;font-size:.7rem;color:var(--silver);}
.divider::before,.divider::after{content:'';flex:1;height:1px;background:rgba(255,255,255,0.06);}

@media(max-width:860px){body{grid-template-columns:1fr;}.left{min-height:200px;padding:2rem;}.right{border-left:none;border-top:1px solid var(--border);}.hero h1{font-size:1.8rem;}}
@media(max-width:460px){.tab{font-size:.7rem;padding:.5rem .1rem;}}
</style>
</head>
<body>

<!-- LEFT -->
<div class="left">
  <div class="grid-bg"></div>
  <div class="logo-row">
    <div class="logo-mark">⬡</div>
    <div class="logo-name">Tenant Portal <small>Boarding House</small></div>
  </div>

  <div class="hero">
    <h1>Manage your <em>tenancy</em> online.</h1>
    <p>Pay rent, track your payments, submit maintenance requests, and stay updated — all in one place.</p>

    <div class="feature"><div class="feature-ic">💳</div> Submit and track rent payments</div>
    <div class="feature"><div class="feature-ic">🔧</div> Report maintenance issues</div>
    <div class="feature"><div class="feature-ic">📋</div> View invoices and contracts</div>
    <div class="feature"><div class="feature-ic">📢</div> See announcements from management</div>
  </div>

  <div class="left-foot">&copy; <?= date('Y') ?> Boarding House. All rights reserved.</div>
</div>

<!-- RIGHT -->
<div class="right">
  <div class="form-wrap">

    <div class="tabs">
      <a href="index.php"    class="tab active">Sign In</a>
      <a href="inquiry.php"  class="tab">Inquire</a>
      <a href="register.php" class="tab">Register</a>
    </div>

    <div class="form-title">Welcome back 👋</div>
    <div class="form-sub">Sign in to your tenant account to manage your stay.</div>

    <?php if ($error): ?>
    <div class="alert-err">⚠ <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php">

      <div class="field">
        <label>Email Address</label>
        <div class="wrap">
          <span class="ico">✉</span>
          <input type="email" name="email" placeholder="your@email.com"
                 value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                 required autofocus autocomplete="email">
        </div>
      </div>

      <div class="field">
        <label>Password</label>
        <div class="wrap">
          <span class="ico">🔒</span>
          <input type="password" name="password" placeholder="Enter your password"
                 required autocomplete="current-password">
        </div>
      </div>

      <button type="submit" class="btn-submit">🔐 Sign In</button>
    </form>

    <!-- ── Forgot password link (NEW) ── -->
    <a href="forgot_password.php" class="forgot-link">Forgot your password?</a>

    <div class="divider">or</div>

    <div style="text-align:center;font-size:.78rem;color:var(--silver);line-height:1.7;">
      New here? <a href="inquiry.php" style="color:var(--accent-lt);text-decoration:none;">Submit a room inquiry</a>
      or <a href="register.php" style="color:var(--accent-lt);text-decoration:none;">create an account</a>
      if you already have an invite link.
    </div>

  </div>
</div>

</body>
</html>