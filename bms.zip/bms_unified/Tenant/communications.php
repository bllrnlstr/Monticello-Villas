<?php
session_start();
if(isset($_SESSION["tenant_time"]) && (time()-$_SESSION["tenant_time"])>7200){session_destroy();header("Location: index.php");exit();}
$_SESSION["tenant_time"] = time();
if (!isset($_SESSION['tenant_id'])) { header("Location: index.php"); exit(); }

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';
$pdo = getDB();

$tenant_id   = $_SESSION['tenant_id'];
$tenant_name = $_SESSION['tenant_name'];
$tenant_room = $_SESSION['tenant_room'];

$initials = '';
foreach (explode(' ', $tenant_name) as $p) {
    if ($p !== '') $initials .= strtoupper($p[0]);
}

// Fetch all announcements newest first
$announcements = $pdo->query("
    SELECT a.*, u.full_name AS posted_by_name
    FROM announcements a
    LEFT JOIN admin_users u ON u.id = a.created_by
    ORDER BY a.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

// Type config
$typeConfig = [
    'general'     => ['label'=>'General',     'icon'=>'fa-bullhorn',        'color'=>'blue',   'bg'=>'rgba(37,99,235,0.08)',   'border'=>'rgba(37,99,235,0.2)',   'badge_bg'=>'rgba(37,99,235,0.15)',  'badge_color'=>'var(--accent-lt)'],
    'warning'     => ['label'=>'Warning',     'icon'=>'fa-exclamation-triangle','color'=>'red', 'bg'=>'rgba(239,68,68,0.07)',   'border'=>'rgba(239,68,68,0.2)',   'badge_bg'=>'rgba(239,68,68,0.15)',  'badge_color'=>'#fca5a5'],
    'maintenance' => ['label'=>'Maintenance', 'icon'=>'fa-tools',           'color'=>'yellow', 'bg'=>'rgba(245,158,11,0.07)', 'border'=>'rgba(245,158,11,0.2)',  'badge_bg'=>'rgba(245,158,11,0.15)','badge_color'=>'#fcd34d'],
    'reminder'    => ['label'=>'Reminder',    'icon'=>'fa-bell',            'color'=>'green',  'bg'=>'rgba(16,185,129,0.07)', 'border'=>'rgba(16,185,129,0.2)',  'badge_bg'=>'rgba(16,185,129,0.15)','badge_color'=>'#6ee7b7'],
];

$filterType = $_GET['type'] ?? '';
$filtered   = $filterType
    ? array_filter($announcements, fn($a) => $a['type'] === $filterType)
    : $announcements;
$filtered = array_values($filtered);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Communications — Monticello TMS</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
:root{
  --bg:#080d1a;--surface:#0d1424;--surface-2:#111827;
  --accent:#2563eb;--accent-lt:#3b82f6;--accent-gl:rgba(37,99,235,0.15);
  --ok:#10b981;--warn:#f59e0b;--err:#ef4444;--purple:#8b5cf6;
  --silver:#94a3b8;--light:#cbd5e1;--white:#f1f5f9;
  --border:rgba(255,255,255,0.07);--border-2:rgba(255,255,255,0.04);
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--light);display:flex;min-height:100vh;}

/* Sidebar */
.sidebar{width:240px;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;height:100vh;z-index:100;}
.sb-logo{padding:1.6rem 1.4rem;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:0.7rem;}
.sb-mark{width:32px;height:32px;background:var(--accent);border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:0.9rem;flex-shrink:0;}
.sb-name{font-family:'Syne',sans-serif;font-size:0.9rem;font-weight:700;color:var(--white);}
.sb-name small{display:block;font-size:0.58rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:0.1em;text-transform:uppercase;margin-top:1px;}
.sb-nav{flex:1;padding:1rem 0.75rem;overflow-y:auto;}
.nav-section-label{font-size:0.58rem;font-weight:700;text-transform:uppercase;letter-spacing:0.14em;color:rgba(148,163,184,0.45);padding:0.6rem 0.65rem 0.4rem;margin-top:0.5rem;}
.nav-link{display:flex;align-items:center;gap:0.7rem;padding:0.62rem 0.75rem;border-radius:5px;font-size:0.82rem;font-weight:500;color:var(--silver);text-decoration:none;transition:all 0.18s;margin-bottom:2px;}
.nav-link:hover{background:rgba(255,255,255,0.05);color:var(--white);}
.nav-link.active{background:var(--accent-gl);color:var(--accent-lt);border-left:2px solid var(--accent);padding-left:calc(0.75rem - 2px);}
.nav-link i{width:16px;font-size:0.8rem;opacity:0.8;}
.sb-user{padding:1rem 1.1rem;border-top:1px solid var(--border);}
.sb-user-row{display:flex;align-items:center;gap:0.7rem;margin-bottom:0.75rem;}
.sb-avatar{width:36px;height:36px;border-radius:8px;background:linear-gradient(135deg,var(--accent),#1d4ed8);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-size:0.8rem;font-weight:700;color:#fff;flex-shrink:0;}
.sb-user-name{font-size:0.82rem;font-weight:600;color:var(--white);}
.sb-user-room{font-size:0.68rem;color:var(--silver);margin-top:1px;}
.logout-btn{width:100%;padding:0.55rem;background:rgba(239,68,68,0.08);border:1px solid rgba(239,68,68,0.18);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:0.76rem;font-weight:600;color:#fca5a5;cursor:pointer;transition:all 0.2s;display:flex;align-items:center;justify-content:center;gap:0.5rem;}
.logout-btn:hover{background:rgba(239,68,68,0.14);}

/* Main */
.main{margin-left:240px;flex:1;min-height:100vh;}
.topbar{background:var(--surface);border-bottom:1px solid var(--border);padding:0 2rem;height:58px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:50;}
.topbar-title h1{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);}
.topbar-title p{font-size:0.72rem;color:var(--silver);margin-top:1px;}
.topbar-date{font-size:0.75rem;color:var(--silver);background:var(--border-2);border:1px solid var(--border);padding:0.35rem 0.85rem;border-radius:4px;}
.content{padding:1.75rem 2rem;}

/* Filter tabs */
.filter-tabs{display:flex;gap:8px;margin-bottom:1.5rem;flex-wrap:wrap;}
.filter-tab{padding:0.5rem 1.1rem;background:var(--surface);border:1px solid var(--border);border-radius:5px;font-size:0.78rem;font-weight:500;color:var(--silver);text-decoration:none;transition:all 0.18s;display:flex;align-items:center;gap:0.4rem;}
.filter-tab:hover{border-color:rgba(255,255,255,0.15);color:var(--white);}
.filter-tab.active{background:var(--accent-gl);border-color:rgba(37,99,235,0.35);color:var(--accent-lt);}
.filter-tab .cnt{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 4px;border-radius:9px;background:var(--accent-gl);color:var(--accent-lt);font-size:0.6rem;font-weight:700;}

/* Announcement cards */
.ann-list{display:flex;flex-direction:column;gap:14px;}
.ann-card{border-radius:8px;border:1px solid;padding:1.3rem 1.5rem;position:relative;overflow:hidden;transition:border-color 0.18s;}
.ann-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;}
.ann-general  {background:rgba(37,99,235,0.06); border-color:rgba(37,99,235,0.18); } .ann-general::before  {background:var(--accent);}
.ann-warning  {background:rgba(239,68,68,0.06); border-color:rgba(239,68,68,0.18); } .ann-warning::before  {background:var(--err);}
.ann-maintenance{background:rgba(245,158,11,0.06);border-color:rgba(245,158,11,0.18);} .ann-maintenance::before{background:var(--warn);}
.ann-reminder {background:rgba(16,185,129,0.06);border-color:rgba(16,185,129,0.18);} .ann-reminder::before {background:var(--ok);}
.ann-card:hover{border-color:rgba(255,255,255,0.15);}

.ann-header{display:flex;align-items:flex-start;justify-content:space-between;gap:1rem;margin-bottom:0.75rem;}
.ann-left{display:flex;align-items:flex-start;gap:0.85rem;flex:1;}
.ann-icon{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:0.85rem;flex-shrink:0;margin-top:1px;}
.ann-title{font-family:'Syne',sans-serif;font-size:0.95rem;font-weight:700;color:var(--white);margin-bottom:3px;}
.ann-badge{display:inline-flex;align-items:center;gap:0.3rem;padding:0.18rem 0.6rem;border-radius:2px;font-size:0.6rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;}
.ann-body{font-size:0.85rem;color:var(--light);line-height:1.7;white-space:pre-wrap;}
.ann-footer{display:flex;align-items:center;gap:0.75rem;margin-top:0.85rem;padding-top:0.85rem;border-top:1px solid rgba(255,255,255,0.05);font-size:0.7rem;color:var(--silver);}
.ann-footer i{font-size:0.65rem;}
.ann-right{flex-shrink:0;text-align:right;}
.ann-time{font-size:0.68rem;color:var(--silver);white-space:nowrap;}
.ann-day{font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:800;color:var(--white);line-height:1;}
.ann-month{font-size:0.65rem;color:var(--silver);text-transform:uppercase;letter-spacing:0.1em;}

/* New badge */
.new-dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:var(--accent-lt);margin-right:5px;vertical-align:middle;}

/* Stats row */
.stats-row{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:1.5rem;}
.stat-mini{background:var(--surface);border:1px solid var(--border);border-radius:6px;padding:14px 16px;display:flex;align-items:center;gap:10px;}
.stat-mini-icon{width:34px;height:34px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:0.85rem;flex-shrink:0;}
.stat-mini-val{font-family:'Syne',sans-serif;font-size:1.3rem;font-weight:700;color:var(--white);line-height:1;}
.stat-mini-lbl{font-size:0.62rem;text-transform:uppercase;letter-spacing:0.08em;color:var(--silver);margin-top:2px;}

/* Empty */
.empty-state{text-align:center;padding:4rem 1rem;color:var(--silver);}
.empty-state i{font-size:2.5rem;opacity:0.12;display:block;margin-bottom:1rem;}
.empty-title{font-family:'Syne',sans-serif;font-size:1rem;font-weight:700;color:var(--white);margin-bottom:.4rem;}

@media(max-width:720px){.sidebar{display:none;}.main{margin-left:0;}.stats-row{grid-template-columns:1fr 1fr;}}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sb-logo">
    <div class="sb-mark">⬡</div>
    <div class="sb-name">Monticello <small>Tenant Portal</small></div>
  </div>
  <nav class="sb-nav">
    <div class="nav-section-label">Main</div>
    <a href="dashboard.php"       class="nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
    <a href="payments.php"        class="nav-link"><i class="fas fa-credit-card"></i> Payments</a>
    <div class="nav-section-label">Account</div>
    <a href="invoices.php"        class="nav-link"><i class="fas fa-file-invoice"></i> Invoices</a>
    <a href="maintenance.php"     class="nav-link"><i class="fas fa-tools"></i> Maintenance</a>
    <a href="communications.php"  class="nav-link active"><i class="fas fa-bullhorn"></i> Announcements</a>
    <a href="profile.php"         class="nav-link"><i class="fas fa-user-cog"></i> Profile</a>
  </nav>
  <div class="sb-user">
    <div class="sb-user-row">
      <div class="sb-avatar"><?= htmlspecialchars($initials) ?></div>
      <div>
        <div class="sb-user-name"><?= htmlspecialchars($tenant_name) ?></div>
        <div class="sb-user-room">Room <?= htmlspecialchars($tenant_room) ?></div>
      </div>
    </div>
    <form method="POST" action="logout.php" style="margin:0;">
      <button type="submit" class="logout-btn"><i class="fas fa-sign-out-alt"></i> Sign Out</button>
    </form>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <div class="topbar-title">
      <h1>Communications</h1>
      <p>Announcements and updates from management</p>
    </div>
    <div class="topbar-date"><?= date('l, F j, Y') ?></div>
  </div>

  <div class="content">

    <!-- Stats -->
    <?php
    $typeCounts = array_count_values(array_column($announcements, 'type'));
    $total      = count($announcements);
    // Find how many posted in last 7 days
    $recent = count(array_filter($announcements, fn($a) => strtotime($a['created_at']) >= strtotime('-7 days')));
    ?>
    <div class="stats-row">
      <div class="stat-mini">
        <div class="stat-mini-icon" style="background:var(--accent-gl);color:var(--accent-lt);"><i class="fas fa-bullhorn"></i></div>
        <div><div class="stat-mini-val"><?= $total ?></div><div class="stat-mini-lbl">Total</div></div>
      </div>
      <div class="stat-mini">
        <div class="stat-mini-icon" style="background:rgba(16,185,129,0.1);color:#6ee7b7;"><i class="fas fa-clock"></i></div>
        <div><div class="stat-mini-val"><?= $recent ?></div><div class="stat-mini-lbl">This Week</div></div>
      </div>
      <div class="stat-mini">
        <div class="stat-mini-icon" style="background:rgba(245,158,11,0.1);color:#fcd34d;"><i class="fas fa-tools"></i></div>
        <div><div class="stat-mini-val"><?= $typeCounts['maintenance'] ?? 0 ?></div><div class="stat-mini-lbl">Maintenance</div></div>
      </div>
      <div class="stat-mini">
        <div class="stat-mini-icon" style="background:rgba(239,68,68,0.1);color:#fca5a5;"><i class="fas fa-exclamation-triangle"></i></div>
        <div><div class="stat-mini-val"><?= $typeCounts['warning'] ?? 0 ?></div><div class="stat-mini-lbl">Warnings</div></div>
      </div>
    </div>

    <!-- Filter Tabs -->
    <div class="filter-tabs">
      <a href="communications.php"             class="filter-tab <?= $filterType===''?'active':'' ?>">
        <i class="fas fa-list"></i> All <span class="cnt"><?= $total ?></span>
      </a>
      <?php foreach ($typeConfig as $key => $cfg): $cnt = $typeCounts[$key] ?? 0; if ($cnt > 0): ?>
      <a href="?type=<?= $key ?>" class="filter-tab <?= $filterType===$key?'active':'' ?>">
        <i class="fas <?= $cfg['icon'] ?>"></i> <?= $cfg['label'] ?> <span class="cnt"><?= $cnt ?></span>
      </a>
      <?php endif; endforeach; ?>
    </div>

    <!-- Announcements List -->
    <?php if (empty($filtered)): ?>
    <div class="empty-state">
      <i class="fas fa-bullhorn"></i>
      <div class="empty-title">No announcements yet</div>
      <div style="font-size:0.82rem;">Check back later for updates from management.</div>
    </div>
    <?php else: ?>
    <div class="ann-list">
      <?php foreach ($filtered as $a):
        $cfg     = $typeConfig[$a['type']] ?? $typeConfig['general'];
        $isNew   = strtotime($a['created_at']) >= strtotime('-3 days');
        $annDate = new DateTime($a['created_at']);
      ?>
      <div class="ann-card ann-<?= $a['type'] ?>">
        <div class="ann-header">
          <div class="ann-left">
            <div class="ann-icon" style="background:<?= $cfg['badge_bg'] ?>;color:<?= $cfg['badge_color'] ?>;">
              <i class="fas <?= $cfg['icon'] ?>"></i>
            </div>
            <div>
              <div class="ann-title">
                <?php if ($isNew): ?><span class="new-dot"></span><?php endif; ?>
                <?= htmlspecialchars($a['title'], ENT_QUOTES, 'UTF-8') ?>
              </div>
              <span class="ann-badge" style="background:<?= $cfg['badge_bg'] ?>;color:<?= $cfg['badge_color'] ?>;">
                <i class="fas <?= $cfg['icon'] ?>"></i> <?= $cfg['label'] ?>
              </span>
              <?php if ($isNew): ?>
              <span style="display:inline-flex;align-items:center;gap:3px;padding:0.18rem 0.55rem;border-radius:2px;font-size:0.6rem;font-weight:700;text-transform:uppercase;letter-spacing:0.1em;background:rgba(37,99,235,0.15);color:var(--accent-lt);margin-left:4px;">NEW</span>
              <?php endif; ?>
            </div>
          </div>
          <div class="ann-right">
            <div class="ann-day"><?= $annDate->format('j') ?></div>
            <div class="ann-month"><?= $annDate->format('M Y') ?></div>
          </div>
        </div>

        <div class="ann-body"><?= htmlspecialchars($a['body'], ENT_QUOTES, 'UTF-8') ?></div>

        <div class="ann-footer">
          <span><i class="fas fa-user-shield"></i> <?= htmlspecialchars($a['posted_by_name'] ?? 'Management', ENT_QUOTES, 'UTF-8') ?></span>
          <span><i class="fas fa-clock"></i> <?= date('M j, Y · g:i A', strtotime($a['created_at'])) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

  </div>
</div>

</body>
</html>