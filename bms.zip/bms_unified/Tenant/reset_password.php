<?php
/**
 * tenant/reset_password.php — Password Reset Form
 * Validates the token from email and lets the tenant set a new password.
 */
session_start();

if (isset($_SESSION['tenant_id'])) {
    header("Location: dashboard.php"); exit();
}

require_once __DIR__ . '/../shared/db.php';
require_once __DIR__ . '/../shared/queries.php';

$pdo        = getDB();
$token      = trim($_GET['token'] ?? $_POST['token'] ?? '');
$tokenRow   = null;
$tokenError = '';
$success    = false;
$error      = '';

if ($token !== '') {
    try {
        $tokenRow = $pdo->prepare(
            "SELECT rt.*, t.full_name, t.email
             FROM password_reset_tokens rt
             JOIN tenants t ON t.id = rt.tenant_id
             WHERE rt.token = ? LIMIT 1"
        );
        $tokenRow->execute([$token]);
        $tokenRow = $tokenRow->fetch(PDO::FETCH_ASSOC);

        if (!$tokenRow) {
            $tokenError = 'This reset link is invalid. Please request a new one.';
        } elseif ((int)$tokenRow['used'] === 1) {
            $tokenError = 'This reset link has already been used. Please request a new one.';
        } elseif (strtotime($tokenRow['expires_at']) < time()) {
            $tokenError = 'This reset link has expired (valid for 1 hour). Please request a new one.';
        }
    } catch (PDOException $e) {
        $tokenError = 'Invalid or expired reset link.';
    }
} else {
    $tokenError = 'No reset token provided.';
}

// Handle form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$tokenError && $tokenRow) {
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm']  ?? '';

    if (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $pdo->prepare("UPDATE tenants SET password_hash = ? WHERE id = ?")
            ->execute([$hash, $tokenRow['tenant_id']]);
        $pdo->prepare("UPDATE password_reset_tokens SET used = 1 WHERE token = ?")
            ->execute([$token]);
        $success = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reset Password — Tenant Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap" rel="stylesheet">
<style>
:root{--bg:#080d1a;--surface:#0d1424;--accent:#2563eb;--accent-lt:#3b82f6;--accent-gl:rgba(37,99,235,0.15);--ok:#10b981;--err:#ef4444;--silver:#94a3b8;--light:#cbd5e1;--white:#f1f5f9;--border:rgba(255,255,255,0.07);}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'DM Sans',sans-serif;background:var(--bg);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1.5rem;}
.card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:2.5rem 2rem;width:100%;max-width:420px;box-shadow:0 24px 48px rgba(0,0,0,.5);}
.logo-row{display:flex;align-items:center;gap:.7rem;margin-bottom:2rem;}
.logo-mark{width:34px;height:34px;background:var(--accent);border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:1rem;}
.logo-name{font-family:'Syne',sans-serif;font-size:.92rem;font-weight:700;color:var(--white);}
.logo-name small{display:block;font-size:.55rem;font-family:'DM Sans',sans-serif;font-weight:400;color:var(--silver);letter-spacing:.1em;text-transform:uppercase;}
h1{font-family:'Syne',sans-serif;font-size:1.5rem;font-weight:800;color:var(--white);margin-bottom:.4rem;}
.subtitle{font-size:.82rem;color:var(--silver);line-height:1.7;margin-bottom:1.5rem;}
.alert-err{display:flex;align-items:center;gap:.5rem;padding:.65rem .9rem;border-radius:5px;font-size:.78rem;margin-bottom:1rem;border-left:3px solid var(--err);background:rgba(239,68,68,0.07);color:#fca5a5;}
.success-box{text-align:center;padding:.5rem 0;}
.success-icon{width:64px;height:64px;border-radius:16px;background:rgba(16,185,129,0.12);border:1px solid rgba(16,185,129,0.25);display:flex;align-items:center;justify-content:center;font-size:1.8rem;margin:0 auto 1.25rem;}
.success-title{font-family:'Syne',sans-serif;font-size:1.2rem;font-weight:800;color:var(--white);margin-bottom:.5rem;}
.success-sub{font-size:.82rem;color:var(--silver);line-height:1.75;margin-bottom:1.5rem;}
.error-box{text-align:center;padding:.5rem 0;}
.error-icon{width:64px;height:64px;border-radius:16px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);display:flex;align-items:center;justify-content:center;font-size:1.8rem;margin:0 auto 1.25rem;}
.field{margin-bottom:1rem;}
.field label{display:block;font-size:.65rem;font-weight:700;text-transform:uppercase;letter-spacing:.09em;color:var(--silver);margin-bottom:.4rem;}
.field .wrap{position:relative;}
.field .ico{position:absolute;left:.75rem;top:50%;transform:translateY(-50%);font-size:.72rem;color:rgba(148,163,184,0.4);}
.field input{width:100%;padding:.72rem 1rem .72rem 2.3rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.09);border-radius:5px;font-family:'DM Sans',sans-serif;font-size:.875rem;color:var(--white);outline:none;transition:border-color .2s;}
.field input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-gl);}
.field input::placeholder{color:rgba(148,163,184,0.35);}
.strength-bar{height:3px;border-radius:99px;margin-top:.4rem;background:rgba(255,255,255,0.06);overflow:hidden;}
.strength-fill{height:100%;border-radius:99px;transition:width .3s,background .3s;}
.strength-label{font-size:.62rem;color:var(--silver);margin-top:.25rem;}
.btn-submit{width:100%;padding:.8rem;background:var(--accent);color:#fff;border:none;border-radius:5px;font-family:'Syne',sans-serif;font-size:.88rem;font-weight:700;cursor:pointer;transition:all .2s;margin-top:.25rem;}
.btn-submit:hover{background:#1d4ed8;box-shadow:0 5px 16px var(--accent-gl);}
.btn-back{display:block;width:100%;padding:.75rem;background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:5px;font-family:'Syne',sans-serif;font-size:.86rem;font-weight:600;color:var(--light);text-decoration:none;text-align:center;transition:all .2s;margin-top:.6rem;}
.btn-back:hover{background:rgba(255,255,255,0.07);}
.who-box{display:flex;align-items:center;gap:.65rem;padding:.65rem .9rem;background:rgba(37,99,235,0.08);border:1px solid rgba(37,99,235,0.2);border-radius:5px;margin-bottom:1.25rem;font-size:.78rem;color:var(--light);}
.who-box strong{color:var(--white);}
</style>
</head>
<body>
<div class="card">
  <div class="logo-row">
    <div class="logo-mark">⬡</div>
    <div class="logo-name">Tenant Portal <small>Boarding House</small></div>
  </div>

  <?php if ($tokenError): ?>
  <div class="error-box">
    <div class="error-icon">🔒</div>
    <h1 style="margin-bottom:.5rem;">Invalid Link</h1>
    <p class="subtitle"><?= htmlspecialchars($tokenError, ENT_QUOTES, 'UTF-8') ?></p>
    <a href="forgot_password.php" class="btn-submit" style="display:block;text-align:center;text-decoration:none;">Request New Reset Link</a>
    <a href="index.php" class="btn-back">← Back to Sign In</a>
  </div>

  <?php elseif ($success): ?>
  <div class="success-box">
    <div class="success-icon">✅</div>
    <div class="success-title">Password Updated!</div>
    <div class="success-sub">Your password has been changed successfully. You can now sign in with your new password.</div>
    <a href="index.php" class="btn-submit" style="display:block;text-align:center;text-decoration:none;">Sign In Now →</a>
  </div>

  <?php else: ?>
  <h1>Set New Password</h1>
  <p class="subtitle">Choose a new password for your account.</p>

  <div class="who-box">
    🔑 Resetting password for <strong><?= htmlspecialchars($tokenRow['full_name'], ENT_QUOTES, 'UTF-8') ?></strong>
    &nbsp;·&nbsp; <?= htmlspecialchars($tokenRow['email'], ENT_QUOTES, 'UTF-8') ?>
  </div>

  <?php if ($error): ?>
  <div class="alert-err">⚠ <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
  <?php endif; ?>

  <form method="POST">
    <input type="hidden" name="token" value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>">

    <div class="field">
      <label>New Password</label>
      <div class="wrap">
        <span class="ico">🔒</span>
        <input type="password" name="password" id="pw" placeholder="Minimum 6 characters"
               required minlength="6" autocomplete="new-password" oninput="checkStrength(this.value)">
      </div>
      <div class="strength-bar"><div class="strength-fill" id="sfill" style="width:0%"></div></div>
      <div class="strength-label" id="slabel"></div>
    </div>

    <div class="field">
      <label>Confirm New Password</label>
      <div class="wrap">
        <span class="ico">🔒</span>
        <input type="password" name="confirm" placeholder="Repeat your new password"
               required minlength="6" autocomplete="new-password">
      </div>
    </div>

    <button type="submit" class="btn-submit">🔒 Update Password</button>
  </form>
  <?php endif; ?>
</div>

<script>
function checkStrength(v) {
  let score = 0;
  if (v.length >= 6)  score++;
  if (v.length >= 10) score++;
  if (/[A-Z]/.test(v)) score++;
  if (/[0-9]/.test(v)) score++;
  if (/[^A-Za-z0-9]/.test(v)) score++;
  const configs = [
    {w:'0%',   bg:'transparent', label:''},
    {w:'25%',  bg:'#ef4444',     label:'Weak'},
    {w:'50%',  bg:'#f59e0b',     label:'Fair'},
    {w:'75%',  bg:'#3b82f6',     label:'Good'},
    {w:'100%', bg:'#10b981',     label:'Strong'},
  ];
  const c = configs[Math.min(score, 4)];
  document.getElementById('sfill').style.cssText = `width:${c.w};background:${c.bg}`;
  document.getElementById('slabel').textContent  = c.label;
}
</script>
</body>
</html>