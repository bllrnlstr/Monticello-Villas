<?php
/**
 * shared/queries.php — Centralized SQL constants for bms_unified.
 * Included by both Admin and Tenant portal pages.
 */

// ── NAV STATS ────────────────────────────────────────────────
define('SQL_NAV_STATS', "
    SELECT
        (SELECT COUNT(*) FROM payments           WHERE status = 'pending')          AS pending_payments,
        (SELECT COUNT(*) FROM maintenance_requests WHERE status IN ('pending','open')) AS maintenance_requests,
        (SELECT COUNT(*) FROM inquiries           WHERE status = 'new')             AS new_inquiries,
        (SELECT COUNT(*) FROM payments            WHERE status = 'overdue')         AS overdue_payments,
        (SELECT COUNT(*) FROM tenants             WHERE approval_status = 'pending') AS pending_registrations
");

// ── ROOMS ────────────────────────────────────────────────────
define('SQL_ROOMS_SUMMARY',            "SELECT status, COUNT(*) AS cnt FROM rooms GROUP BY status");
define('SQL_ROOMS_LIST',               "SELECT r.*, (SELECT t.full_name FROM tenants t WHERE t.room_id=r.id AND t.status='active' LIMIT 1) AS current_tenant FROM rooms r WHERE 1=1");
define('SQL_ROOMS_LIST_SEARCH_APPEND', " AND (r.room_number LIKE ? OR r.room_type LIKE ? OR r.amenities LIKE ?)");
define('SQL_ROOMS_LIST_STATUS_APPEND', " AND r.status = ?");
define('SQL_ROOMS_LIST_ORDER',         " ORDER BY r.floor ASC, r.room_number ASC");
define('SQL_ROOM_GET_BY_ID',           "SELECT * FROM rooms WHERE id = ? LIMIT 1");
define('SQL_ROOM_GET_BY_NUMBER',       "SELECT * FROM rooms WHERE room_number = ? LIMIT 1");
define('SQL_ROOM_INSERT',              "INSERT INTO rooms (room_number,room_type,floor,capacity,monthly_rate,status,description,amenities) VALUES (?,?,?,?,?,?,?,?)");
define('SQL_ROOM_UPDATE',              "UPDATE rooms SET room_number=?,room_type=?,floor=?,capacity=?,monthly_rate=?,status=?,description=?,amenities=? WHERE id=?");
define('SQL_ROOM_DELETE',              "DELETE FROM rooms WHERE id=?");
define('SQL_ROOM_SET_STATUS',          "UPDATE rooms SET status=? WHERE id=?");
define('SQL_ROOMS_ALL',                "SELECT id,room_number,room_type,monthly_rate,status,capacity FROM rooms ORDER BY floor,room_number");
define('SQL_ROOMS_VACANT',             "SELECT id,room_number,room_type,monthly_rate FROM rooms WHERE status IN ('vacant','reserved') ORDER BY room_number");

// ── TENANTS ──────────────────────────────────────────────────
define('SQL_TENANTS_SUMMARY',            "SELECT approval_status AS status, COUNT(*) AS cnt FROM tenants GROUP BY approval_status");
define('SQL_TENANTS_LIST',               "SELECT t.*, r.room_number AS assigned_room_number, r.room_type FROM tenants t LEFT JOIN rooms r ON r.id = t.room_id WHERE 1=1");
define('SQL_TENANTS_LIST_SEARCH_APPEND', " AND (t.full_name LIKE ? OR t.email LIKE ? OR t.phone LIKE ? OR t.room_number LIKE ?)");
define('SQL_TENANTS_LIST_STATUS_APPEND', " AND t.approval_status = ?");
define('SQL_TENANTS_LIST_ORDER',         " ORDER BY t.created_at DESC");
define('SQL_TENANT_GET_BY_ID',           "SELECT * FROM tenants WHERE id = ? LIMIT 1");
define('SQL_TENANT_GET_BY_EMAIL',        "SELECT * FROM tenants WHERE email = ? LIMIT 1");
define('SQL_TENANT_INSERT',              "INSERT INTO tenants (full_name,email,phone,address,room_number,emergency_contact,emergency_phone,password_hash,approval_status,status) VALUES (?,?,?,?,?,?,?,?,'pending','pending')");

// Admin-created tenant (pre-approved, no password login needed)
// params: room_id, full_name, email, phone, address, emergency_contact, emergency_phone, id_type, id_number, move_in_date, move_out_date, status, notes
define('SQL_TENANT_ADMIN_INSERT',
    "INSERT INTO tenants
        (room_id,full_name,email,phone,address,emergency_contact,emergency_phone,
         id_type,id_number,move_in_date,move_out_date,status,notes,
         room_number,approval_status,password_hash)
     VALUES
        (?,?,?,?,?,?,?,?,?,?,?,?,?,
         COALESCE((SELECT room_number FROM rooms WHERE id=? LIMIT 1),''),
         'approved', '')");

// params: room_id, full_name, email, phone, address, emergency_contact, emergency_phone, id_type, id_number, move_in_date, move_out_date, status, notes, id
define('SQL_TENANT_ADMIN_UPDATE',
    "UPDATE tenants SET
        room_id=?, full_name=?, email=?, phone=?, address=?,
        emergency_contact=?, emergency_phone=?,
        id_type=?, id_number=?, move_in_date=?, move_out_date=?,
        status=?, notes=?,
        room_number=COALESCE((SELECT room_number FROM rooms WHERE id=? LIMIT 1), room_number)
     WHERE id=?");
define('SQL_TENANT_UPDATE_PROFILE',      "UPDATE tenants SET full_name=?,phone=?,address=?,room_number=?,emergency_contact=?,emergency_phone=? WHERE id=?");
define('SQL_TENANT_UPDATE_FULL',         "UPDATE tenants SET room_id=?,full_name=?,email=?,phone=?,address=?,room_number=?,emergency_contact=?,emergency_phone=?,id_type=?,id_number=?,monthly_due_day=?,monthly_rent=?,move_in_date=?,move_out_date=?,status=?,notes=? WHERE id=?");
define('SQL_TENANT_DELETE',              "DELETE FROM tenants WHERE id=?");
define('SQL_TENANT_RESET_PASSWORD',      "UPDATE tenants SET password_hash=? WHERE id=?");
define('SQL_TENANT_UPDATE_LAST_SEEN',    "UPDATE tenants SET updated_at=NOW() WHERE id=?");
define('SQL_TENANTS_ACTIVE',             "SELECT id,full_name,room_id,room_number,monthly_rent FROM tenants WHERE approval_status='approved' AND status='active' ORDER BY full_name");
define('SQL_TENANTS_ACTIVE_WITH_ROOM',   "SELECT t.id, t.full_name, t.room_id, r.room_number FROM tenants t LEFT JOIN rooms r ON r.id = t.room_id WHERE t.approval_status='approved' AND t.status='active' ORDER BY t.full_name");

// Approve / reject a tenant registration
define('SQL_TENANT_APPROVE', "
    UPDATE tenants
    SET approval_status='approved', status='active',
        approved_by=?, approved_at=NOW(),
        room_id=(SELECT id FROM rooms WHERE room_number=tenants.room_number LIMIT 1)
    WHERE id=?
");
define('SQL_TENANT_REJECT', "
    UPDATE tenants
    SET approval_status='rejected', status='inactive',
        rejection_reason=?
    WHERE id=?
");
// When approved, mark room occupied
define('SQL_ROOM_OCCUPY_BY_NUMBER', "UPDATE rooms SET status='occupied' WHERE room_number=? AND status IN ('vacant','reserved')");

// ── PAYMENTS ─────────────────────────────────────────────────
define('SQL_PAYMENTS_SUMMARY', "
    SELECT
        COALESCE(SUM(CASE WHEN status='paid'    THEN amount ELSE 0 END),0) AS total_collected,
        COALESCE(SUM(CASE WHEN status='pending' THEN amount ELSE 0 END),0) AS total_pending,
        COALESCE(SUM(CASE WHEN status='overdue' THEN amount ELSE 0 END),0) AS total_overdue,
        COUNT(CASE WHEN status='paid'    THEN 1 END) AS count_paid,
        COUNT(CASE WHEN status='pending' THEN 1 END) AS count_pending,
        COUNT(CASE WHEN status='overdue' THEN 1 END) AS count_overdue
    FROM payments
");
define('SQL_PAYMENTS_LIST',               "SELECT p.*, t.full_name AS tenant_name, r.room_number FROM payments p LEFT JOIN tenants t ON t.id=p.tenant_id LEFT JOIN rooms r ON r.id=p.room_id WHERE 1=1");
define('SQL_PAYMENTS_LIST_SEARCH_APPEND', " AND (t.full_name LIKE ? OR r.room_number LIKE ? OR p.reference LIKE ?)");
define('SQL_PAYMENTS_LIST_STATUS_APPEND', " AND p.status = ?");
define('SQL_PAYMENTS_LIST_ORDER',         " ORDER BY p.created_at DESC");
define('SQL_PAYMENT_GET_BY_ID',           "SELECT * FROM payments WHERE id=? LIMIT 1");
define('SQL_PAYMENT_INSERT',              "INSERT INTO payments (tenant_id,room_id,amount,type,status,due_date,payment_date,paid_at,payment_method,reference,admin_notes,submitted_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
define('SQL_PAYMENT_UPDATE',              "UPDATE payments SET tenant_id=?,room_id=?,amount=?,type=?,status=?,due_date=?,payment_date=?,paid_at=?,payment_method=?,reference=?,admin_notes=? WHERE id=?");
define('SQL_PAYMENT_DELETE',              "DELETE FROM payments WHERE id=?");
define('SQL_PAYMENT_MARK_PAID',           "UPDATE payments SET status='paid', paid_at=NOW() WHERE id=? AND status != 'paid'");
define('SQL_PAYMENT_EXISTS_FOR_MONTH',    "SELECT COUNT(*) FROM payments WHERE tenant_id=? AND type='rent' AND MONTH(due_date)=? AND YEAR(due_date)=?");
// Tenant submits payment request
define('SQL_PAYMENT_TENANT_SUBMIT',       "INSERT INTO payments (tenant_id,room_id,amount,due_date,payment_date,payment_method,status,submitted_by) VALUES (?,?,?,?,?,?,'pending','tenant')");
// Tenant's own payments
define('SQL_PAYMENTS_BY_TENANT',          "SELECT * FROM payments WHERE tenant_id=? ORDER BY created_at DESC");
define('SQL_PAYMENT_LATEST_BY_TENANT',    "SELECT * FROM payments WHERE tenant_id=? ORDER BY created_at DESC LIMIT 1");

// ── MAINTENANCE ──────────────────────────────────────────────
define('SQL_MAINT_SUMMARY', "
    SELECT COUNT(*) AS total,
           COUNT(CASE WHEN status IN ('pending','open') THEN 1 END) AS open_count,
           COUNT(CASE WHEN status='in_progress'         THEN 1 END) AS in_progress_count,
           COUNT(CASE WHEN status='resolved'            THEN 1 END) AS resolved_count
    FROM maintenance_requests
");
define('SQL_MAINT_LIST',               "SELECT m.*, r.room_number, t.full_name AS tenant_name FROM maintenance_requests m LEFT JOIN rooms r ON r.id=m.room_id LEFT JOIN tenants t ON t.id=m.tenant_id WHERE 1=1");
define('SQL_MAINT_LIST_SEARCH_APPEND', " AND (m.title LIKE ? OR m.description LIKE ? OR r.room_number LIKE ?)");
define('SQL_MAINT_LIST_STATUS_APPEND',   " AND m.status = ?");
define('SQL_MAINT_LIST_PRIORITY_APPEND', " AND m.priority = ?");
define('SQL_MAINT_LIST_ORDER',         " ORDER BY FIELD(m.priority,'urgent','high','medium','low'), m.created_at DESC");
define('SQL_MAINT_GET_BY_ID',          "SELECT * FROM maintenance_requests WHERE id=? LIMIT 1");
define('SQL_MAINT_INSERT',             "INSERT INTO maintenance_requests (room_id,tenant_id,title,description,priority,status,notes,submitted_by,created_at,updated_at) VALUES (?,?,?,?,?,?,?,'admin',NOW(),NOW())");
define('SQL_MAINT_UPDATE',             "UPDATE maintenance_requests SET room_id=?,tenant_id=?,title=?,description=?,priority=?,status=?,notes=?,updated_at=NOW() WHERE id=?");
define('SQL_MAINT_DELETE',             "DELETE FROM maintenance_requests WHERE id=?");
define('SQL_MAINT_RESOLVE',            "UPDATE maintenance_requests SET status='resolved', resolved_at=NOW() WHERE id=?");
define('SQL_MAINT_REPLY',              "UPDATE maintenance_requests SET admin_reply=?, status=? WHERE id=?");
// Tenant: submit and list own requests
define('SQL_MAINT_TENANT_SUBMIT',      "INSERT INTO maintenance_requests (tenant_id,room_id,category,title,description,urgency,status,submitted_by) VALUES (?,?,?,?,?,'normal','pending','tenant')");
define('SQL_MAINT_BY_TENANT',          "SELECT * FROM maintenance_requests WHERE tenant_id=? ORDER BY created_at DESC");
// Schedules (admin-posted, tenant-readable)
define('SQL_MAINT_SCHEDULES_UPCOMING', "SELECT * FROM maintenance_schedules WHERE status IN ('scheduled','ongoing') ORDER BY scheduled_date ASC");
define('SQL_MAINT_SCHEDULES_PAST',     "SELECT * FROM maintenance_schedules WHERE status IN ('completed','cancelled') OR scheduled_date < CURDATE() ORDER BY scheduled_date DESC LIMIT 20");
define('SQL_MAINT_SCHEDULE_INSERT',    "INSERT INTO maintenance_schedules (title,description,type,scheduled_date,scheduled_time,estimated_duration,affected_area,status,created_by) VALUES (?,?,?,?,?,?,?,?,?)");

// ── INQUIRIES ────────────────────────────────────────────────
define('SQL_INQUIRIES_SUMMARY',            "SELECT COUNT(*) AS total, COUNT(CASE WHEN status='new' THEN 1 END) AS new_count, COUNT(CASE WHEN status='contacted' THEN 1 END) AS contacted_count, COUNT(CASE WHEN status='converted' THEN 1 END) AS converted_count FROM inquiries");
define('SQL_INQUIRIES_LIST',               "SELECT * FROM inquiries WHERE 1=1");
define('SQL_INQUIRIES_LIST_SEARCH_APPEND', " AND (name LIKE ? OR email LIKE ? OR contact LIKE ? OR message LIKE ?)");
define('SQL_INQUIRIES_LIST_STATUS_APPEND', " AND status = ?");
define('SQL_INQUIRIES_LIST_ORDER',         " ORDER BY created_at DESC");
define('SQL_INQUIRY_GET_BY_ID',            "SELECT * FROM inquiries WHERE id=? LIMIT 1");
define('SQL_INQUIRY_INSERT',               "INSERT INTO inquiries (name,email,contact,room_type,message,status,notes) VALUES (?,?,?,?,?,?,?)");
define('SQL_INQUIRY_UPDATE',               "UPDATE inquiries SET name=?,email=?,contact=?,room_type=?,message=?,status=?,notes=? WHERE id=?");
define('SQL_INQUIRY_DELETE',               "DELETE FROM inquiries WHERE id=?");
define('SQL_INQUIRY_SET_STATUS',           "UPDATE inquiries SET status=? WHERE id=?");

// ── CONTRACTS ────────────────────────────────────────────────
define('SQL_CONTRACTS_SUMMARY',            "SELECT COUNT(*) AS total, COUNT(CASE WHEN status='active' THEN 1 END) AS active_count, COUNT(CASE WHEN status='expired' THEN 1 END) AS expired_count, COUNT(CASE WHEN status='terminated' THEN 1 END) AS terminated_count FROM contracts");
define('SQL_CONTRACTS_EXPIRING_SOON',      "SELECT COUNT(*) AS cnt FROM contracts WHERE status='active' AND end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(),INTERVAL 30 DAY)");
define('SQL_CONTRACTS_LIST',               "SELECT c.*, t.full_name AS tenant_name, r.room_number, r.room_type FROM contracts c LEFT JOIN tenants t ON t.id=c.tenant_id LEFT JOIN rooms r ON r.id=c.room_id WHERE 1=1");
define('SQL_CONTRACTS_LIST_SEARCH_APPEND', " AND (t.full_name LIKE ? OR r.room_number LIKE ?)");
define('SQL_CONTRACTS_LIST_STATUS_APPEND', " AND c.status = ?");
define('SQL_CONTRACTS_LIST_ORDER',         " ORDER BY c.start_date DESC");
define('SQL_CONTRACT_GET_BY_ID',           "SELECT * FROM contracts WHERE id=? LIMIT 1");
define('SQL_CONTRACT_INSERT',              "INSERT INTO contracts (tenant_id,room_id,start_date,end_date,monthly_rate,deposit,status,terms) VALUES (?,?,?,?,?,?,?,?)");
define('SQL_CONTRACT_UPDATE',              "UPDATE contracts SET tenant_id=?,room_id=?,start_date=?,end_date=?,monthly_rate=?,deposit=?,status=?,terms=? WHERE id=?");
define('SQL_CONTRACT_DELETE',              "DELETE FROM contracts WHERE id=?");
define('SQL_CONTRACTS_AUTO_EXPIRE',        "UPDATE contracts SET status='expired' WHERE status='active' AND end_date < CURDATE()");

// ── ANNOUNCEMENTS ────────────────────────────────────────────
define('SQL_ANNOUNCEMENTS_RECENT',   "SELECT a.*, u.full_name AS posted_by FROM announcements a LEFT JOIN admin_users u ON u.id=a.created_by ORDER BY a.created_at DESC LIMIT 10");
define('SQL_ANNOUNCEMENT_INSERT',    "INSERT INTO announcements (title,body,type,created_by) VALUES (?,?,?,?)");
define('SQL_ANNOUNCEMENT_DELETE',    "DELETE FROM announcements WHERE id=?");

// ── ADMIN USERS ──────────────────────────────────────────────
define('SQL_USERS_LIST',              "SELECT id,username,email,full_name,role,is_active,last_login,created_at FROM admin_users ORDER BY role DESC,full_name ASC");
define('SQL_USER_GET_BY_ID',          "SELECT id,username,email,full_name,role,is_active,created_at FROM admin_users WHERE id=? LIMIT 1");
define('SQL_USER_GET_BY_USERNAME',    "SELECT * FROM admin_users WHERE username=? LIMIT 1");
define('SQL_USER_INSERT',             "INSERT INTO admin_users (username,email,password,full_name,role,is_active) VALUES (?,?,?,?,?,1)");
define('SQL_USER_UPDATE',             "UPDATE admin_users SET username=?,email=?,full_name=?,role=? WHERE id=?");
define('SQL_USER_RESET_PASSWORD',     "UPDATE admin_users SET password=? WHERE id=?");
define('SQL_USER_TOGGLE_ACTIVE',      "UPDATE admin_users SET is_active=NOT is_active WHERE id=?");
define('SQL_USER_DELETE',             "DELETE FROM admin_users WHERE id=? AND id != 1");
define('SQL_USER_UPDATE_LAST_LOGIN',  "UPDATE admin_users SET last_login=NOW() WHERE id=?");

// ── AUDIT LOGS ───────────────────────────────────────────────
define('SQL_AUDIT_INSERT_ADMIN',      "INSERT INTO audit_logs (admin_id,actor_type,action,details,ip_address) VALUES (?,'admin',?,?,?)");
define('SQL_AUDIT_INSERT_TENANT',     "INSERT INTO audit_logs (tenant_id,actor_type,action,details,ip_address) VALUES (?,'tenant',?,?,?)");
define('SQL_AUDIT_LIST',              "SELECT a.*, u.username, u.full_name, t.full_name AS tenant_name FROM audit_logs a LEFT JOIN admin_users u ON u.id=a.admin_id LEFT JOIN tenants t ON t.id=a.tenant_id WHERE 1=1");
define('SQL_AUDIT_LIST_SEARCH_APPEND'," AND (a.action LIKE ? OR a.details LIKE ? OR u.username LIKE ? OR a.ip_address LIKE ?)");
define('SQL_AUDIT_LIST_ORDER',        " ORDER BY a.created_at DESC");

// ── BORROWED ITEMS ───────────────────────────────────────────
define('SQL_BORROWED_BY_TENANT',      "SELECT * FROM borrowed_items WHERE tenant_id=? ORDER BY borrow_date DESC");
define('SQL_BORROWED_ALL',            "SELECT b.*, t.full_name FROM borrowed_items b LEFT JOIN tenants t ON t.id=b.tenant_id ORDER BY borrow_date DESC");
define('SQL_BORROW_INSERT',           "INSERT INTO borrowed_items (tenant_id,item_name,quantity,borrow_date,notes) VALUES (?,?,?,?,?)");
define('SQL_BORROW_RETURN',           "UPDATE borrowed_items SET status='returned', return_date=? WHERE id=?");

// ============================================================
// HELPER FUNCTIONS (shared by both portals)
// ============================================================

function db_execute(PDO $pdo, string $sql, array $params = []): int {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $verb = strtoupper(substr(ltrim($sql), 0, 6));
    return ($verb === 'INSERT') ? (int)$pdo->lastInsertId() : $stmt->rowCount();
}

function db_fetch_all(PDO $pdo, string $sql, array $params = []): array {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function db_fetch_one(PDO $pdo, string $sql, array $params = []): ?array {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function db_scalar(PDO $pdo, string $sql, array $params = [], int $col = 0) {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchColumn($col);
}

function db_paginate(PDO $pdo, string $sql, array $params, int $page, int $perPage): array {
    $total   = (int)db_scalar($pdo, "SELECT COUNT(*) FROM ({$sql}) AS _c", $params);
    $offset  = ($page - 1) * $perPage;
    $rows    = db_fetch_all($pdo, $sql . " LIMIT {$perPage} OFFSET {$offset}", $params);
    return [
        'rows'  => $rows,
        'total' => $total,
        'pages' => max(1, (int)ceil($total / $perPage)),
    ];
}

function db_nav_stats(PDO $pdo): array {
    $stmt = $pdo->query(SQL_NAV_STATS);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: [
        'pending_payments'      => 0,
        'maintenance_requests'  => 0,
        'new_inquiries'         => 0,
        'overdue_payments'      => 0,
        'pending_registrations' => 0,
    ];
}

function db_audit(PDO $pdo, int $adminId, string $action, string $details = ''): void {
    db_audit_admin($pdo, $adminId, $action, $details);
}

function db_audit_admin(PDO $pdo, int $adminId, string $action, string $details = ''): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    db_execute($pdo, SQL_AUDIT_INSERT_ADMIN, [$adminId, $action, $details, $ip]);
}

function db_audit_tenant(PDO $pdo, int $tenantId, string $action, string $details = ''): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    db_execute($pdo, SQL_AUDIT_INSERT_TENANT, [$tenantId, $action, $details, $ip]);
}

function db_auto_expire_contracts(PDO $pdo): int {
    return db_execute($pdo, SQL_CONTRACTS_AUTO_EXPIRE);
}

function db_generate_monthly_invoices(PDO $pdo, int $month, int $year): int {
    $tenants = db_fetch_all($pdo, SQL_TENANTS_ACTIVE);
    $dueDate = sprintf('%04d-%02d-05', $year, $month);
    $created = 0;
    foreach ($tenants as $t) {
        if (!$t['monthly_rent']) continue;
        $exists = (int)db_scalar($pdo, SQL_PAYMENT_EXISTS_FOR_MONTH, [$t['id'], $month, $year]);
        if ($exists === 0) {
            db_execute($pdo,
                "INSERT INTO payments (tenant_id,room_id,amount,type,status,due_date,submitted_by,admin_notes) VALUES (?,?,?,'rent','pending',?,'admin','Auto-generated monthly invoice')",
                [$t['id'], $t['room_id'], $t['monthly_rent'], $dueDate]
            );
            $created++;
        }
    }
    return $created;
}