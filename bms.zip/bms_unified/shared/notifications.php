<?php
/**
 * shared/notifications.php — Email Notifications via PHPMailer + Gmail SMTP
 *
 * Gmail:        ellenboardinghouse1@gmail.com
 * App Password: uudo wgvb fxzs rjbr
 * Sender Name:  Ellen Boarding House
 */

define('BMS_GMAIL_FROM',         'ellenboardinghouse1@gmail.com');
define('BMS_GMAIL_APP_PASSWORD', 'uudo wgvb fxzs rjbr');
define('BMS_GMAIL_FROM_NAME',    'Ellen Boarding House');


// ══════════════════════════════════════════════════════════════════
// CORE SEND FUNCTION
// ══════════════════════════════════════════════════════════════════

function bms_send_email(string $to, string $subject, string $html): array
{
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return [false, 'Invalid email address: ' . $to];
    }

    $auto   = __DIR__ . '/../vendor/autoload.php';
    $manual = __DIR__ . '/../vendor/phpmailer/phpmailer/src/PHPMailer.php';

    if (file_exists($auto)) {
        require_once $auto;
    } elseif (file_exists($manual)) {
        require_once $manual;
        require_once dirname($manual) . '/SMTP.php';
        require_once dirname($manual) . '/Exception.php';
    } else {
        return [false, 'PHPMailer not found. Run: composer require phpmailer/phpmailer'];
    }

    try {
        $m = new PHPMailer\PHPMailer\PHPMailer(true);

        $m->isSMTP();
        $m->Host       = 'smtp.gmail.com';
        $m->SMTPAuth   = true;
        $m->Username   = BMS_GMAIL_FROM;
        $m->Password   = BMS_GMAIL_APP_PASSWORD;
        $m->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $m->Port       = 587;
        $m->CharSet    = 'UTF-8';

        $m->setFrom(BMS_GMAIL_FROM, BMS_GMAIL_FROM_NAME);
        $m->addAddress($to);
        $m->addReplyTo(BMS_GMAIL_FROM, BMS_GMAIL_FROM_NAME);

        $m->isHTML(true);
        $m->Subject = $subject;
        $m->Body    = _bms_template($html);
        $m->AltBody = strip_tags(str_replace(
            ['<br>', '<br/>', '</p>', '</li>', '</tr>'],
            "\n",
            $html
        ));

        $m->send();
        return [true, ''];

    } catch (Throwable $e) {
        error_log('[Ellen BH Mail Error] ' . $e->getMessage());
        return [false, $e->getMessage()];
    }
}


// ══════════════════════════════════════════════════════════════════
// EMAIL TEMPLATE
// ══════════════════════════════════════════════════════════════════

function _bms_template(string $content): string
{
    $year = date('Y');
    $name = BMS_GMAIL_FROM_NAME;

    return <<<HTML
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: Arial, sans-serif; background: #f1f5f9; padding: 20px 0; }
  .wrapper { max-width: 580px; margin: 0 auto; background: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 16px rgba(0,0,0,0.10); }
  .header { background: #2563eb; padding: 28px 32px; text-align: center; }
  .header h1 { color: #ffffff; font-size: 20px; font-weight: 700; margin: 0; }
  .header p { color: rgba(255,255,255,0.75); font-size: 12px; margin: 6px 0 0; letter-spacing: 0.05em; text-transform: uppercase; }
  .body { padding: 28px 32px; color: #334155; font-size: 14px; line-height: 1.8; }
  .body p { margin: 0 0 14px; }
  .body a { color: #2563eb; }
  table.info { width: 100%; border-collapse: collapse; margin: 16px 0; border-radius: 8px; overflow: hidden; border: 1px solid #e2e8f0; }
  table.info td { padding: 10px 14px; font-size: 13.5px; border-bottom: 1px solid #e2e8f0; }
  table.info tr:last-child td { border-bottom: none; }
  table.info tr:nth-child(odd) td { background: #f8fafc; }
  table.info td:first-child { font-weight: 700; color: #475569; width: 44%; }
  .btn-wrap { text-align: center; margin: 20px 0; }
  .btn { display: inline-block; background: #2563eb; color: #ffffff !important; padding: 12px 28px; border-radius: 7px; text-decoration: none; font-weight: 700; font-size: 14px; letter-spacing: 0.02em; }
  .note { background: #fef9c3; border-left: 4px solid #f59e0b; padding: 11px 15px; font-size: 13px; color: #92400e; margin: 16px 0; line-height: 1.6; }
  .success-note { background: #f0fdf4; border-left: 4px solid #22c55e; padding: 11px 15px; font-size: 13px; color: #166534; margin: 16px 0; line-height: 1.6; }
  .danger-note { background: #fef2f2; border-left: 4px solid #ef4444; padding: 11px 15px; font-size: 13px; color: #991b1b; margin: 16px 0; line-height: 1.6; }
  .info-note { background: #eff6ff; border-left: 4px solid #2563eb; padding: 11px 15px; font-size: 13px; color: #1e40af; margin: 16px 0; line-height: 1.6; }
  .footer { background: #f1f5f9; padding: 16px 32px; text-align: center; font-size: 11px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
</style>
</head>
<body>
  <div class="wrapper">
    <div class="header">
      <h1>🏠 {$name}</h1>
      <p>Tenant Portal — Official Notice</p>
    </div>
    <div class="body">
      {$content}
    </div>
    <div class="footer">
      This is an automated message — please do not reply directly to this email.
      &nbsp;·&nbsp; © {$year} {$name}. All rights reserved.
    </div>
  </div>
</body>
</html>
HTML;
}


// ══════════════════════════════════════════════════════════════════
// EXISTING FUNCTIONS (unchanged)
// ══════════════════════════════════════════════════════════════════

function notify_inquiry_received(string $email, string $name, string $statusUrl): array
{
    $subject = 'We Received Your Room Inquiry — ' . BMS_GMAIL_FROM_NAME;
    $html    = "
<p>Dear <strong>{$name}</strong>,</p>
<p>Thank you for your interest in renting with us! We have received your room inquiry and our team will review it shortly.</p>
<p>We will reach out to you soon to discuss room availability.</p>
<div class='note'>
  📌 <strong>Want to check the status of your inquiry?</strong><br><br>
  Visit this page anytime and enter your email address:<br>
  <a href='{$statusUrl}'>{$statusUrl}</a>
</div>
<p>We look forward to speaking with you!</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}

function notify_inquiry_closed(string $email, string $name, string $inquiryUrl): array
{
    $subject = 'Update on Your Room Inquiry — ' . BMS_GMAIL_FROM_NAME;
    $html    = "
<p>Dear <strong>{$name}</strong>,</p>
<p>Thank you for your interest in renting with us.</p>
<p>Unfortunately, we are <strong>unable to accommodate your request at this time</strong>. The room may no longer be available, or we were unable to reach you within the inquiry window.</p>
<p>You are welcome to <a href='{$inquiryUrl}'>submit a new inquiry</a> at any time.</p>
<p>We appreciate your interest and hope to hear from you again soon.</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}

function notify_invite_sent(string $email, string $name, string $registerUrl): array
{
    $subject = '🎉 A Room Is Available — You\'re Invited to Register!';
    $html    = "
<p>Dear <strong>{$name}</strong>,</p>
<p>Great news! We have reviewed your inquiry and <strong>a room is available for you</strong>.</p>
<p>You have been invited to create your tenant account. Click the button below to get started:</p>
<div class='btn-wrap'>
  <a href='{$registerUrl}' class='btn'>Create My Account →</a>
</div>
<p style='font-size:13px;color:#64748b;'>Or copy and paste this link into your browser:<br>
<a href='{$registerUrl}'>{$registerUrl}</a></p>
<div class='note'>
  ⚠ <strong>Important:</strong> This invite link is valid for <strong>7 days</strong> and can only be used <strong>once</strong>. Please do not share it with anyone.
</div>
<p>After you register, the admin will set up your room and rent details, then send you your login credentials.</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}

function notify_registration_approved(
    string $email,
    string $name,
    string $loginEmail,
    string $password,
    string $roomNumber,
    float  $monthlyRent,
    int    $dueDay,
    string $moveIn,
    string $loginUrl
): array {
    $sfx = match (true) {
        $dueDay % 100 >= 11 && $dueDay % 100 <= 13 => 'th',
        $dueDay % 10 === 1                          => 'st',
        $dueDay % 10 === 2                          => 'nd',
        $dueDay % 10 === 3                          => 'rd',
        default                                     => 'th',
    };

    $rentFormatted   = '₱' . number_format($monthlyRent, 2);
    $moveInFormatted = ($moveIn && $moveIn !== '0000-00-00')
        ? date('F j, Y', strtotime($moveIn))
        : 'To be confirmed';

    $subject = '✅ Your Registration is Approved — Welcome to ' . BMS_GMAIL_FROM_NAME . '!';

    $html = "
<p>Dear <strong>{$name}</strong>,</p>
<p>Congratulations! 🎉 Your tenant registration has been <strong style='color:#16a34a;'>approved</strong>. Below are your account details — please save these:</p>

<table class='info'>
  <tr><td>Login Email</td><td>{$loginEmail}</td></tr>
  <tr>
    <td>Password</td>
    <td><strong style='font-family:monospace;font-size:16px;letter-spacing:3px;color:#1e293b;'>{$password}</strong></td>
  </tr>
  <tr><td>Room Number</td><td><strong>{$roomNumber}</strong></td></tr>
  <tr><td>Monthly Rent</td><td><strong>{$rentFormatted}</strong></td></tr>
  <tr><td>Rent Due Date</td><td>Every <strong>{$dueDay}{$sfx}</strong> of the month</td></tr>
  <tr><td>Move-In Date</td><td>{$moveInFormatted}</td></tr>
</table>

<div class='btn-wrap'>
  <a href='{$loginUrl}' class='btn'>Sign In to Tenant Portal →</a>
</div>

<div class='note'>
  ⚠ <strong>Save your password now.</strong> For security, this password will not be sent again. You can change it from your Profile page after signing in.
</div>

<div class='success-note'>
  ✅ Once logged in you can: track your payments, submit maintenance requests, view announcements, and manage your profile.
</div>

<p>Welcome aboard — we're glad to have you! 🏡</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}

function notify_registration_rejected(
    string $email,
    string $name,
    string $reason,
    string $inquiryUrl
): array {
    $subject    = 'Update on Your Tenant Registration — ' . BMS_GMAIL_FROM_NAME;
    $reasonHtml = $reason
        ? "<div class='danger-note'><strong>Reason:</strong> " . htmlspecialchars($reason, ENT_QUOTES, 'UTF-8') . "</div>"
        : '';

    $html = "
<p>Dear <strong>{$name}</strong>,</p>
<p>Thank you for your patience while we reviewed your registration.</p>
<p>We regret to inform you that your tenant registration has <strong>not been approved</strong> at this time.</p>
{$reasonHtml}
<p>If you have any questions or would like to try again, please <a href='{$inquiryUrl}'>submit a new inquiry</a> at any time.</p>
<p>We appreciate your interest.</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}


// ══════════════════════════════════════════════════════════════════
// NEW: PASSWORD RESET
// ══════════════════════════════════════════════════════════════════

/**
 * Sent when tenant requests a password reset.
 */
function notify_password_reset(string $email, string $name, string $resetUrl): array
{
    $subject = '🔒 Reset Your Password — ' . BMS_GMAIL_FROM_NAME;
    $html    = "
<p>Dear <strong>{$name}</strong>,</p>
<p>We received a request to reset the password for your tenant account.</p>
<p>Click the button below to set a new password:</p>
<div class='btn-wrap'>
  <a href='{$resetUrl}' class='btn'>Reset My Password →</a>
</div>
<p style='font-size:13px;color:#64748b;'>Or copy and paste this link into your browser:<br>
<a href='{$resetUrl}'>{$resetUrl}</a></p>
<div class='note'>
  ⚠ <strong>This link expires in 1 hour</strong> and can only be used once.<br>
  If you did not request a password reset, you can safely ignore this email — your password will not be changed.
</div>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}


// ══════════════════════════════════════════════════════════════════
// NEW: PAYMENT ACCEPTED
// ══════════════════════════════════════════════════════════════════

/**
 * Sent when admin accepts/confirms a tenant's payment.
 */
function notify_payment_accepted(
    string $email,
    string $name,
    float  $amount,
    string $method,
    string $dueDate,
    string $confirmedAt,
    string $adminNote,
    string $portalUrl
): array {
    $subject       = '✅ Payment Confirmed — ' . BMS_GMAIL_FROM_NAME;
    $amtFormatted  = '₱' . number_format($amount, 2);
    $dueFmt        = $dueDate    ? date('F j, Y', strtotime($dueDate))    : '—';
    $confFmt       = $confirmedAt ? date('F j, Y g:i A', strtotime($confirmedAt)) : date('F j, Y g:i A');
    $noteHtml      = $adminNote
        ? "<div class='info-note'>💬 <strong>Admin note:</strong> " . htmlspecialchars($adminNote, ENT_QUOTES, 'UTF-8') . "</div>"
        : '';

    $html = "
<p>Dear <strong>{$name}</strong>,</p>
<p>Great news! Your payment has been <strong style='color:#16a34a;'>confirmed</strong> by our management team. Here are the details:</p>

<table class='info'>
  <tr><td>Amount</td><td><strong style='font-size:16px;color:#16a34a;'>{$amtFormatted}</strong></td></tr>
  <tr><td>Payment Method</td><td>" . htmlspecialchars($method, ENT_QUOTES, 'UTF-8') . "</td></tr>
  <tr><td>For Month / Due</td><td>{$dueFmt}</td></tr>
  <tr><td>Confirmed On</td><td>{$confFmt}</td></tr>
</table>

{$noteHtml}

<div class='success-note'>
  ✅ Your payment is on record. You can view your full payment history in the tenant portal.
</div>

<div class='btn-wrap'>
  <a href='{$portalUrl}' class='btn'>View Payment History →</a>
</div>

<p>Thank you for your prompt payment! 🙏</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}


// ══════════════════════════════════════════════════════════════════
// NEW: PAYMENT REJECTED
// ══════════════════════════════════════════════════════════════════

/**
 * Sent when admin rejects a tenant's payment submission.
 */
function notify_payment_rejected(
    string $email,
    string $name,
    float  $amount,
    string $method,
    string $adminNote,
    string $portalUrl
): array {
    $subject      = '❌ Payment Not Accepted — Action Required';
    $amtFormatted = '₱' . number_format($amount, 2);
    $reasonHtml   = $adminNote
        ? "<div class='danger-note'>📋 <strong>Reason:</strong> " . htmlspecialchars($adminNote, ENT_QUOTES, 'UTF-8') . "</div>"
        : "<div class='danger-note'>No specific reason was provided. Please contact management for details.</div>";

    $html = "
<p>Dear <strong>{$name}</strong>,</p>
<p>We were unable to process your payment submission. Please review the details below:</p>

<table class='info'>
  <tr><td>Amount Submitted</td><td><strong>{$amtFormatted}</strong></td></tr>
  <tr><td>Payment Method</td><td>" . htmlspecialchars($method, ENT_QUOTES, 'UTF-8') . "</td></tr>
  <tr><td>Status</td><td><strong style='color:#dc2626;'>Rejected</strong></td></tr>
</table>

{$reasonHtml}

<div class='note'>
  ⚠ <strong>Action required:</strong> Please go to the tenant portal and resubmit your payment with the correct details or proof of payment.
</div>

<div class='btn-wrap'>
  <a href='{$portalUrl}' class='btn'>Resubmit Payment →</a>
</div>

<p>If you have any questions, please contact us directly.</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}


// ══════════════════════════════════════════════════════════════════
// NEW: MAINTENANCE STATUS UPDATE
// ══════════════════════════════════════════════════════════════════

/**
 * Sent when admin updates the status of a maintenance request.
 */
function notify_maintenance_update(
    string $email,
    string $name,
    string $requestTitle,
    string $newStatus,
    string $adminReply,
    string $portalUrl
): array {
    $statusLabels = [
        'open'        => ['label' => 'Open',         'color' => '#2563eb', 'icon' => '📋'],
        'in_progress' => ['label' => 'In Progress',  'color' => '#d97706', 'icon' => '🔧'],
        'pending'     => ['label' => 'Pending',       'color' => '#d97706', 'icon' => '⏳'],
        'resolved'    => ['label' => 'Resolved',      'color' => '#16a34a', 'icon' => '✅'],
        'closed'      => ['label' => 'Closed',        'color' => '#64748b', 'icon' => '🔒'],
    ];
    $s         = $statusLabels[$newStatus] ?? ['label' => ucfirst($newStatus), 'color' => '#334155', 'icon' => '📋'];
    $subject   = "{$s['icon']} Maintenance Update: " . $requestTitle . ' — ' . BMS_GMAIL_FROM_NAME;
    $replyHtml = $adminReply
        ? "<div class='info-note'>💬 <strong>Message from management:</strong><br>" . nl2br(htmlspecialchars($adminReply, ENT_QUOTES, 'UTF-8')) . "</div>"
        : '';
    $isResolved = in_array($newStatus, ['resolved', 'closed']);

    $html = "
<p>Dear <strong>{$name}</strong>,</p>
<p>There is an update on your maintenance request:</p>

<table class='info'>
  <tr><td>Request</td><td><strong>" . htmlspecialchars($requestTitle, ENT_QUOTES, 'UTF-8') . "</strong></td></tr>
  <tr><td>New Status</td><td><strong style='color:{$s['color']};'>{$s['icon']} {$s['label']}</strong></td></tr>
</table>

{$replyHtml}

" . ($isResolved
    ? "<div class='success-note'>✅ Your maintenance issue has been resolved. If the problem persists, please submit a new request from the tenant portal.</div>"
    : "<div class='info-note'>ℹ Our maintenance team is working on your request. We will update you again when there is a change.</div>"
) . "

<div class='btn-wrap'>
  <a href='{$portalUrl}' class='btn'>View Request →</a>
</div>

<p>Thank you for your patience.</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}


// ══════════════════════════════════════════════════════════════════
// NEW: CONTRACT EXPIRY WARNING
// ══════════════════════════════════════════════════════════════════

/**
 * Sent to tenant when their contract is expiring soon (30 days or 7 days).
 */
function notify_contract_expiring(
    string $email,
    string $name,
    string $roomNumber,
    string $endDate,
    int    $daysLeft,
    string $portalUrl
): array {
    $endFmt  = date('F j, Y', strtotime($endDate));
    $urgency = $daysLeft <= 7 ? 'danger-note' : 'note';
    $icon    = $daysLeft <= 7 ? '🔴' : '🟡';
    $subject = "{$icon} Your Lease Expires in {$daysLeft} Day" . ($daysLeft !== 1 ? 's' : '') . ' — ' . BMS_GMAIL_FROM_NAME;

    $html = "
<p>Dear <strong>{$name}</strong>,</p>
<p>This is a reminder that your lease contract for <strong>Room {$roomNumber}</strong> is expiring soon.</p>

<table class='info'>
  <tr><td>Room</td><td><strong>{$roomNumber}</strong></td></tr>
  <tr><td>Contract End Date</td><td><strong style='color:#dc2626;'>{$endFmt}</strong></td></tr>
  <tr><td>Days Remaining</td><td><strong style='color:#dc2626;'>{$daysLeft} day" . ($daysLeft !== 1 ? 's' : '') . "</strong></td></tr>
</table>

<div class='{$urgency}'>
  {$icon} <strong>Action required:</strong> Please contact management as soon as possible to discuss renewal or move-out arrangements before your contract expires.
</div>

<div class='btn-wrap'>
  <a href='{$portalUrl}' class='btn'>Contact Management →</a>
</div>

<p>If you have already arranged this with our team, please disregard this notice.</p>
<p>— The Management Team</p>";

    return bms_send_email($email, $subject, $html);
}